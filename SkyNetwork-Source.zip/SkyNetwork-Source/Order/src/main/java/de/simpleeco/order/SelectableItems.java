package de.simpleeco.order;

import org.bukkit.Material;

import java.util.ArrayList;
import java.util.List;

/**
 * Provides the list of items a player may create a buy order for.
 * Excludes technical / creative-only / non-obtainable items (e.g. Bedrock,
 * command blocks, barriers, spawn eggs, structure blocks).
 */
public final class SelectableItems {

    private static List<Material> cache;

    private SelectableItems() {
    }

    public static List<Material> all() {
        if (cache == null) {
            cache = build();
        }
        return cache;
    }

    private static List<Material> build() {
        List<Material> list = new ArrayList<>();
        for (Material m : Material.values()) {
            if (isSelectable(m)) {
                list.add(m);
            }
        }
        list.sort((a, b) -> a.name().compareToIgnoreCase(b.name()));
        return list;
    }

    private static boolean isSelectable(Material m) {
        if (m.isLegacy() || m.isAir() || !m.isItem()) {
            return false;
        }
        String n = m.name();
        if (n.contains("COMMAND_BLOCK") || n.equals("BARRIER") || n.equals("STRUCTURE_VOID")
                || n.equals("STRUCTURE_BLOCK") || n.equals("JIGSAW") || n.equals("LIGHT")
                || n.equals("DEBUG_STICK") || n.equals("KNOWLEDGE_BOOK") || n.contains("SPAWN_EGG")
                || n.equals("BEDROCK") || n.equals("END_PORTAL_FRAME") || n.contains("INFESTED")
                || n.equals("SPAWNER") || n.equals("REINFORCED_DEEPSLATE")
                || n.equals("BUNDLE") || n.equals("WATER") || n.equals("LAVA")
                || n.endsWith("_SPAWN_EGG") || n.equals("PETRIFIED_OAK_SLAB")) {
            return false;
        }
        return true;
    }
}
