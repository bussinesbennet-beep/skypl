package de.simpleeco.order.gui;

import de.simpleeco.order.util.CoreI18n;
import de.simpleeco.order.util.DialogUi;
import de.simpleeco.order.util.Text;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Enchantment picker for order requests, matching the Shop's level-cycling
 * selector. Enchanted swords and pickaxes are saved as exact order variants.
 */
public final class OrderEnchantDialog {

    private record Def(Enchantment enchantment, int max, String group) { }

    private static final List<Def> SWORD = List.of(
            new Def(Enchantment.SHARPNESS, 5, "damage"),
            new Def(Enchantment.SMITE, 5, "damage"),
            new Def(Enchantment.BANE_OF_ARTHROPODS, 5, "damage"),
            new Def(Enchantment.KNOCKBACK, 2, ""),
            new Def(Enchantment.FIRE_ASPECT, 2, ""),
            new Def(Enchantment.LOOTING, 3, ""),
            new Def(Enchantment.SWEEPING_EDGE, 3, ""),
            new Def(Enchantment.UNBREAKING, 3, ""),
            new Def(Enchantment.MENDING, 1, ""),
            new Def(Enchantment.VANISHING_CURSE, 1, "")
    );

    private static final List<Def> PICKAXE = List.of(
            new Def(Enchantment.EFFICIENCY, 5, ""),
            new Def(Enchantment.FORTUNE, 3, "tool"),
            new Def(Enchantment.SILK_TOUCH, 1, "tool"),
            new Def(Enchantment.UNBREAKING, 3, ""),
            new Def(Enchantment.MENDING, 1, ""),
            new Def(Enchantment.VANISHING_CURSE, 1, "")
    );

    private final JavaPlugin plugin;

    public OrderEnchantDialog(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    private static List<Def> defs(Material material) {
        return material == Material.DIAMOND_PICKAXE ? PICKAXE : SWORD;
    }

    /** Opens the selector, optionally pre-populated from the current draft. */
    public void open(Player player, Material material, Map<Enchantment, Integer> initial,
                     Consumer<Map<Enchantment, Integer>> onFinish, Runnable onCancel) {
        if (material != Material.DIAMOND_SWORD && material != Material.DIAMOND_PICKAXE) {
            onFinish.accept(Map.of());
            return;
        }
        Session session = new Session(material, initial, onFinish, onCancel);
        show(player, session);
    }

    private void show(Player player, Session session) {
        String itemName = pretty(session.material);
        Component title = Text.of(CoreI18n.gui(player, "order-gui.items.enchant-title",
                "Enchantments — {item}", "item", itemName));

        ItemStack preview = new ItemStack(session.material);
        ItemMeta previewMeta = preview.getItemMeta();
        if (previewMeta != null) {
            session.levels.forEach((enchantment, level) -> previewMeta.addEnchant(enchantment, level, true));
            preview.setItemMeta(previewMeta);
        }

        List<DialogBody> body = new ArrayList<>();
        body.add(DialogUi.itemBody(preview));
        body.add(DialogUi.muted(CoreI18n.gui(player, "order-gui.items.enchant-help",
                "Click an enchantment to raise its level; cycle past the maximum to remove it.")));

        List<ActionButton> buttons = new ArrayList<>();
        for (Def def : defs(session.material)) {
            int level = session.levels.getOrDefault(def.enchantment(), 0);
            boolean blocked = level == 0 && isBlocked(def, session);
            Component label = Component.text()
                    .append(Component.text(prettyEnchant(def.enchantment()),
                                    blocked ? NamedTextColor.DARK_GRAY : NamedTextColor.WHITE)
                            .decoration(TextDecoration.ITALIC, false))
                    .append(Component.text(level > 0 ? "  " + roman(level) : "  —",
                                    level > 0 ? NamedTextColor.WHITE : NamedTextColor.GRAY)
                            .decoration(TextDecoration.ITALIC, false))
                    .build();

            String tooltip = blocked
                    ? CoreI18n.gui(player, "order-gui.items.enchant-blocked",
                            "Conflicts with another enchantment already on this item.")
                    : level >= def.max()
                    ? CoreI18n.gui(player, "order-gui.items.enchant-remove", "Click to remove this enchantment.")
                    : CoreI18n.gui(player, "order-gui.items.enchant-next-level",
                            "Click for level {level}.", "level", roman(level + 1));

            buttons.add(DialogUi.button(label, tooltip, 150, DialogUi.WHITE,
                    blocked ? null : DialogUi.click(p -> {
                        cycle(session, def);
                        show(p, session);
                    })));
        }

        Component finishLabel = DialogUi.withIcon(plugin, "check", Component.text(
                CoreI18n.gui(player, "order-gui.items.enchant-use", "Use Item")
                        .replace("&8", "").replace("&f", ""))
                .decoration(TextDecoration.ITALIC, false));
        buttons.add(DialogUi.button(finishLabel,
                CoreI18n.gui(player, "order-gui.items.enchant-use-lore",
                        "Use this exact enchanted variant for the order."),
                150, DialogUi.POSITIVE, DialogUi.click(p -> {
                    Map<Enchantment, Integer> result = Map.copyOf(session.levels);
                    p.closeDialog();
                    DialogUi.runNextTick(plugin, () -> session.onFinish.accept(result));
                })));

        Component cancelLabel = DialogUi.withIcon(plugin, "cross", Component.text(
                CoreI18n.gui(player, "order-gui.items.enchant-cancel", "Cancel")
                        .replace("&8", "").replace("&f", ""))
                .decoration(TextDecoration.ITALIC, false));
        buttons.add(DialogUi.button(cancelLabel,
                CoreI18n.gui(player, "order-gui.items.enchant-cancel-lore",
                        "Return to the item list without changing the order."),
                150, DialogUi.NEGATIVE, DialogUi.click(p -> {
                    p.closeDialog();
                    DialogUi.runNextTick(plugin, session.onCancel);
                })));

        DialogUi.open(player, title, body, buttons, 2);
    }

    private static boolean isBlocked(Def def, Session session) {
        if (def.group().isEmpty()) return false;
        for (Def other : defs(session.material)) {
            if (other == def || !other.group().equals(def.group())) continue;
            if (session.levels.getOrDefault(other.enchantment(), 0) > 0) return true;
        }
        return false;
    }

    private static void cycle(Session session, Def def) {
        int current = session.levels.getOrDefault(def.enchantment(), 0);
        if (current >= def.max()) {
            session.levels.remove(def.enchantment());
            return;
        }
        if (!def.group().isEmpty()) {
            for (Def other : defs(session.material)) {
                if (other != def && other.group().equals(def.group())) {
                    session.levels.remove(other.enchantment());
                }
            }
        }
        session.levels.put(def.enchantment(), current + 1);
    }

    private static String pretty(Material material) {
        String[] parts = material.name().toLowerCase(java.util.Locale.ROOT).split("_");
        StringBuilder result = new StringBuilder();
        for (String part : parts) {
            if (!part.isEmpty()) {
                if (!result.isEmpty()) result.append(' ');
                result.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
            }
        }
        return result.toString();
    }

    private static String prettyEnchant(Enchantment enchantment) {
        String[] parts = enchantment.getKey().getKey().split("_");
        StringBuilder result = new StringBuilder();
        for (String part : parts) {
            if (!result.isEmpty()) result.append(' ');
            result.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return result.toString();
    }

    private static String roman(int level) {
        return switch (level) {
            case 1 -> "I";
            case 2 -> "II";
            case 3 -> "III";
            case 4 -> "IV";
            case 5 -> "V";
            default -> String.valueOf(level);
        };
    }

    private static final class Session {
        private final Material material;
        private final LinkedHashMap<Enchantment, Integer> levels = new LinkedHashMap<>();
        private final Consumer<Map<Enchantment, Integer>> onFinish;
        private final Runnable onCancel;

        private Session(Material material, Map<Enchantment, Integer> initial,
                        Consumer<Map<Enchantment, Integer>> onFinish, Runnable onCancel) {
            this.material = material;
            if (initial != null) initial.forEach((enchantment, level) -> {
                if (enchantment != null && level != null && level > 0) levels.put(enchantment, level);
            });
            this.onFinish = onFinish;
            this.onCancel = onCancel == null ? () -> { } : onCancel;
        }
    }
}
