package de.simpleeco.order.gui;

import de.simpleeco.order.BuyOrder;

import java.util.Comparator;

/**
 * Sort modes for the order board, cycled by the compass.
 */
public enum OrderSort {

    NEWEST("Newest", Comparator.comparingLong(BuyOrder::getCreatedAt).reversed()),
    PRICE_DESC("Highest price", Comparator.comparingDouble(BuyOrder::getPricePerUnit).reversed()),
    PRICE_ASC("Lowest price", Comparator.comparingDouble(BuyOrder::getPricePerUnit)),
    QUANTITY_DESC("Most wanted", Comparator.comparingInt(BuyOrder::remaining).reversed());

    private final String label;
    private final Comparator<BuyOrder> comparator;

    OrderSort(String label, Comparator<BuyOrder> comparator) {
        this.label = label;
        this.comparator = comparator;
    }

    public String getLabel() { return label; }
    public Comparator<BuyOrder> getComparator() { return comparator; }

    public OrderSort next() {
        OrderSort[] v = values();
        return v[(ordinal() + 1) % v.length];
    }
}
