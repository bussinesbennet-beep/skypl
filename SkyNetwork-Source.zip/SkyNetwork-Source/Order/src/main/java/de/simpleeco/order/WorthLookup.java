package de.simpleeco.order;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.EnumMap;
import java.util.Locale;
import java.util.Map;

/**
 * Soft integration with the SellWorth plugin: reads its {@code worth.yml} so the
 * order-claim "Sell all" button can price delivered items. If SellWorth is not
 * installed (or a material has no price), selling is simply unavailable.
 *
 * The file is re-read when its last-modified timestamp changes, so owner edits
 * are picked up without a restart.
 */
public class WorthLookup {

    private final JavaPlugin plugin;
    private final Map<Material, Double> prices = new EnumMap<>(Material.class);
    private long lastModified = -1;
    private boolean checkedFile = false;

    public WorthLookup(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    /** True if the SellWorth plugin is present on the server. */
    public boolean isAvailable() {
        return plugin.getServer().getPluginManager().getPlugin("SellWorth") != null;
    }

    private File worthFile() {
        File pluginsDir = plugin.getDataFolder().getParentFile();
        return new File(pluginsDir, "SellWorth/worth.yml");
    }

    private void ensureLoaded() {
        File file = worthFile();
        if (!file.exists()) {
            if (!checkedFile) {
                checkedFile = true;
            }
            prices.clear();
            lastModified = -1;
            return;
        }
        long mod = file.lastModified();
        if (mod == lastModified && !prices.isEmpty()) {
            return; // up to date
        }
        prices.clear();
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = cfg.getConfigurationSection("worth");
        if (section != null) {
            for (String key : section.getKeys(false)) {
                Material mat = Material.matchMaterial(key.toUpperCase(Locale.ROOT));
                if (mat == null) continue;
                double price = section.getDouble(key, 0);
                if (price > 0) prices.put(mat, price);
            }
        }
        lastModified = mod;
    }

    /** Per-unit sell price for a material, or 0 if not sellable / SellWorth absent. */
    public double unitPrice(Material material) {
        if (!isAvailable()) return 0;
        ensureLoaded();
        return prices.getOrDefault(material, 0.0);
    }

    public boolean canSell(Material material) {
        return unitPrice(material) > 0;
    }
}
