package de.simpleeco.order;

import de.simpleeco.order.economy.EconomyBridge;
import de.simpleeco.order.gui.OrderGui;
import de.simpleeco.order.gui.OrderListener;
import de.simpleeco.order.storage.OrderStorage;
import de.simpleeco.order.util.SignInput;
import org.bukkit.command.PluginCommand;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.sql.SQLException;
import de.simpleeco.order.util.CoreI18n;

public class OrderPlugin extends JavaPlugin {

    private OrderStorage storage;
    private OrderManager manager;
    private StatStore stats;

    @Override
    public void onEnable() {
        CoreI18n.registerReloadable("order", () -> { saveDefaultConfig(); reloadConfig(); });
        saveDefaultConfig();

        storage = new OrderStorage(this, getConfig().getString("database.file", "../../../network-data/orders.db"));
        try {
            storage.init();
        } catch (SQLException e) {
            getLogger().severe("Could not initialize the database: " + e.getMessage());
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        EconomyBridge economy = new EconomyBridge(this);
        economy.resolve();

        int defaultLimit = getConfig().getInt("limits.default-limit", 9);
        double minPrice = getConfig().getDouble("order.min-price-per-unit", 1);
        double maxPrice = getConfig().getDouble("order.max-price-per-unit", 1000000);
        int maxQuantity = getConfig().getInt("order.max-quantity", 0);

        manager = new OrderManager(storage, economy, defaultLimit, minPrice, maxPrice, maxQuantity);
        manager.loadAll();

        WorthLookup worth = new WorthLookup(this);
        OrderGui gui = new OrderGui(manager, economy, worth, getConfig());

        // Per-player statistics (for PlaceholderAPI).
        stats = new StatStore(this);

        // Sign input helper (used for search and quantity/price entry).
        SignInput signInput = new SignInput(this);
        getServer().getPluginManager().registerEvents(signInput, this);

        de.simpleeco.order.economy.PrefsBridge orderPrefs = new de.simpleeco.order.economy.PrefsBridge();
        orderPrefs.resolve();

        de.simpleeco.order.gui.OrderListener orderListener =
                new de.simpleeco.order.gui.OrderListener(this, manager, gui, economy, signInput,
                        getConfig(), stats, orderPrefs, new de.simpleeco.order.util.Sounds(orderPrefs));
        gui.setListener(orderListener);
        getServer().getPluginManager().registerEvents(orderListener, this);

        // Anti-dupe safety net for stray GUI/display items.
        de.simpleeco.order.util.GuiGuard orderGuard = new de.simpleeco.order.util.GuiGuard(this);
        getServer().getPluginManager().registerEvents(orderGuard, this);
        orderGuard.startPeriodicSweep();

        // PlaceholderAPI-Expansion registrieren, falls PlaceholderAPI vorhanden ist.
        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new PlaceholderHook(stats, economy.symbol()).register();
            getLogger().info("Hooked into PlaceholderAPI (%order_earned%, %order_spent%).");
        }

        // Clean up any pending sign prompt if a player quits mid-prompt.
        getServer().getPluginManager().registerEvents(new Listener() {
            @EventHandler
            public void onQuit(PlayerQuitEvent e) {
                signInput.cancel(e.getPlayer().getUniqueId());
            }
        }, this);

        PluginCommand cmd = getCommand("order");
        if (cmd != null) {
            cmd.setExecutor(new OrderCommand(gui, getConfig()));
        }

        getLogger().info("Order has been enabled.");
    }

    @Override
    public void onDisable() {
        if (storage != null) {
            storage.close();
        }
        if (stats != null) {
            stats.saveNow();
        }
        getLogger().info("Order has been disabled.");
    }
}
