package de.simpleeco.order;

import de.simpleeco.order.economy.EconomyBridge;
import de.simpleeco.order.storage.OrderStorage;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Central buy-order logic: create, fulfil, claim, cancel, and query orders.
 * Money is reserved from the creator on creation and paid to fulfillers per
 * unit delivered. Cancelling refunds the reserved money for the remainder.
 */
public class OrderManager {

    private final OrderStorage storage;
    private final EconomyBridge economy;

    private final int defaultLimit;
    private final double minPrice;
    private final double maxPrice;
    private final int maxQuantity;

    private final Map<UUID, BuyOrder> orders = new ConcurrentHashMap<>();

    public OrderManager(OrderStorage storage, EconomyBridge economy,
                        int defaultLimit, double minPrice, double maxPrice, int maxQuantity) {
        this.storage = storage;
        this.economy = economy;
        this.defaultLimit = defaultLimit;
        this.minPrice = minPrice;
        this.maxPrice = maxPrice;
        this.maxQuantity = maxQuantity;
    }

    public void loadAll() {
        orders.clear();
        for (BuyOrder o : storage.loadAll()) {
            orders.put(o.getId(), o);
        }
    }

    // ----- Queries -----

    public BuyOrder get(UUID id) {
        loadAll();
        return orders.get(id);
    }

    /** All orders that still want items (open), for the public board. */
    public List<BuyOrder> openOrders() {
        loadAll();
        List<BuyOrder> list = new ArrayList<>();
        for (BuyOrder o : orders.values()) {
            if (!o.isComplete()) {
                list.add(o);
            }
        }
        return list;
    }

    /** All orders belonging to a player (including completed ones with pending claims). */
    public List<BuyOrder> ordersOf(UUID owner) {
        loadAll();
        List<BuyOrder> list = new ArrayList<>();
        for (BuyOrder o : orders.values()) {
            if (o.getOwner().equals(owner)) {
                list.add(o);
            }
        }
        list.sort(Comparator.comparingLong(BuyOrder::getCreatedAt).reversed());
        return list;
    }

    /** Count of open (still-wanted) orders that occupy a player's limit slot. */
    public int openCountOf(UUID owner) {
        loadAll();
        int count = 0;
        for (BuyOrder o : orders.values()) {
            if (o.getOwner().equals(owner) && !o.isComplete()) {
                count++;
            }
        }
        return count;
    }

    // ----- Limits -----

    public int limitFor(Player player) {
        if (player.hasPermission("order.limit.unlimited")) {
            return Integer.MAX_VALUE;
        }
        int best = defaultLimit;
        // Highest order.limit.<n> permission wins.
        for (var pai : player.getEffectivePermissions()) {
            String perm = pai.getPermission().toLowerCase();
            if (pai.getValue() && perm.startsWith("order.limit.")) {
                String suffix = perm.substring("order.limit.".length());
                try {
                    best = Math.max(best, Integer.parseInt(suffix));
                } catch (NumberFormatException ignored) {
                    // "unlimited" handled above
                }
            }
        }
        return best;
    }

    // ----- Config accessors -----

    public double getMinPrice() { return minPrice; }
    public double getMaxPrice() { return maxPrice; }
    public int getMaxQuantity() { return maxQuantity; }

    /** Whether there is no per-order quantity cap (max-quantity <= 0). */
    public boolean isQuantityUnlimited() { return maxQuantity <= 0; }

    /** Effective quantity cap for clamping input; Integer.MAX_VALUE when unlimited. */
    public int effectiveMaxQuantity() { return isQuantityUnlimited() ? Integer.MAX_VALUE : maxQuantity; }

    // ----- Mutations -----

    public enum CreateResult { OK, LIMIT_REACHED, NO_MONEY, INVALID, ECON_MISSING }

    /**
     * Creates a buy order, reserving quantity*price from the creator.
     */
    public CreateResult create(Player owner, Material material, int quantity, double pricePerUnit) {
        return create(owner, material, quantity, pricePerUnit, Map.of());
    }

    /** Creates a buy order, reserving funds for a material and optional enchants. */
    public CreateResult create(Player owner, Material material, int quantity, double pricePerUnit,
                               Map<Enchantment, Integer> enchantments) {
        if (!economy.isAvailable()) {
            return CreateResult.ECON_MISSING;
        }
        if (material == null || material == Material.AIR
                || quantity < 1 || (!isQuantityUnlimited() && quantity > maxQuantity)
                || pricePerUnit < minPrice || pricePerUnit > maxPrice
                || !validEnchantments(material, enchantments)) {
            return CreateResult.INVALID;
        }
        if (openCountOf(owner.getUniqueId()) >= limitFor(owner)) {
            return CreateResult.LIMIT_REACHED;
        }
        double total = quantity * pricePerUnit;
        if (!economy.has(owner.getUniqueId(), total)) {
            return CreateResult.NO_MONEY;
        }
        if (!economy.withdraw(owner.getUniqueId(), total)) {
            return CreateResult.NO_MONEY;
        }
        economy.recordOrderSpent(owner.getUniqueId(), total);
        BuyOrder order = BuyOrder.create(owner.getUniqueId(), owner.getName(),
                material, quantity, pricePerUnit, enchantments);
        orders.put(order.getId(), order);
        storage.save(order);
        return CreateResult.OK;
    }

    private boolean validEnchantments(Material material, Map<Enchantment, Integer> enchantments) {
        if (enchantments == null || enchantments.isEmpty()) return true;
        if (material != Material.DIAMOND_SWORD && material != Material.DIAMOND_PICKAXE) return false;
        List<Enchantment> selected = new ArrayList<>();
        for (Map.Entry<Enchantment, Integer> entry : enchantments.entrySet()) {
            Enchantment enchantment = entry.getKey();
            Integer level = entry.getValue();
            if (enchantment == null || level == null || level < 1 || level > enchantment.getMaxLevel()
                    || !enchantment.canEnchantItem(new org.bukkit.inventory.ItemStack(material))) {
                return false;
            }
            for (Enchantment previous : selected) {
                if (enchantment.conflictsWith(previous)) return false;
            }
            selected.add(enchantment);
        }
        return true;
    }

    /**
     * Fulfils up to {@code offer} units of an order from a fulfiller.
     * Pays the fulfiller per delivered unit and releases the reserved money.
     *
     * @return the number of units actually accepted (0 if none).
     */
    public int fulfil(BuyOrder order, Player fulfiller, int offer) {
        if (order == null || order.isComplete() || offer <= 0) {
            return 0;
        }
        OrderStorage.FulfilResult result = storage.fulfil(order.getId(), offer);
        if (result == null || result.accepted() <= 0) return 0;
        order = result.order();
        int accepted = result.accepted();
        double payout = accepted * order.getPricePerUnit();
        orders.put(order.getId(), order);

        economy.deposit(fulfiller.getUniqueId(), payout);
        economy.recordOrderEarned(fulfiller.getUniqueId(), payout);
        return accepted;
    }

    /**
     * Marks up to {@code claimed} pending items as claimed (called after the
     * items were successfully given to the owner).
     */
    public void claim(BuyOrder order, int claimed) {
        if (order == null || claimed <= 0) {
            return;
        }
        order.setPendingClaim(Math.max(0, order.getPendingClaim() - claimed));
        // Remove fully completed & fully claimed orders.
        if (order.isComplete() && order.getPendingClaim() <= 0) {
            orders.remove(order.getId());
            storage.delete(order.getId());
        } else {
            storage.save(order);
        }
    }

    /**
     * Cancels an order: refunds reserved money for the unfulfilled remainder.
     * Any already-delivered but unclaimed items remain claimable, so the order
     * is only removed once nothing is pending.
     *
     * @return the refunded amount.
     */
    public double cancel(BuyOrder order) {
        if (order == null) {
            return 0;
        }
        double refund = order.getReserved();
        if (refund > 0) {
            economy.deposit(order.getOwner(), refund);
            order.setReserved(0);
        }
        // Prevent further fulfilment by marking it complete (filled = quantity).
        order.setFilled(order.getQuantity());
        if (order.getPendingClaim() <= 0) {
            orders.remove(order.getId());
            storage.delete(order.getId());
        } else {
            storage.save(order);
        }
        return refund;
    }
}
