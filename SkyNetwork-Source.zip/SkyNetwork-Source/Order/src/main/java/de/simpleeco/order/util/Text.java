package de.simpleeco.order.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Turns &-color-coded strings (with &#rrggbb hex) into Adventure Components.
 */
public final class Text {

    private static final LegacyComponentSerializer LEGACY =
            LegacyComponentSerializer.builder().character('&').hexColors().build();

    private static final Pattern HEX = Pattern.compile("&#([0-9A-Fa-f]{6})");
    /** Detects any legacy colour/format code so plain text can stay white. */
    private static final Pattern HAS_CODES =
            Pattern.compile("(?i)&#[0-9a-f]{6}|&[0-9a-fk-orx]");

    private Text() {
    }

    private static String preprocess(String input) {
        Matcher m = HEX.matcher(input);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            StringBuilder repl = new StringBuilder("&x");
            for (char c : m.group(1).toCharArray()) {
                repl.append('&').append(c);
            }
            m.appendReplacement(sb, repl.toString());
        }
        m.appendTail(sb);
        return sb.toString();
    }

    /** Colour codes are honoured when present - otherwise the text is plain white. */
    public static Component of(String legacy) { // WHITE_DEFAULT_MARKER
        if (legacy == null || legacy.isEmpty()) {
            return Component.empty();
        }
        if (!HAS_CODES.matcher(legacy).find()) {
            return Component.text(legacy, NamedTextColor.WHITE)
                    .decoration(TextDecoration.ITALIC, false);
        }
        return LEGACY.deserialize(preprocess(legacy)).decoration(TextDecoration.ITALIC, false);
    }

    public static Component italic(String legacy) {
        if (legacy == null || legacy.isEmpty()) {
            return Component.empty();
        }
        if (!HAS_CODES.matcher(legacy).find()) {
            return Component.text(legacy, NamedTextColor.WHITE)
                    .decoration(TextDecoration.ITALIC, true);
        }
        return LEGACY.deserialize(preprocess(legacy)).decoration(TextDecoration.ITALIC, true);
    }

    public static List<Component> lore(List<String> lines) {
        List<Component> out = new ArrayList<>();
        for (String line : lines) {
            out.add(of(line));
        }
        return out;
    }

    public static List<Component> loreItalic(List<String> lines) {
        List<Component> out = new ArrayList<>();
        for (String line : lines) {
            out.add(italic(line));
        }
        return out;
    }

    /** Strips &-codes and &#rrggbb for plain-text comparisons/titles. */
    public static String strip(String s) {
        return s.replaceAll("(?i)&#[0-9A-Fa-f]{6}", "").replaceAll("(?i)&[0-9A-FK-OR]", "");
    }
}
