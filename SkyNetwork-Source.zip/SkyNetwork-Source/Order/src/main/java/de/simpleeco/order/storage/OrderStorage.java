package de.simpleeco.order.storage;

import de.simpleeco.order.BuyOrder;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * SQLite persistence for buy orders. Orders are kept in memory by the
 * OrderManager; this class loads them on start and saves changes.
 */
public class OrderStorage {

    public record FulfilResult(BuyOrder order, int accepted) { }

    private final JavaPlugin plugin;
    private final File databaseFile;
    private Connection connection;

    public OrderStorage(JavaPlugin plugin, String fileName) {
        this.plugin = plugin;
        this.databaseFile = new File(plugin.getDataFolder(), fileName);
    }

    public void init() throws SQLException {
        File parent = databaseFile.getAbsoluteFile().getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) plugin.getLogger().warning("Could not create shared database folder: " + parent);
        connection = DriverManager.getConnection("jdbc:sqlite:" + databaseFile.getAbsolutePath());
        try (var pragma = connection.createStatement()) { pragma.execute("PRAGMA busy_timeout=10000"); pragma.execute("PRAGMA journal_mode=WAL"); }
        try (PreparedStatement ps = connection.prepareStatement(
                "CREATE TABLE IF NOT EXISTS orders (" +
                        "id TEXT PRIMARY KEY, " +
                        "owner TEXT NOT NULL, " +
                        "owner_name TEXT, " +
                        "material TEXT NOT NULL, " +
                        "quantity INTEGER NOT NULL, " +
                        "price REAL NOT NULL, " +
                        "created_at INTEGER NOT NULL, " +
                        "filled INTEGER NOT NULL, " +
                        "pending_claim INTEGER NOT NULL, " +
                        "reserved REAL NOT NULL, " +
                        "enchantments TEXT NOT NULL DEFAULT '')")) {
            ps.executeUpdate();
        }
        ensureEnchantmentsColumn();
    }

    /** Adds the new field to databases created by older plugin versions. */
    private void ensureEnchantmentsColumn() throws SQLException {
        boolean present = false;
        try (PreparedStatement ps = connection.prepareStatement("PRAGMA table_info(orders)");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                if ("enchantments".equalsIgnoreCase(rs.getString("name"))) {
                    present = true;
                    break;
                }
            }
        }
        if (!present) {
            try (PreparedStatement ps = connection.prepareStatement(
                    "ALTER TABLE orders ADD COLUMN enchantments TEXT NOT NULL DEFAULT ''")) {
                ps.executeUpdate();
            }
        }
    }

    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Error closing the database: " + e.getMessage());
        }
    }

    public List<BuyOrder> loadAll() {
        List<BuyOrder> out = new ArrayList<>();
        try (PreparedStatement ps = connection.prepareStatement("SELECT * FROM orders");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                BuyOrder order = fromRow(rs);
                if (order != null) out.add(order);
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Error loading orders: " + e.getMessage());
        }
        return out;
    }

    /** Serializes delivery claims through SQLite's immediate write transaction. */
    public synchronized FulfilResult fulfil(UUID id, int offer) {
        if (offer <= 0) return null;
        try (var tx = connection.createStatement()) {
            tx.execute("BEGIN IMMEDIATE");
            try {
                BuyOrder order;
                try (PreparedStatement ps = connection.prepareStatement("SELECT * FROM orders WHERE id=?")) {
                    ps.setString(1, id.toString());
                    try (ResultSet rs = ps.executeQuery()) { if (!rs.next()) { tx.execute("ROLLBACK"); return null; } order = fromRow(rs); }
                }
                if (order == null) { tx.execute("ROLLBACK"); return null; }
                int accepted = Math.min(offer, order.remaining());
                if (accepted <= 0) { tx.execute("COMMIT"); return new FulfilResult(order, 0); }
                order.setFilled(order.getFilled() + accepted);
                order.setPendingClaim(order.getPendingClaim() + accepted);
                order.setReserved(Math.max(0, order.getReserved() - accepted * order.getPricePerUnit()));
                try (PreparedStatement ps = connection.prepareStatement(
                        "UPDATE orders SET filled=?, pending_claim=?, reserved=? WHERE id=?")) {
                    ps.setInt(1, order.getFilled()); ps.setInt(2, order.getPendingClaim());
                    ps.setDouble(3, order.getReserved()); ps.setString(4, id.toString()); ps.executeUpdate();
                }
                tx.execute("COMMIT");
                return new FulfilResult(order, accepted);
            } catch (Exception e) {
                try { tx.execute("ROLLBACK"); } catch (SQLException ignored) { }
                throw e;
            }
        } catch (Exception e) {
            plugin.getLogger().warning("Could not fulfil order " + id + ": " + e.getMessage());
            return null;
        }
    }

    private BuyOrder fromRow(ResultSet rs) throws SQLException {
        Material mat = Material.matchMaterial(rs.getString("material").toUpperCase(Locale.ROOT));
        if (mat == null) return null;
        return new BuyOrder(UUID.fromString(rs.getString("id")), UUID.fromString(rs.getString("owner")),
                rs.getString("owner_name"), mat, rs.getInt("quantity"), rs.getDouble("price"),
                rs.getLong("created_at"), rs.getInt("filled"), rs.getInt("pending_claim"),
                rs.getDouble("reserved"), decodeEnchantments(rs.getString("enchantments")));
    }

    public void save(BuyOrder o) {
        try (PreparedStatement ps = connection.prepareStatement(
                "INSERT INTO orders (id, owner, owner_name, material, quantity, price, created_at, filled, pending_claim, reserved, enchantments) " +
                        "VALUES (?,?,?,?,?,?,?,?,?,?,?) " +
                        "ON CONFLICT(id) DO UPDATE SET filled=excluded.filled, " +
                        "pending_claim=excluded.pending_claim, reserved=excluded.reserved, " +
                        "owner_name=excluded.owner_name, enchantments=excluded.enchantments")) {
            ps.setString(1, o.getId().toString());
            ps.setString(2, o.getOwner().toString());
            ps.setString(3, o.getOwnerName());
            ps.setString(4, o.getMaterial().name());
            ps.setInt(5, o.getQuantity());
            ps.setDouble(6, o.getPricePerUnit());
            ps.setLong(7, o.getCreatedAt());
            ps.setInt(8, o.getFilled());
            ps.setInt(9, o.getPendingClaim());
            ps.setDouble(10, o.getReserved());
            ps.setString(11, encodeEnchantments(o.getEnchantments()));
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().warning("Error saving order " + o.getId() + ": " + e.getMessage());
        }
    }

    private String encodeEnchantments(Map<Enchantment, Integer> enchantments) {
        if (enchantments == null || enchantments.isEmpty()) return "";
        List<String> values = new ArrayList<>();
        enchantments.forEach((enchantment, level) -> {
            if (enchantment != null && level != null && level > 0) {
                values.add(enchantment.getKey().getKey() + "=" + level);
            }
        });
        return String.join(",", values);
    }

    private Map<Enchantment, Integer> decodeEnchantments(String encoded) {
        Map<Enchantment, Integer> out = new LinkedHashMap<>();
        if (encoded == null || encoded.isBlank()) return out;
        for (String token : encoded.split(",")) {
            String[] pair = token.trim().split("=", 2);
            if (pair.length != 2) continue;
            try {
                Enchantment enchantment = Enchantment.getByKey(NamespacedKey.minecraft(pair[0].trim()));
                int level = Integer.parseInt(pair[1].trim());
                if (enchantment != null && level > 0) out.put(enchantment, level);
            } catch (IllegalArgumentException ignored) {
                // Ignore old/custom data that cannot be resolved on this server.
            }
        }
        return out;
    }

    public void delete(UUID id) {
        try (PreparedStatement ps = connection.prepareStatement("DELETE FROM orders WHERE id = ?")) {
            ps.setString(1, id.toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().warning("Error deleting order " + id + ": " + e.getMessage());
        }
    }
}
