package de.simpleeco.order.gui;

import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Holder that identifies an Order GUI and carries its per-view state.
 */
public class OrderHolder implements InventoryHolder {

    public enum View { BOARD, MY_ORDERS, CREATE, FULFIL_INPUT, FULFIL_CONFIRM, ITEM_SELECTOR, COLLECT, SELL_CONFIRM }

    private final View view;
    private Inventory inventory;

    // BOARD / MY_ORDERS
    private final int page;
    private final OrderSort sort;

    // BOARD search filter (null/empty = no filter)
    private String searchFilter;

    // CREATE (draft state)
    private Material draftMaterial;
    private int draftQuantity;
    private double draftPrice;
    private final Map<Enchantment, Integer> draftEnchants = new LinkedHashMap<>();

    // ITEM_SELECTOR
    private int selectorPage;
    private String selectorFilter;
    // Draft carried through the selector so returning keeps the form state.
    private Material carriedMaterial;
    private int carriedQuantity;
    private double carriedPrice;
    private final Map<Enchantment, Integer> carriedEnchants = new LinkedHashMap<>();

    // FULFIL
    private final UUID targetOrderId;
    // Number of matching items the player put in (computed when opening confirm).
    private int deliverAmount;
    // Set true when the player clicks Confirm, so the close handler pays out
    // instead of returning items.
    private boolean confirmed;

    // FULFIL_CONFIRM: the emptied shulker boxes to hand back to the player only
    // AFTER the delivery is confirmed (so on cancel the full shulkers are returned).
    private final List<ItemStack> emptiedShulkers = new ArrayList<>();

    // COLLECT view: how many items were placed into the grid on the last render
    // (used to reconcile how many the owner took out on close), and the page.
    private int shownAmount;
    private int collectPage;
    // Set when the owner leaves COLLECT via the Sell-all button, so the close
    // handler does not re-claim the grid items (they are handled by the sell flow).
    private boolean suppressCollectClose;

    private OrderHolder(View view, int page, OrderSort sort, UUID targetOrderId) {
        this.view = view;
        this.page = page;
        this.sort = sort;
        this.targetOrderId = targetOrderId;
    }

    public static OrderHolder board(int page, OrderSort sort, String searchFilter) {
        OrderHolder h = new OrderHolder(View.BOARD, page, sort, null);
        h.searchFilter = searchFilter;
        return h;
    }

    public static OrderHolder myOrders(int page) {
        return new OrderHolder(View.MY_ORDERS, page, OrderSort.NEWEST, null);
    }

    public static OrderHolder create() {
        return new OrderHolder(View.CREATE, 0, OrderSort.NEWEST, null);
    }

    public static OrderHolder fulfilInput(UUID orderId) {
        return new OrderHolder(View.FULFIL_INPUT, 0, OrderSort.NEWEST, orderId);
    }

    public static OrderHolder fulfilConfirm(UUID orderId, int deliverAmount) {
        OrderHolder h = new OrderHolder(View.FULFIL_CONFIRM, 0, OrderSort.NEWEST, orderId);
        h.deliverAmount = deliverAmount;
        return h;
    }

    public static OrderHolder collect(UUID orderId) {
        return new OrderHolder(View.COLLECT, 0, OrderSort.NEWEST, orderId);
    }

    public static OrderHolder sellConfirm(UUID orderId, int deliverAmount) {
        OrderHolder h = new OrderHolder(View.SELL_CONFIRM, 0, OrderSort.NEWEST, orderId);
        h.deliverAmount = deliverAmount; // reused to carry the sell amount
        return h;
    }

    public static OrderHolder itemSelector(int selectorPage, String selectorFilter) {
        OrderHolder h = new OrderHolder(View.ITEM_SELECTOR, 0, OrderSort.NEWEST, null);
        h.selectorPage = selectorPage;
        h.selectorFilter = selectorFilter;
        return h;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @NotNull
    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public View getView() { return view; }
    public int getPage() { return page; }
    public OrderSort getSort() { return sort; }
    public UUID getTargetOrderId() { return targetOrderId; }

    public int getDeliverAmount() { return deliverAmount; }
    public void setDeliverAmount(int deliverAmount) { this.deliverAmount = deliverAmount; }

    public boolean isConfirmed() { return confirmed; }
    public void setConfirmed(boolean confirmed) { this.confirmed = confirmed; }

    public List<ItemStack> getEmptiedShulkers() { return emptiedShulkers; }

    public int getShownAmount() { return shownAmount; }
    public void setShownAmount(int shownAmount) { this.shownAmount = shownAmount; }

    public int getCollectPage() { return collectPage; }
    public void setCollectPage(int collectPage) { this.collectPage = collectPage; }

    public boolean isSuppressCollectClose() { return suppressCollectClose; }
    public void setSuppressCollectClose(boolean v) { this.suppressCollectClose = v; }

    public String getSearchFilter() { return searchFilter; }

    public Material getDraftMaterial() { return draftMaterial; }
    public void setDraftMaterial(Material draftMaterial) { this.draftMaterial = draftMaterial; }

    public int getDraftQuantity() { return draftQuantity; }
    public void setDraftQuantity(int draftQuantity) { this.draftQuantity = draftQuantity; }

    public double getDraftPrice() { return draftPrice; }
    public void setDraftPrice(double draftPrice) { this.draftPrice = draftPrice; }
    public Map<Enchantment, Integer> getDraftEnchants() { return draftEnchants; }
    public void setDraftEnchants(Map<Enchantment, Integer> enchants) {
        draftEnchants.clear();
        if (enchants != null) enchants.forEach((enchantment, level) -> {
            if (enchantment != null && level != null && level > 0) draftEnchants.put(enchantment, level);
        });
    }

    public int getSelectorPage() { return selectorPage; }
    public String getSelectorFilter() { return selectorFilter; }

    public Material getCarriedMaterial() { return carriedMaterial; }
    public void setCarriedMaterial(Material m) { this.carriedMaterial = m; }
    public int getCarriedQuantity() { return carriedQuantity; }
    public void setCarriedQuantity(int q) { this.carriedQuantity = q; }
    public double getCarriedPrice() { return carriedPrice; }
    public void setCarriedPrice(double p) { this.carriedPrice = p; }
    public Map<Enchantment, Integer> getCarriedEnchants() { return carriedEnchants; }
    public void setCarriedEnchants(Map<Enchantment, Integer> enchants) {
        carriedEnchants.clear();
        if (enchants != null) enchants.forEach((enchantment, level) -> {
            if (enchantment != null && level != null && level > 0) carriedEnchants.put(enchantment, level);
        });
    }
}
