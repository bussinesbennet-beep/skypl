package de.simpleeco.order.gui;

import de.simpleeco.order.BuyOrder;
import de.simpleeco.order.OrderManager;
import de.simpleeco.order.economy.EconomyBridge;
import de.simpleeco.order.util.SignInput;
import de.simpleeco.order.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Map;

/**
 * Handles all clicks in the order GUIs, including the sign-based search and the
 * sign-based quantity/price entry in the create flow.
 */
public class OrderListener implements Listener {

    private final org.bukkit.plugin.Plugin plugin;
    private final OrderManager manager;
    private final OrderGui gui;
    private final EconomyBridge economy;
    private final SignInput signInput;
    private final FileConfiguration config;
    private final de.simpleeco.order.StatStore stats;
    private final de.simpleeco.order.economy.PrefsBridge prefs;
    private final de.simpleeco.order.util.Sounds sounds;
    private final OrderEnchantDialog enchantDialog;

    public OrderListener(org.bukkit.plugin.Plugin plugin, OrderManager manager, OrderGui gui,
                         EconomyBridge economy, SignInput signInput, FileConfiguration config,
                         de.simpleeco.order.StatStore stats,
                         de.simpleeco.order.economy.PrefsBridge prefs,
                         de.simpleeco.order.util.Sounds sounds) {
        this.plugin = plugin;
        this.manager = manager;
        this.gui = gui;
        this.economy = economy;
        this.signInput = signInput;
        this.config = config;
        this.stats = stats;
        this.prefs = prefs;
        this.sounds = sounds;
        this.enchantDialog = new OrderEnchantDialog((org.bukkit.plugin.java.JavaPlugin) plugin);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (!(top.getHolder() instanceof OrderHolder holder)) {
            return;
        }
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        boolean clickedTop = event.getClickedInventory() != null && event.getClickedInventory().equals(top);

        switch (holder.getView()) {
            // View-only menus: the top inventory is view-only, but the player may
            // freely rearrange their OWN inventory. Clicks in the top are always
            // cancelled; bottom clicks are only cancelled if they'd push an item
            // up into the menu.
            case BOARD -> { if (cancelViewOnly(event, clickedTop)) return; if (clickedTop) { sounds.click(player); handleBoard(player, holder, event.getRawSlot(), event.getClick()); } }
            case MY_ORDERS -> { if (cancelViewOnly(event, clickedTop)) return; if (clickedTop) { sounds.click(player); handleMyOrders(player, holder, event.getRawSlot(), event.getClick()); } }
            case CREATE -> { if (cancelViewOnly(event, clickedTop)) return; if (clickedTop) { sounds.click(player); handleCreate(player, holder, event.getRawSlot()); } }
            case ITEM_SELECTOR -> { if (cancelViewOnly(event, clickedTop)) return; if (clickedTop) { sounds.click(player); handleSelector(player, holder, event.getRawSlot(), event.getClick()); } }
            case FULFIL_CONFIRM -> { if (cancelViewOnly(event, clickedTop)) return; if (clickedTop) { sounds.click(player); handleFulfilConfirm(player, holder, event.getRawSlot()); } }
            case SELL_CONFIRM -> { if (cancelViewOnly(event, clickedTop)) return; if (clickedTop) { sounds.click(player); handleSellConfirm(player, holder, event.getRawSlot()); } }
            // Drop-in chest: allow item movement, but empty filled shulkers on drop.
            case FULFIL_INPUT -> handleFulfilInput(player, holder, event);
            // Collect grid: allow taking items from the top rows; buttons on the bottom row.
            case COLLECT -> handleCollect(player, holder, event);
        }
    }

    /**
     * Cancels clicks for a view-only menu while still allowing the player to
     * rearrange their own inventory. Top-inventory clicks are always cancelled;
     * bottom-inventory clicks are only cancelled if the action would move an item
     * up into the (view-only) menu.
     *
     * @return true if the event was cancelled AND no further handling should run.
     */
    private boolean cancelViewOnly(InventoryClickEvent event, boolean clickedTop) {
        if (clickedTop) {
            event.setCancelled(true);
            return false; // let the top-slot button handler run
        }
        // Click in the player's own inventory.
        org.bukkit.event.inventory.InventoryAction action = event.getAction();
        if (action == org.bukkit.event.inventory.InventoryAction.MOVE_TO_OTHER_INVENTORY
                || action == org.bukkit.event.inventory.InventoryAction.COLLECT_TO_CURSOR
                || action == org.bukkit.event.inventory.InventoryAction.HOTBAR_MOVE_AND_READD
                || action == org.bukkit.event.inventory.InventoryAction.HOTBAR_SWAP
                || action == org.bukkit.event.inventory.InventoryAction.UNKNOWN) {
            event.setCancelled(true);
        }
        return true; // bottom click: never runs a button handler
    }

    @EventHandler
    public void onDrag(org.bukkit.event.inventory.InventoryDragEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (!(top.getHolder() instanceof OrderHolder holder)) {
            return;
        }
        // The drop-in chest allows any drag.
        if (holder.getView() == OrderHolder.View.FULFIL_INPUT) {
            return;
        }
        // The collect grid is TAKE-ONLY: any drag that touches the top inventory
        // (content rows or nav row) would add items into it, which reconciliation
        // could then count as claimable stock — a dupe. Block every drag that
        // touches the top; drags confined to the player's own inventory are fine.
        if (holder.getView() == OrderHolder.View.COLLECT) {
            for (int raw : event.getRawSlots()) {
                if (raw < OrderGui.COLLECT_SIZE) {
                    event.setCancelled(true);
                    return;
                }
            }
            return;
        }
        // All other (view-only) menus: only cancel drags that touch the top
        // inventory; drags confined to the player's own inventory are allowed.
        int topSize = top.getSize();
        for (int raw : event.getRawSlots()) {
            if (raw < topSize) {
                event.setCancelled(true);
                return;
            }
        }
    }

    // -------------------------------------------------------- BOARD

    private void handleBoard(Player player, OrderHolder holder, int slot, ClickType click) {
        switch (slot) {
            case OrderGui.B_MY -> gui.openMyOrders(player, 0);
            case OrderGui.B_CREATE -> gui.openCreate(player, null, 1, manager.getMinPrice());
            case OrderGui.B_REFRESH -> gui.openBoard(player, holder.getPage(), holder.getSort(), holder.getSearchFilter());
            case OrderGui.B_COMPASS -> gui.openBoard(player, holder.getPage(), holder.getSort().next(), holder.getSearchFilter());
            case OrderGui.B_PREV -> gui.openBoard(player, holder.getPage() - 1, holder.getSort(), holder.getSearchFilter());
            case OrderGui.B_NEXT -> gui.openBoard(player, holder.getPage() + 1, holder.getSort(), holder.getSearchFilter());
            case OrderGui.B_SEARCH -> {
                if (click.isRightClick()) {
                    gui.openBoard(player, 0, holder.getSort(), null); // clear filter
                } else {
                    OrderSort sort = holder.getSort();
                    promptSign(player, List.of("", "Search item", "----------"),
                            text -> gui.openBoard(player, 0, sort, text.isEmpty() ? null : text));
                }
            }
            default -> {
                if (slot >= 0 && slot < OrderGui.CONTENT_SLOTS) {
                    BuyOrder order = orderAtBoardSlot(holder, slot);
                    if (order == null) { sounds.deny(player); return; }
                    if (order.getOwner().equals(player.getUniqueId())) {
                        send(player, "messages.own-order");
                        sounds.deny(player);
                        return;
                    }
                    gui.openFulfilInput(player, order);
                }
            }
        }
    }

    private BuyOrder orderAtBoardSlot(OrderHolder holder, int slot) {
        java.util.List<BuyOrder> orders = new java.util.ArrayList<>(manager.openOrders());
        String filter = holder.getSearchFilter();
        if (filter != null && !filter.isEmpty()) {
            String f = filter.toLowerCase();
            orders.removeIf(o -> !gui.pretty(o.getMaterial()).toLowerCase().contains(f)
                    && !o.getMaterial().name().toLowerCase().contains(f));
        }
        orders.sort(holder.getSort().getComparator());
        int idx = holder.getPage() * OrderGui.CONTENT_SLOTS + slot;
        return idx < orders.size() ? orders.get(idx) : null;
    }

    // ---------------------------------------------------- MY ORDERS

    private void handleMyOrders(Player player, OrderHolder holder, int slot, ClickType click) {
        switch (slot) {
            case OrderGui.M_BACK -> gui.openBoard(player, 0, OrderSort.NEWEST, null);
            case OrderGui.M_CREATE -> gui.openCreate(player, null, 1, manager.getMinPrice());
            case OrderGui.M_PREV -> gui.openMyOrders(player, holder.getPage() - 1);
            case OrderGui.M_NEXT -> gui.openMyOrders(player, holder.getPage() + 1);
            default -> {
                if (slot >= 0 && slot < OrderGui.CONTENT_SLOTS) {
                    java.util.List<BuyOrder> orders = manager.ordersOf(player.getUniqueId());
                    int idx = holder.getPage() * OrderGui.CONTENT_SLOTS + slot;
                    if (idx >= orders.size()) return;
                    BuyOrder order = orders.get(idx);

                    if (click.isRightClick() && !order.isComplete()) {
                        double refund = manager.cancel(order);
                        send(player, "messages.cancelled", "refund", economy.format(refund));
                        sounds.success(player);
                        gui.openMyOrders(player, holder.getPage());
                    } else if (click.isLeftClick() && order.getPendingClaim() > 0) {
                        // Open the collect view where the owner can take, drop, or sell.
                        gui.openCollect(player, order, 0);
                    }
                }
            }
        }
    }

    private int leftoverAmount(Map<Integer, ItemStack> leftover) {
        int total = 0;
        for (ItemStack s : leftover.values()) total += s.getAmount();
        return total;
    }

    // ---------------------------------------------------- COLLECT (6 rows)

    /**
     * Clicks in the collect grid. The top 5 rows are real, takeable delivered
     * items; the bottom row holds the nav buttons (which are cancelled).
     */
    private void handleCollect(Player player, OrderHolder holder, InventoryClickEvent event) {
        int raw = event.getRawSlot();
        Inventory top = event.getView().getTopInventory();
        boolean clickedTop = event.getClickedInventory() != null && event.getClickedInventory().equals(top);

        // Bottom nav row (in the top inventory) -> buttons, always cancelled.
        if (clickedTop && raw >= OrderGui.COLLECT_CONTENT) {
            event.setCancelled(true);
            BuyOrder order = manager.get(holder.getTargetOrderId());
            if (order == null) { player.closeInventory(); return; }
            switch (raw) {
                case OrderGui.COL_BACK -> gui.openMyOrders(player, 0);
                case OrderGui.COL_PREV -> reopenCollect(player, holder, order, holder.getCollectPage() - 1);
                case OrderGui.COL_NEXT -> reopenCollect(player, holder, order, holder.getCollectPage() + 1);
                case OrderGui.COL_DROP_ALL -> dropAllCollect(player, holder, order, top);
                case OrderGui.COL_SELL_ALL -> {
                    if (!gui.worth().canSell(order.getMaterial())) return;
                    // First reconcile what is currently in the grid, then open sell confirm
                    // for the FULL pending amount.
                    reconcileCollect(player, holder, order, top);
                    holder.setSuppressCollectClose(true);
                    int pending = order.getPendingClaim();
                    if (pending <= 0) { gui.openMyOrders(player, 0); return; }
                    Bukkit.getScheduler().runTaskLater(plugin, () -> {
                        if (player.isOnline()) gui.openSellConfirm(player, order, pending);
                    }, 1L);
                }
                default -> { /* empty nav slot */ }
            }
            return;
        }

        // Double-click-collect could pull from nav slots or gather across the
        // whole window; cancel it outright.
        if (event.getClick() == ClickType.DOUBLE_CLICK) {
            event.setCancelled(true);
            return;
        }

        // A shift-click in the player's OWN inventory would move an item UP into
        // the collect grid, where reconciliation would then count it as
        // "delivered stock" the player could claim/sell — an item-creation dupe.
        // Block any shift move-to-other-inventory that originates below.
        if (!clickedTop && event.isShiftClick()) {
            event.setCancelled(true);
            return;
        }

        // Placing/adding items into the top grid from the cursor is also blocked:
        // the grid is take-only. We allow taking OUT (pickup/half/one from a top
        // slot into an empty cursor) but never putting IN.
        if (clickedTop && putsItemIntoTop(event)) {
            event.setCancelled(true);
            return;
        }
        // All other clicks (taking items from the grid, moving within own inv) are allowed.
    }

    /**
     * @return true if this click would ADD items to the clicked top-inventory
     * slot (place cursor, swap non-empty cursor, hotbar-swap a held item in,
     * etc.). Taking items out (empty cursor picking up, or number-key when the
     * hotbar slot is empty) returns false.
     */
    private boolean putsItemIntoTop(InventoryClickEvent event) {
        ItemStack cursor = event.getCursor();
        boolean cursorHasItem = cursor != null && cursor.getType() != Material.AIR;
        switch (event.getAction()) {
            case PLACE_ALL, PLACE_ONE, PLACE_SOME, SWAP_WITH_CURSOR -> {
                return true;
            }
            case HOTBAR_SWAP, HOTBAR_MOVE_AND_READD -> {
                // Moving a hotbar item into the slot only adds if that hotbar slot
                // currently holds something.
                int btn = event.getHotbarButton();
                if (btn >= 0) {
                    ItemStack hb = event.getWhoClicked().getInventory().getItem(btn);
                    return hb != null && hb.getType() != Material.AIR;
                }
                return true;
            }
            case COLLECT_TO_CURSOR -> {
                return cursorHasItem; // gathers matching items across the window
            }
            default -> {
                return false;
            }
        }
    }

    private void reopenCollect(Player player, OrderHolder holder, BuyOrder order, int page) {
        // Reconcile the current page first so counts stay correct, then reopen.
        reconcileCollect(player, holder, order, holder.getInventory());
        holder.setSuppressCollectClose(true);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline()) gui.openCollect(player, order, page);
        }, 1L);
    }

    private void dropAllCollect(Player player, OrderHolder holder, BuyOrder order, Inventory top) {
        // Count what's currently in the grid, drop it all in front of the player,
        // and reduce the pending-claim by that amount.
        int inGrid = 0;
        for (int i = 0; i < OrderGui.COLLECT_CONTENT; i++) {
            ItemStack s = top.getItem(i);
            if (gui.matchesOrderItem(s, order)) {
                inGrid += s.getAmount();
                top.setItem(i, null);
            }
        }
        if (inGrid <= 0) return;
        holder.setShownAmount(0);
        manager.claim(order, inGrid);
        final int toDrop = inGrid;
        int maxStack = order.getMaterial().getMaxStackSize();
        int remaining = toDrop;
        while (remaining > 0) {
            int give = Math.min(maxStack, remaining);
            dropFromPlayer(player, order.buildItemStack(give));
            remaining -= give;
        }
        send(player, "messages.dropped-items", "count", String.valueOf(toDrop));

        // Refresh the collect view (there may be more pending on further pages).
        BuyOrder refreshed = manager.get(holder.getTargetOrderId());
        holder.setSuppressCollectClose(true);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) return;
            if (refreshed != null && refreshed.getPendingClaim() > 0) {
                gui.openCollect(player, refreshed, 0);
            } else {
                gui.openMyOrders(player, 0);
            }
        }, 1L);
    }

    /**
     * Reconciles the collect grid with the order's pending-claim count: whatever
     * the owner removed from the grid is marked claimed. Any items still in the
     * grid remain pending. Called on page change, sell, and on close.
     */
    private void reconcileCollect(Player player, OrderHolder holder, BuyOrder order, Inventory top) {
        if (top == null) return;
        int stillInGrid = 0;
        for (int i = 0; i < OrderGui.COLLECT_CONTENT; i++) {
            ItemStack s = top.getItem(i);
            if (gui.matchesOrderItem(s, order)) {
                stillInGrid += s.getAmount();
            }
        }
        int taken = holder.getShownAmount() - stillInGrid;
        if (taken > 0) {
            manager.claim(order, taken);
        }
        holder.setShownAmount(stillInGrid);
    }

    // ---------------------------------------------------- SELL CONFIRM

    private void handleSellConfirm(Player player, OrderHolder holder, int slot) {
        BuyOrder order = manager.get(holder.getTargetOrderId());
        if (order == null) { player.closeInventory(); return; }
        if (slot == OrderGui.SC_CONFIRM) {
            int amount = Math.min(holder.getDeliverAmount(), order.getPendingClaim());
            if (amount <= 0 || !gui.worth().canSell(order.getMaterial())) {
                player.closeInventory();
                return;
            }
            double total = gui.worth().unitPrice(order.getMaterial()) * amount;
            manager.claim(order, amount);            // consume the pending items
            economy.deposit(player.getUniqueId(), total);
            send(player, "messages.sold-collected",
                    "count", String.valueOf(amount),
                    "total", economy.format(total));
            sounds.success(player);
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (player.isOnline()) gui.openMyOrders(player, 0);
            }, 1L);
        } else if (slot == OrderGui.SC_BACK) {
            // Go back to the collect view.
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (player.isOnline() && order.getPendingClaim() > 0) gui.openCollect(player, order, 0);
                else if (player.isOnline()) gui.openMyOrders(player, 0);
            }, 1L);
        }
    }

    /**
     * Runs the actual collect-and-sell for a confirmed amount. Called from the
     * native sell-confirmation dialog.
     */
    public void confirmCollectSell(Player player, BuyOrder order, int amount) {
        if (order == null) {
            return;
        }
        int claimed = Math.min(amount, order.getPendingClaim());
        if (claimed <= 0 || !gui.worth().canSell(order.getMaterial())) {
            return;
        }
        double total = gui.worth().unitPrice(order.getMaterial()) * claimed;
        manager.claim(order, claimed);            // consume the pending items
        economy.deposit(player.getUniqueId(), total);
        send(player, "messages.sold-collected",
                "count", String.valueOf(claimed),
                "total", economy.format(total));
        sounds.success(player);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline()) gui.openMyOrders(player, 0);
        }, 1L);
    }

    // ------------------------------------------------------- CREATE (3 rows)

    private void handleCreate(Player player, OrderHolder holder, int slot) {
        switch (slot) {
            case OrderGui.CR_MATERIAL ->
                    gui.openItemSelector(player, holder, 0, null);
            case OrderGui.CR_QUANTITY -> {
                Material mat = holder.getDraftMaterial();
                int q = holder.getDraftQuantity();
                double p = holder.getDraftPrice();
                Map<Enchantment, Integer> enchants = Map.copyOf(holder.getDraftEnchants());
                promptSign(player, List.of("", "Enter amount", "----------"), text -> {
                    double parsed = de.simpleeco.order.util.NumberUtil.parse(text);
                    int value = Double.isNaN(parsed) ? q : (int) Math.floor(parsed);
                    int clamped = Math.max(1, Math.min(manager.effectiveMaxQuantity(), value));
                    gui.openCreate(player, mat, clamped, p, enchants);
                });
            }
            case OrderGui.CR_PRICE -> {
                Material mat = holder.getDraftMaterial();
                int q = holder.getDraftQuantity();
                double p = holder.getDraftPrice();
                Map<Enchantment, Integer> enchants = Map.copyOf(holder.getDraftEnchants());
                promptSign(player, List.of("", "Enter price", "----------"), text -> {
                    double parsed = de.simpleeco.order.util.NumberUtil.parse(text);
                    double value = Double.isNaN(parsed) ? p : Math.floor(parsed);
                    double clamped = Math.max(manager.getMinPrice(), Math.min(manager.getMaxPrice(), value));
                    gui.openCreate(player, mat, q, clamped, enchants);
                });
            }
            case OrderGui.CR_CONFIRM -> confirmCreate(player, holder);
            case OrderGui.CR_BACK -> gui.openBoard(player, 0, OrderSort.NEWEST, null);
            default -> { /* ignore */ }
        }
    }

    private void confirmCreate(Player player, OrderHolder holder) {
        if (holder.getDraftMaterial() == null || holder.getDraftMaterial() == Material.AIR) {
            send(player, "messages.invalid");
            sounds.deny(player);
            return;
        }
        OrderManager.CreateResult result = manager.create(player,
                holder.getDraftMaterial(), holder.getDraftQuantity(), holder.getDraftPrice(),
                holder.getDraftEnchants());
        switch (result) {
            case OK -> {
                if (stats != null) {
                    stats.add(player.getUniqueId(),
                            de.simpleeco.order.PlaceholderHook.KEY_SPENT,
                            holder.getDraftQuantity() * holder.getDraftPrice());
                }
                send(player, "messages.created",
                        "amount", String.valueOf(holder.getDraftQuantity()),
                        "item", gui.pretty(holder.getDraftMaterial()),
                        "price", economy.format(holder.getDraftPrice()));
                sounds.success(player);
                gui.openMyOrders(player, 0);
            }
            case LIMIT_REACHED -> {
                send(player, "messages.limit-reached",
                        "limit", String.valueOf(manager.limitFor(player)));
                sounds.deny(player);
            }
            case NO_MONEY -> {
                send(player, "messages.not-enough-money",
                        "total", economy.format(holder.getDraftQuantity() * holder.getDraftPrice()),
                        "balance", economy.format(economy.getBalance(player.getUniqueId())));
                sounds.deny(player);
            }
            case ECON_MISSING -> {
                send(player, "messages.economy-missing");
                sounds.deny(player);
            }
            case INVALID -> {
                send(player, "messages.invalid");
                sounds.deny(player);
            }
        }
    }

    // ------------------------------------------------ ITEM SELECTOR (6 rows)

    private void handleSelector(Player player, OrderHolder holder, int slot, ClickType click) {
        Material carriedMat = holder.getCarriedMaterial();
        int carriedQ = Math.max(1, holder.getCarriedQuantity());
        double carriedP = holder.getCarriedPrice() < manager.getMinPrice()
                ? manager.getMinPrice() : holder.getCarriedPrice();
        Map<Enchantment, Integer> carriedEnchants = Map.copyOf(holder.getCarriedEnchants());

        switch (slot) {
            case OrderGui.SEL_BACK ->
                    gui.openCreate(player, carriedMat, carriedQ, carriedP, carriedEnchants);
            case OrderGui.SEL_PREV ->
                    gui.openItemSelector(player, carryHolder(holder), holder.getSelectorPage() - 1, holder.getSelectorFilter());
            case OrderGui.SEL_NEXT ->
                    gui.openItemSelector(player, carryHolder(holder), holder.getSelectorPage() + 1, holder.getSelectorFilter());
            case OrderGui.SEL_SEARCH -> {
                if (click.isRightClick()) {
                    gui.openItemSelector(player, carryHolder(holder), 0, null);
                } else {
                    OrderHolder carried = carryHolder(holder);
                    promptSign(player, List.of("", "Search item", "----------"),
                            text -> gui.openItemSelector(player, carried, 0, text.isEmpty() ? null : text));
                }
            }
            default -> {
                if (slot >= 0 && slot < OrderGui.CONTENT_SLOTS) {
                    List<Material> items = gui.selectorItemsFor(holder);
                    int idx = holder.getSelectorPage() * OrderGui.CONTENT_SLOTS + slot;
                    if (idx < items.size()) {
                        Material chosen = items.get(idx);
                        if (chosen == Material.DIAMOND_SWORD || chosen == Material.DIAMOND_PICKAXE) {
                            Map<Enchantment, Integer> initial = chosen == carriedMat
                                    ? carriedEnchants : Map.of();
                            OrderHolder returnState = carryHolder(holder);
                            player.closeInventory();
                            de.simpleeco.order.util.DialogUi.runNextTick(
                                    (org.bukkit.plugin.java.JavaPlugin) plugin,
                                    () -> enchantDialog.open(player, chosen, initial,
                                            selected -> gui.openCreate(player, chosen, carriedQ, carriedP, selected),
                                            () -> gui.openItemSelector(player, returnState,
                                                    holder.getSelectorPage(), holder.getSelectorFilter())));
                        } else {
                            gui.openCreate(player, chosen, carriedQ, carriedP, Map.of());
                        }
                    }
                }
            }
        }
    }

    /** Wraps a selector holder's carried draft into a create-style holder for reopening. */
    private OrderHolder carryHolder(OrderHolder selector) {
        OrderHolder h = OrderHolder.create();
        h.setDraftMaterial(selector.getCarriedMaterial());
        h.setDraftQuantity(selector.getCarriedQuantity());
        h.setDraftPrice(selector.getCarriedPrice());
        h.setDraftEnchants(selector.getCarriedEnchants());
        return h;
    }

    // ------------------------------------------------ FULFIL INPUT (drop-in chest)

    /**
     * Handles clicks in the drop-in chest. Item movement is fully allowed: the
     * player drops matching items or filled shulker boxes in and leaves them
     * there. Shulkers are only emptied when the delivery is CONFIRMED (see the
     * close/confirm handling), so cancelling returns the full shulker untouched.
     */
    private void handleFulfilInput(Player player, OrderHolder holder, InventoryClickEvent event) {
        BuyOrder order = manager.get(holder.getTargetOrderId());
        if (order == null) {
            event.setCancelled(true);
        }
        // Otherwise allow the item to settle in the chest; nothing else to do.
    }

    private boolean isShulkerBox(Material m) {
        return m == Material.SHULKER_BOX || m.name().endsWith("_SHULKER_BOX");
    }

    /**
     * Extracts all matching items from a shulker box, leaving non-matching
     * contents inside. Returns the number extracted and mutates the passed
     * stack's meta so it becomes the emptied box (matching slots cleared).
     */
    private int extractMatchingFromShulker(ItemStack shulker, BuyOrder order) {
        if (!(shulker.getItemMeta() instanceof org.bukkit.inventory.meta.BlockStateMeta bsm)) {
            return 0;
        }
        if (!(bsm.getBlockState() instanceof org.bukkit.block.ShulkerBox box)) {
            return 0;
        }
        int extracted = 0;
        ItemStack[] contents = box.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack inner = contents[i];
            if (gui.matchesOrderItem(inner, order)) {
                extracted += inner.getAmount();
                contents[i] = null;
            }
        }
        if (extracted > 0) {
            box.getInventory().setContents(contents);
            bsm.setBlockState(box);
            shulker.setItemMeta(bsm);
        }
        return extracted;
    }

    // ------------------------------------------------ FULFIL CONFIRM

    private void handleFulfilConfirm(Player player, OrderHolder holder, int slot) {
        if (slot == OrderGui.FC_CONFIRM_RIGHT) {
            holder.setConfirmed(true);
            // The actual payout & item consumption happens in onClose (single path).
            player.closeInventory();
        } else if (slot == OrderGui.FC_CONFIRM_LEFT) {
            // Decline: close without confirming; onClose returns the escrowed items.
            holder.setConfirmed(false);
            player.closeInventory();
        }
    }

    // ------------------------------------------------ CLOSE HANDLING

    @EventHandler
    public void onClose(org.bukkit.event.inventory.InventoryCloseEvent event) {
        Inventory top = event.getInventory();
        if (!(top.getHolder() instanceof OrderHolder holder)) {
            return;
        }
        if (!(event.getPlayer() instanceof Player player)) {
            return;
        }

        try {
            if (holder.getView() == OrderHolder.View.FULFIL_INPUT) {
                onCloseFulfilInput(player, holder, top);
            } else if (holder.getView() == OrderHolder.View.FULFIL_CONFIRM) {
                onCloseFulfilConfirm(player, holder);
            } else if (holder.getView() == OrderHolder.View.COLLECT) {
                onCloseCollect(player, holder, top);
            }
        } catch (Exception ex) {
            plugin.getLogger().warning("Error while handling Order GUI close: " + ex);
            ex.printStackTrace();
        }
    }

    /** When the drop-in chest closes: count matching items and open the confirm view. */
    private void onCloseFulfilInput(Player player, OrderHolder holder, Inventory chest) {
        BuyOrder order = manager.get(holder.getTargetOrderId());
        holder.getEmptiedShulkers().clear();

        // Collect matching items (loose stacks + inside filled shulkers) and
        // return everything non-matching to the player.
        int matching = 0;
        for (int slot = 0; slot < chest.getSize(); slot++) {
            ItemStack stack = chest.getItem(slot);
            if (stack == null || stack.getType() == Material.AIR) {
                continue;
            }
            if (order != null && gui.matchesOrderItem(stack, order)) {
                // Loose matching stack.
                matching += stack.getAmount();
                chest.setItem(slot, null);
            } else if (order != null && isShulkerBox(stack.getType())) {
                // Filled shulker: pull out matching items; keep the emptied box in
                // escrow to return only if the delivery is confirmed. If nothing
                // matched, return the whole shulker now.
                ItemStack box = stack.clone();
                int extracted = extractMatchingFromShulker(box, order);
                chest.setItem(slot, null);
                if (extracted > 0) {
                    matching += extracted;
                    box.setAmount(1);
                    holder.getEmptiedShulkers().add(box);
                } else {
                    giveBackStack(player, stack);
                }
            } else {
                // Return non-matching items to the player.
                giveBackStack(player, stack);
                chest.setItem(slot, null);
            }
        }

        if (order == null) {
            // Order vanished while the chest was open.
            send(player, "messages.order-gone");
            return;
        }

        // Cap at what the order still needs; return the surplus.
        int deliver = Math.min(matching, order.remaining());
        int surplus = matching - deliver;
        if (surplus > 0) {
            giveBack(player, order, surplus);
        }

        if (deliver <= 0) {
            if (matching > 0) {
                send(player, "messages.order-gone");
            }
            return;
        }

        // Stash the deliver amount (as items already removed from the chest) and
        // open the confirmation. We hold the items "in escrow" by having removed
        // them from the chest; the confirm-close path either pays out or refunds.
        final int deliverFinal = deliver;
        final List<ItemStack> emptied = new java.util.ArrayList<>(holder.getEmptiedShulkers());
        holder.getEmptiedShulkers().clear();
        // Open the confirm view a tick LATER: opening an inventory during (or at
        // the very start of the tick after) an InventoryCloseEvent is silently
        // ignored by the server, so we delay by 1 tick to reliably show it.
        boolean wantConfirm = prefs.get(player.getUniqueId(),
                de.simpleeco.economy.api.SimplePrefsAPI.KEY_ORDER_CONFIRM, true);
        if (!wantConfirm) {
            // Confirmation disabled: pay out immediately without the confirm view.
            fulfilNow(player, order, deliverFinal, emptied);
            return;
        }
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) {
                // Player left before confirming: return their items + shulkers.
                giveBack(player, order, deliverFinal);
                for (ItemStack box : emptied) giveBackStack(player, box);
                return;
            }
            gui.openFulfilConfirm(player, order, deliverFinal, emptied);
        }, 1L);
    }

    /**
     * Completes a delivery without a confirmation screen (used when the player
     * disabled the order-confirm toggle). Mirrors the confirmed branch of
     * {@link #onCloseFulfilConfirm}.
     */
    private void fulfilNow(Player player, BuyOrder order, int amount, List<ItemStack> emptied) {
        int accepted = manager.fulfil(order, player, amount);
        if (accepted < amount) {
            giveBack(player, order, amount - accepted);
        }
        for (ItemStack box : emptied) {
            giveBackStack(player, box);
        }
        if (accepted > 0 && stats != null) {
            stats.add(player.getUniqueId(),
                    de.simpleeco.order.PlaceholderHook.KEY_EARNED,
                    accepted * order.getPricePerUnit());
        }
        if (accepted > 0) {
            send(player, "messages.fulfilled-some",
                    "amount", String.valueOf(accepted),
                    "item", gui.pretty(order.getMaterial()),
                    "earned", economy.format(accepted * order.getPricePerUnit()));
        }
    }

    /** When the confirm view closes: pay out if confirmed, otherwise return items. */
    private void onCloseFulfilConfirm(Player player, OrderHolder holder) {
        BuyOrder order = manager.get(holder.getTargetOrderId());
        int amount = holder.getDeliverAmount();
        if (amount <= 0) {
            return;
        }
        if (order == null) {
            // Order vanished: give the items back.
            send(player, "messages.order-gone");
            return;
        }

        if (holder.isConfirmed()) {
            int accepted = manager.fulfil(order, player, amount);
            if (accepted < amount) {
                giveBack(player, order, amount - accepted);
            }
            // Delivery went through -> hand back the now-empty shulker boxes.
            for (ItemStack box : holder.getEmptiedShulkers()) {
                giveBackStack(player, box);
            }
            holder.getEmptiedShulkers().clear();
            if (accepted > 0 && stats != null) {
                stats.add(player.getUniqueId(),
                        de.simpleeco.order.PlaceholderHook.KEY_EARNED,
                        accepted * order.getPricePerUnit());
            }
            if (accepted > 0) {
                send(player, "messages.fulfilled-some",
                        "amount", String.valueOf(accepted),
                        "item", gui.pretty(order.getMaterial()),
                        "earned", economy.format(accepted * order.getPricePerUnit()));
            }
        } else {
            // Not confirmed -> return the escrowed items and the emptied shulkers
            // (same total contents the player put in).
            giveBack(player, order, amount);
            for (ItemStack box : holder.getEmptiedShulkers()) {
                giveBackStack(player, box);
            }
            holder.getEmptiedShulkers().clear();
        }
    }

    /**
     * When the collect view closes: whatever the owner took out of the grid is
     * marked claimed; anything still in the grid stays pending (it is not lost,
     * it remains claimable next time). Skipped when the close was triggered by
     * us navigating to another Order view (suppress flag).
     */
    private void onCloseCollect(Player player, OrderHolder holder, Inventory top) {
        if (holder.isSuppressCollectClose()) {
            holder.setSuppressCollectClose(false);
            return;
        }
        BuyOrder order = manager.get(holder.getTargetOrderId());
        if (order == null) {
            return;
        }
        reconcileCollect(player, holder, order, top);
    }

    private void giveBackStack(Player player, ItemStack stack) {
        Map<Integer, ItemStack> leftover = player.getInventory().addItem(stack);
        for (ItemStack left : leftover.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), left);
        }
    }

    private void giveBack(Player player, BuyOrder order, int amount) {
        int maxStack = order.getMaterial().getMaxStackSize();
        int remaining = amount;
        while (remaining > 0) {
            int give = Math.min(maxStack, remaining);
            Map<Integer, ItemStack> leftover = player.getInventory().addItem(order.buildItemStack(give));
            for (ItemStack left : leftover.values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), left);
            }
            remaining -= give;
        }
    }

    // ------------------------------------------------------- HELPERS

    /**
     * Asks for a value in a native dialog text field (formerly a sign).
     *
     * @param initial list whose element 0 is the pre-filled text and element 1
     *                the label shown above the input box
     */
    private void promptSign(Player player, List<String> initial, java.util.function.Consumer<String> onDone) {
        String start = initial.isEmpty() ? "" : initial.get(0);
        String titleText = initial.size() > 1 ? initial.get(1) : "Enter value";

        Bukkit.getScheduler().runTask(plugin, () -> {
            player.closeInventory();
            de.simpleeco.order.util.DialogUi.input(
                    de.simpleeco.order.util.DialogUi.self("Order"), player,
                    de.simpleeco.order.util.DialogUi.title(titleText),
                    List.of(de.simpleeco.order.util.DialogUi.muted(
                            "Type the value, then press Continue")),
                    "value", titleText, start, 32,
                    "Continue", "Cancel",
                    (p, typed) -> onDone.accept(typed == null ? "" : typed.trim()),
                    null);
        });
    }

    private net.kyori.adventure.text.Component msg(String path, String... repl) {
        String text = config.getString("messages.prefix", "") + config.getString(path, "");
        for (int i = 0; i + 1 < repl.length; i += 2) {
            text = text.replace("{" + repl[i] + "}", repl[i + 1]);
        }
        return Text.of(text);
    }

    /**
     * Sends a chat message only if it is enabled. Each message can be toggled in
     * config under {@code message-toggles.<key>} (default true), where {@code key}
     * is the part after "messages." (e.g. "dropped-items"). This lets server
     * owners silence individual messages.
     */
    private void send(Player player, String path, String... repl) {
        String key = path.startsWith("messages.") ? path.substring("messages.".length()) : path;
        if (!config.getBoolean("message-toggles." + key, true)) {
            return;
        }
        String translated = de.simpleeco.order.util.CoreI18n.translate(player, "order." + key, repl);
        net.kyori.adventure.text.Component component;
        if (translated != null) {
            component = Text.of(config.getString("messages.prefix", "") + translated);
        } else {
            String raw = config.getString(path, "");
            if (raw == null || raw.isEmpty()) {
                return;
            }
            component = msg(path, repl);
        }
        java.util.UUID id = player.getUniqueId();
        if (!prefs.get(id, de.simpleeco.economy.api.SimplePrefsAPI.KEY_ORDER_ALERTS, true)) return;
        if (prefs.get(id, de.simpleeco.economy.api.SimplePrefsAPI.KEY_SERVER_CHAT_MESSAGES, true)
                && prefs.get(id, de.simpleeco.economy.api.SimplePrefsAPI.KEY_CHAT_MESSAGES, true)) {
            player.sendMessage(component);
        }
        if (prefs.get(id, de.simpleeco.economy.api.SimplePrefsAPI.KEY_HOTBAR_MESSAGES, true)) {
            player.sendActionBar(component);
        }
        if (prefs.get(id, de.simpleeco.economy.api.SimplePrefsAPI.KEY_GUI_SOUNDS, true)) {
            player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_NOTE_BLOCK_PLING, 0.35f, 1.65f);
        }
    }

    /** Drops an item in the direction the player is looking, like a normal Q-drop. */
    private void dropFromPlayer(Player player, ItemStack stack) {
        org.bukkit.Location loc = player.getEyeLocation();
        org.bukkit.entity.Item item = player.getWorld().dropItem(loc, stack);
        item.setPickupDelay(40);
        org.bukkit.util.Vector dir = loc.getDirection().normalize().multiply(0.35);
        dir.setY(dir.getY() + 0.1);
        item.setVelocity(dir);
    }
}
