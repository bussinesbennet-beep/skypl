package de.simpleeco.order.economy;

import de.simpleeco.economy.api.SimpleEconomyAPI;
import de.simpleeco.economy.api.SimpleStatsAPI;
import org.bukkit.Bukkit;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.UUID;

/**
 * Bridges to SimpleEconomy for Dollar handling. Also records the "order spent"
 * and "order earned" suite statistics via the optional SimpleStatsAPI.
 */
public class EconomyBridge {

    private final JavaPlugin plugin;
    private SimpleEconomyAPI dollars;
    private SimpleStatsAPI stats;

    public EconomyBridge(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void resolve() {
        RegisteredServiceProvider<SimpleEconomyAPI> d =
                Bukkit.getServicesManager().getRegistration(SimpleEconomyAPI.class);
        dollars = d != null ? d.getProvider() : null;
        if (dollars == null) {
            plugin.getLogger().warning("SimpleEconomy not found - orders are disabled.");
        }
        try {
            RegisteredServiceProvider<SimpleStatsAPI> s =
                    Bukkit.getServicesManager().getRegistration(SimpleStatsAPI.class);
            stats = s != null ? s.getProvider() : null;
        } catch (Throwable t) {
            stats = null;
        }
    }

    /** Records Dollars spent creating a buy order. */
    public void recordOrderSpent(UUID owner, double amount) {
        if (stats != null) {
            stats.add(owner, SimpleStatsAPI.KEY_ORDER_SPENT, amount);
        }
    }

    /** Records Dollars earned fulfilling a buy order. */
    public void recordOrderEarned(UUID fulfiller, double amount) {
        if (stats != null) {
            stats.add(fulfiller, SimpleStatsAPI.KEY_ORDER_EARNED, amount);
        }
    }

    public boolean isAvailable() {
        return dollars != null;
    }

    public double getBalance(UUID uuid) {
        return dollars != null ? dollars.getBalance(uuid) : 0;
    }

    public boolean has(UUID uuid, double amount) {
        return dollars != null && dollars.has(uuid, amount);
    }

    public boolean withdraw(UUID uuid, double amount) {
        return dollars != null && dollars.withdraw(uuid, amount);
    }

    public void deposit(UUID uuid, double amount) {
        if (dollars != null) {
            dollars.deposit(uuid, amount);
        }
    }

    public String format(double amount) {
        return dollars != null ? dollars.format(amount) : ("$" + amount);
    }

    public String symbol() {
        return dollars != null ? dollars.getCurrencySymbol() : "$";
    }
}
