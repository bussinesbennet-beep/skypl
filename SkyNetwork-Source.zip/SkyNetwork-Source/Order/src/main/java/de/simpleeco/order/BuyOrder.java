package de.simpleeco.order;

import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/**
 * A single buy order: "I buy {quantity}x {item} at {pricePerUnit} each".
 * Enchantment requirements are stored with the order so fulfilment and claiming
 * use the exact same item variant after a restart.
 */
public class BuyOrder {

    private final UUID id;
    private final UUID owner;
    private final String ownerName;
    private final Material material;
    private final int quantity;
    private final double pricePerUnit;
    private final long createdAt;
    private final Map<Enchantment, Integer> enchantments = new LinkedHashMap<>();

    private int filled;
    private int pendingClaim;
    private double reserved;

    /** Backwards-compatible constructor for plain-material orders. */
    public BuyOrder(UUID id, UUID owner, String ownerName, Material material,
                    int quantity, double pricePerUnit, long createdAt,
                    int filled, int pendingClaim, double reserved) {
        this(id, owner, ownerName, material, quantity, pricePerUnit, createdAt,
                filled, pendingClaim, reserved, Map.of());
    }

    public BuyOrder(UUID id, UUID owner, String ownerName, Material material,
                    int quantity, double pricePerUnit, long createdAt,
                    int filled, int pendingClaim, double reserved,
                    Map<Enchantment, Integer> enchantments) {
        this.id = id;
        this.owner = owner;
        this.ownerName = ownerName;
        this.material = material;
        this.quantity = quantity;
        this.pricePerUnit = pricePerUnit;
        this.createdAt = createdAt;
        this.filled = filled;
        this.pendingClaim = pendingClaim;
        this.reserved = reserved;
        setEnchantments(enchantments);
    }

    /** Convenience constructor for a fresh plain-material order. */
    public static BuyOrder create(UUID owner, String ownerName, Material material,
                                  int quantity, double pricePerUnit) {
        return create(owner, ownerName, material, quantity, pricePerUnit, Map.of());
    }

    /** Convenience constructor for a fresh order, including optional enchants. */
    public static BuyOrder create(UUID owner, String ownerName, Material material,
                                  int quantity, double pricePerUnit,
                                  Map<Enchantment, Integer> enchantments) {
        return new BuyOrder(UUID.randomUUID(), owner, ownerName, material, quantity,
                pricePerUnit, System.currentTimeMillis(), 0, 0,
                quantity * pricePerUnit, enchantments);
    }

    private void setEnchantments(Map<Enchantment, Integer> values) {
        enchantments.clear();
        if (values != null) values.forEach((enchantment, level) -> {
            if (enchantment != null && level != null && level > 0) enchantments.put(enchantment, level);
        });
    }

    public UUID getId() { return id; }
    public UUID getOwner() { return owner; }
    public String getOwnerName() { return ownerName; }
    public Material getMaterial() { return material; }
    public int getQuantity() { return quantity; }
    public double getPricePerUnit() { return pricePerUnit; }
    public long getCreatedAt() { return createdAt; }
    public Map<Enchantment, Integer> getEnchantments() {
        return Collections.unmodifiableMap(enchantments);
    }

    public int getFilled() { return filled; }
    public void setFilled(int filled) { this.filled = filled; }

    public int getPendingClaim() { return pendingClaim; }
    public void setPendingClaim(int pendingClaim) { this.pendingClaim = pendingClaim; }

    public double getReserved() { return reserved; }
    public void setReserved(double reserved) { this.reserved = reserved; }

    /** Builds the exact order item. Large quantities are split by the caller. */
    public ItemStack buildItemStack(int amount) {
        int safeAmount = Math.max(1, Math.min(material.getMaxStackSize(), amount));
        ItemStack stack = new ItemStack(material, safeAmount);
        if (!enchantments.isEmpty()) {
            ItemMeta meta = stack.getItemMeta();
            if (meta != null) {
                enchantments.forEach((enchantment, level) -> meta.addEnchant(enchantment, level, true));
                stack.setItemMeta(meta);
            }
        }
        return stack;
    }

    public ItemStack buildItemStack() {
        return buildItemStack(1);
    }

    /** Amount still wanted (not yet delivered). */
    public int remaining() {
        return Math.max(0, quantity - filled);
    }

    public boolean isComplete() {
        return remaining() <= 0;
    }
}
