package de.simpleeco.order.util;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

/**
 * Parses user input like "1000" or "1k"/"1.5m", and abbreviates numbers for
 * display (1000 -> "1K").
 */
public final class NumberUtil {

    private static final String[] SUFFIXES = {"", "K", "M", "B", "T"};
    private static final double[] VALUES = {1, 1_000d, 1_000_000d, 1_000_000_000d, 1_000_000_000_000d};

    private NumberUtil() {
    }

    /** Parses "1000", "1k", "1.5m", "2B" (comma or dot). Returns NaN if invalid. */
    public static double parse(String input) {
        if (input == null) {
            return Double.NaN;
        }
        String s = input.trim().toLowerCase(Locale.ROOT).replace(",", ".");
        if (s.isEmpty()) {
            return Double.NaN;
        }
        double multiplier = 1;
        char last = s.charAt(s.length() - 1);
        switch (last) {
            case 'k' -> multiplier = 1_000d;
            case 'm' -> multiplier = 1_000_000d;
            case 'b' -> multiplier = 1_000_000_000d;
            case 't' -> multiplier = 1_000_000_000_000d;
            default -> { }
        }
        if (multiplier != 1) {
            s = s.substring(0, s.length() - 1);
            if (s.isEmpty()) {
                return Double.NaN;
            }
        }
        try {
            double value = Double.parseDouble(s) * multiplier;
            if (Double.isNaN(value) || Double.isInfinite(value)) {
                return Double.NaN;
            }
            return value;
        } catch (NumberFormatException e) {
            return Double.NaN;
        }
    }

    /** Abbreviates a whole number: 1000 -> "1K", 1500 -> "1.5K", 1234567 -> "1.23M". */
    public static String abbreviate(long amount) {
        double abs = Math.abs((double) amount);
        if (abs < 1000d) {
            return String.valueOf(amount);
        }
        int idx = 0;
        for (int i = VALUES.length - 1; i >= 0; i--) {
            if (abs >= VALUES[i]) {
                idx = i;
                break;
            }
        }
        double scaled = amount / VALUES[idx];
        DecimalFormatSymbols sym = new DecimalFormatSymbols(Locale.US);
        DecimalFormat df = new DecimalFormat("#,##0.##", sym);
        return df.format(scaled) + SUFFIXES[idx];
    }
}
