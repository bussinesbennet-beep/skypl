package de.simpleeco.order;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;

import java.text.DecimalFormat;

/**
 * PlaceholderAPI expansion for the Order plugin.
 *
 * Placeholders (identifier "order"):
 *   %order_earned%       -> total Dollars earned by fulfilling others' orders
 *   %order_earned_raw%   -> raw number
 *   %order_spent%        -> total Dollars spent (reserved) creating your own orders
 *   %order_spent_raw%    -> raw number
 */
public class PlaceholderHook extends PlaceholderExpansion {

    public static final String KEY_EARNED = "dollars_earned";
    public static final String KEY_SPENT = "dollars_spent";

    private final StatStore stats;
    private final String symbol;
    private final DecimalFormat fmt = new DecimalFormat("#,##0.##");

    public PlaceholderHook(StatStore stats, String currencySymbol) {
        this.stats = stats;
        this.symbol = currencySymbol == null ? "$" : currencySymbol;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "order";
    }

    @Override
    public @NotNull String getAuthor() {
        return "SimpleEconomy";
    }

    @Override
    public @NotNull String getVersion() {
        return "1.0.0";
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        if (player == null) {
            return "";
        }
        return switch (params.toLowerCase()) {
            case "earned" -> fmt.format(stats.get(player.getUniqueId(), KEY_EARNED));
            case "earned_raw" -> String.valueOf(stats.get(player.getUniqueId(), KEY_EARNED));
            case "spent" -> fmt.format(stats.get(player.getUniqueId(), KEY_SPENT));
            case "spent_raw" -> String.valueOf(stats.get(player.getUniqueId(), KEY_SPENT));
            default -> null;
        };
    }
}
