package de.simpleeco.order;

import de.simpleeco.order.gui.OrderGui;
import de.simpleeco.order.gui.OrderSort;
import de.simpleeco.order.util.Text;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

/** /order -> opens the order board. */
public class OrderCommand implements CommandExecutor {

    private final OrderGui gui;
    private final FileConfiguration config;

    public OrderCommand(OrderGui gui, FileConfiguration config) {
        this.gui = gui;
        this.config = config;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command can only be used by players.");
            return true;
        }
        if (!player.hasPermission("order.use")) {
            String tr = de.simpleeco.order.util.CoreI18n.translate(player, "order.no-permission");
            player.sendMessage(Text.of(config.getString("messages.prefix", "")
                    + (tr != null ? tr : config.getString("messages.no-permission", ""))));
            return true;
        }
        gui.openBoard(player, 0, OrderSort.NEWEST, null);
        return true;
    }
}
