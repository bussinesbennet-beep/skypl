package de.simpleeco.order.gui;

import de.simpleeco.order.util.CoreI18n;
import de.simpleeco.order.util.Text;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/**
 * Shared navigation controls for the Order GUIs, using vanilla items only.
 * No resource-pack model overrides or animated model frames are required.
 */
public final class GuiItems {

    public static final String NAV = "&#c6c7f2";

    private GuiItems() {
    }

    public static ItemStack previousArrow(Player player, int previousPageNumber) {
        return simple(Material.ARROW,
                NAV + CoreI18n.gui(player, "common-gui.prev-page", "Previous Page"),
                "&7" + CoreI18n.gui(player, "common-gui.go-to-page", "Go to page {page}.",
                        "page", String.valueOf(previousPageNumber)));
    }

    public static ItemStack nextArrow(Player player, int nextPageNumber) {
        return simple(Material.ARROW,
                NAV + CoreI18n.gui(player, "common-gui.next-page", "Next Page"),
                "&7" + CoreI18n.gui(player, "common-gui.go-to-page", "Go to page {page}.",
                        "page", String.valueOf(nextPageNumber)));
    }

    public static ItemStack backArrow(Player player) {
        return simple(Material.ARROW,
                NAV + CoreI18n.gui(player, "common-gui.back", "Back"),
                "&7" + CoreI18n.gui(player, "common-gui.return-prev", "Return to the previous menu."));
    }

    public static ItemStack backRedConcrete(Player player) {
        return simple(Material.RED_DYE,
                NAV + CoreI18n.gui(player, "common-gui.back", "Back"),
                "&7" + CoreI18n.gui(player, "common-gui.return-prev", "Return to the previous menu."));
    }

    private static String sortLabel(Player player, OrderSort mode) {
        return switch (mode) {
            case NEWEST -> CoreI18n.gui(player, "order-gui.items.sort-newest", "Newest");
            case PRICE_DESC -> CoreI18n.gui(player, "order-gui.items.sort-price-high", "Highest price");
            case PRICE_ASC -> CoreI18n.gui(player, "order-gui.items.sort-price-low", "Lowest price");
            case QUANTITY_DESC -> CoreI18n.gui(player, "order-gui.items.sort-most-wanted", "Most wanted");
        };
    }

    public static ItemStack compass(Player player, OrderSort current) {
        ItemStack stack = new ItemStack(Material.COMPASS);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.of(NAV + CoreI18n.gui(player, "order-gui.items.sorting", "Sorting")));
        List<String> lore = new ArrayList<>();
        for (OrderSort mode : OrderSort.values()) {
            lore.add((mode == current ? "&#AFAAFF\u2192 " : "&7  ") + sortLabel(player, mode));
        }
        meta.lore(Text.lore(lore));
        stack.setItemMeta(meta);
        return stack;
    }

    public static ItemStack myOrders(Player player) {
        ItemStack stack = new ItemStack(Material.WRITABLE_BOOK);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.of(NAV + CoreI18n.gui(player, "order-gui.items.my-orders", "My Orders")));
        meta.lore(Text.loreItalic(List.of("&7" + CoreI18n.gui(player, "order-gui.items.my-orders-lore",
                "View and manage your buy orders."))));
        stack.setItemMeta(meta);
        return stack;
    }

    public static ItemStack createNew(Player player) {
        ItemStack stack = new ItemStack(Material.LIME_DYE);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.of(NAV + CoreI18n.gui(player, "order-gui.items.create-new", "New Buy Order")));
        meta.lore(Text.loreItalic(List.of("&7" + CoreI18n.gui(player, "order-gui.items.create-new-lore",
                "Create a new buy order."))));
        stack.setItemMeta(meta);
        return stack;
    }

    public static ItemStack refresh(Player player) {
        ItemStack stack = new ItemStack(Material.CLOCK);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.of(NAV + CoreI18n.gui(player, "order-gui.items.refresh", "Refresh")));
        meta.lore(Text.loreItalic(List.of("&7" + CoreI18n.gui(player, "order-gui.items.refresh-lore",
                "Reload the order board."))));
        stack.setItemMeta(meta);
        return stack;
    }

    public static ItemStack search(Player player, String currentFilter) {
        ItemStack stack = new ItemStack(Material.OAK_SIGN);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.of(NAV + CoreI18n.gui(player, "order-gui.items.search", "Search")));
        List<String> lore = new ArrayList<>();
        if (currentFilter != null && !currentFilter.isEmpty()) {
            lore.add("&7" + CoreI18n.gui(player, "order-gui.items.search-current", "Current:") + " &f" + currentFilter);
            lore.add("&7" + CoreI18n.gui(player, "order-gui.items.search-change", "Click to change search."));
            lore.add("&7" + CoreI18n.gui(player, "order-gui.items.search-clear", "Right-click to clear."));
        } else {
            lore.add("&7" + CoreI18n.gui(player, "order-gui.items.search-hover", "Click to search for an item."));
        }
        meta.lore(Text.loreItalic(lore));
        stack.setItemMeta(meta);
        return stack;
    }

    private static ItemStack simple(Material material, String name, String loreLine) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.of(name));
        meta.lore(Text.loreItalic(List.of(loreLine)));
        stack.setItemMeta(meta);
        return stack;
    }
}
