package de.simpleeco.order.gui;

import de.simpleeco.order.BuyOrder;
import de.simpleeco.order.OrderManager;
import de.simpleeco.order.SelectableItems;
import de.simpleeco.order.economy.EconomyBridge;
import de.simpleeco.order.util.GuiGuard;
import de.simpleeco.order.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.enchantments.Enchantment;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Builds and opens all order views. Uses the shared nav design: nav color
 * &#c6c7f2, gray-italic lore, compass sorting, auto-hidden arrows, plus
 * My-Orders / New-Order / Refresh / Search controls.
 */
public class OrderGui {

    public static final int SIZE = 54;           // 6-row views
    public static final int CONTENT_SLOTS = 45;

    // Board nav slots (bottom row).
    public static final int B_PREV = 45;
    public static final int B_MY = 47;
    public static final int B_REFRESH = 49;      // anvil, center
    public static final int B_SEARCH = 48;       // oak sign
    public static final int B_COMPASS = 50;      // compass
    public static final int B_CREATE = 51;
    public static final int B_NEXT = 53;

    // My Orders nav slots.
    public static final int M_BACK = 45;
    public static final int M_PREV = 48;
    public static final int M_NEXT = 50;
    public static final int M_CREATE = 53;

    // ---- Create view: 3 rows (27 slots) ----
    public static final int CREATE_SIZE = 27;
    public static final int CR_MATERIAL = 11;    // item placeholder (left)
    public static final int CR_QUANTITY = 13;    // custom painter's palette (middle)
    public static final int CR_PRICE = 15;       // emerald (right)
    public static final int CR_CONFIRM = 26;     // bottom-right
    public static final int CR_BACK = 18;        // bottom-left

    // ---- Item selector: 6 rows ----
    public static final int SEL_PREV = 45;
    public static final int SEL_SEARCH = 49;     // oak sign, center
    public static final int SEL_BACK = 48;
    public static final int SEL_NEXT = 53;

    // Fulfil input view: a plain 6-row chest (no buttons) the player drops items into.
    public static final int FULFIL_INPUT_SIZE = 54;

    // Fulfil confirm view: 3 rows. Item in the middle, a Confirm button on each side.
    public static final int FC_SIZE = 27;
    public static final int FC_ITEM = 13;
    public static final int FC_CONFIRM_LEFT = 11;
    public static final int FC_CONFIRM_RIGHT = 15;

    // ---- Collect view: 6 rows. Top 5 rows hold delivered items; bottom row = nav. ----
    public static final int COLLECT_SIZE = 54;
    public static final int COLLECT_CONTENT = 45;   // slots 0..44
    public static final int COL_PREV = 45;
    public static final int COL_DROP_ALL = 47;
    public static final int COL_BACK = 49;
    public static final int COL_SELL_ALL = 51;
    public static final int COL_NEXT = 53;

    // ---- Sell-all confirm view: 3 rows. Item in the middle, Confirm + Back. ----
    public static final int SC_SIZE = 27;
    public static final int SC_ITEM = 13;
    public static final int SC_BACK = 11;      // decline on the left
    public static final int SC_CONFIRM = 15;   // accept on the right

    private final OrderManager manager;
    private final EconomyBridge economy;
    private final de.simpleeco.order.WorthLookup worth;
    private final FileConfiguration config;

    /** Set by the plugin wiring, used by dialog buttons to run the real action. */
    private OrderListener listener;

    public void setListener(OrderListener listener) {
        this.listener = listener;
    }

    public OrderGui(OrderManager manager, EconomyBridge economy,
                    de.simpleeco.order.WorthLookup worth, FileConfiguration config) {
        this.manager = manager;
        this.economy = economy;
        this.worth = worth;
        this.config = config;
    }

    public de.simpleeco.order.WorthLookup worth() {
        return worth;
    }

    private String title(String path, String def) {
        return config.getString(path, def);
    }

    /** GUI title honouring the player's "translate GUIs" scope, else local config. */
    private String title(org.bukkit.entity.Player player, String guiKey, String path, String def) {
        return de.simpleeco.order.util.CoreI18n.gui(player, "order-gui." + guiKey,
                config.getString(path, def));
    }

    // ------------------------------------------------------------- BOARD

    public void openBoard(Player player, int page, OrderSort sort, String filter) {
        List<BuyOrder> orders = new ArrayList<>(manager.openOrders());
        if (filter != null && !filter.isEmpty()) {
            String f = filter.toLowerCase(Locale.ROOT);
            orders.removeIf(o -> !pretty(o.getMaterial()).toLowerCase(Locale.ROOT).contains(f)
                    && !o.getMaterial().name().toLowerCase(Locale.ROOT).contains(f));
        }
        orders.sort(sort.getComparator());

        int totalPages = Math.max(1, (int) Math.ceil(orders.size() / (double) CONTENT_SLOTS));
        page = Math.max(0, Math.min(page, totalPages - 1));

        OrderHolder holder = OrderHolder.board(page, sort, filter);
        String t = title(player, "board-title", "gui.board-title", "&8Order Board");
        if (filter != null && !filter.isEmpty()) {
            t = t + " &7(" + filter + ")";
        }
        Inventory inv = Bukkit.createInventory(holder, SIZE, Text.of(t));
        holder.setInventory(inv);

        int start = page * CONTENT_SLOTS;
        for (int i = 0; i < CONTENT_SLOTS; i++) {
            int idx = start + i;
            if (idx >= orders.size()) break;
            inv.setItem(i, boardIcon(player, orders.get(idx)));
        }

        inv.setItem(B_MY, GuiItems.myOrders(player));
        inv.setItem(B_SEARCH, GuiItems.search(player, filter));
        inv.setItem(B_REFRESH, GuiItems.refresh(player));
        inv.setItem(B_COMPASS, GuiItems.compass(player, sort));
        inv.setItem(B_CREATE, GuiItems.createNew(player));
        if (page > 0) inv.setItem(B_PREV, GuiItems.previousArrow(player, page));
        if (page < totalPages - 1) inv.setItem(B_NEXT, GuiItems.nextArrow(player, page + 2));

        GuiGuard.markAll(inv); // view-only board
        player.openInventory(inv);
    }

    private ItemStack boardIcon(Player player, BuyOrder o) {
        ItemStack stack = o.buildItemStack();
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.of("&f" + pretty(o.getMaterial())));
        List<net.kyori.adventure.text.Component> lore = new ArrayList<>();
        lore.add(Text.of("&7" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.price-per-item", "Price Per Item:") + " &a" + economy.format(o.getPricePerUnit())));
        lore.add(Text.of("&7" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.delivered", "Delivered:") + " &e" + de.simpleeco.order.util.NumberUtil.abbreviate(o.getFilled())
                + "&8/" + de.simpleeco.order.util.NumberUtil.abbreviate(o.getQuantity())));
        lore.add(Text.italic("&7" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.click-deliver", "Click to deliver {name}'s Order", "name", safeName(o.getOwnerName()))));
        meta.lore(lore);
        stack.setItemMeta(meta);
        return stack;
    }

    // -------------------------------------------------------- MY ORDERS

    public void openMyOrders(Player player, int page) {
        List<BuyOrder> orders = manager.ordersOf(player.getUniqueId());
        int totalPages = Math.max(1, (int) Math.ceil(orders.size() / (double) CONTENT_SLOTS));
        page = Math.max(0, Math.min(page, totalPages - 1));

        OrderHolder holder = OrderHolder.myOrders(page);
        Inventory inv = Bukkit.createInventory(holder, SIZE, Text.of(title(player, "my-orders-title", "gui.my-orders-title", "&8My Orders")));
        holder.setInventory(inv);

        int start = page * CONTENT_SLOTS;
        for (int i = 0; i < CONTENT_SLOTS; i++) {
            int idx = start + i;
            if (idx >= orders.size()) break;
            inv.setItem(i, myOrderIcon(player, orders.get(idx)));
        }

        inv.setItem(M_BACK, GuiItems.backArrow(player));
        inv.setItem(M_CREATE, GuiItems.createNew(player));
        if (page > 0) inv.setItem(M_PREV, GuiItems.previousArrow(player, page));
        if (page < totalPages - 1) inv.setItem(M_NEXT, GuiItems.nextArrow(player, page + 2));

        GuiGuard.markAll(inv); // view-only my-orders
        player.openInventory(inv);
    }

    private ItemStack myOrderIcon(Player player, BuyOrder o) {
        ItemStack stack = o.buildItemStack();
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.of("&f" + pretty(o.getMaterial())));
        List<net.kyori.adventure.text.Component> lore = new ArrayList<>();
        lore.add(Text.of("&7" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.wanted", "Wanted:") + " &f" + o.remaining() + "&7/&f" + o.getQuantity()));
        lore.add(Text.of("&7" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.price-each", "Price/each:") + " &a" + economy.format(o.getPricePerUnit())));
        lore.add(Text.of("&7" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.reserved", "Reserved:") + " &a" + economy.format(o.getReserved())));
        lore.add(Text.of("&7" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.to-claim", "To claim:") + " &f" + o.getPendingClaim()));
        lore.add(Text.of(" "));
        if (o.getPendingClaim() > 0) {
            lore.add(Text.italic("&7" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.left-collect", "Left-click to collect delivered items")));
        }
        if (!o.isComplete()) {
            lore.add(Text.italic("&7" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.right-cancel", "Right-click to cancel & refund")));
        }
        meta.lore(lore);
        stack.setItemMeta(meta);
        return stack;
    }

    // ------------------------------------------------------------ CREATE (3 rows)

    /** Opens a fresh create form, optionally seeding draft state. */
    public void openCreate(Player player, Material material, int quantity, double price) {
        openCreate(player, material, quantity, price, Map.of());
    }

    /** Opens the create form with the selected enchanted item variant. */
    public void openCreate(Player player, Material material, int quantity, double price,
                           Map<Enchantment, Integer> enchants) {
        OrderHolder holder = OrderHolder.create();
        holder.setDraftMaterial(material);
        holder.setDraftQuantity(quantity < 1 ? 1 : quantity);
        holder.setDraftPrice(price < manager.getMinPrice() ? manager.getMinPrice() : price);
        holder.setDraftEnchants(enchants);

        Inventory inv = Bukkit.createInventory(holder, CREATE_SIZE, Text.of(title(player, "create-title", "gui.create-title", "&8Create Buy Order")));
        holder.setInventory(inv);
        renderCreate(player, holder, inv);
        GuiGuard.markAll(inv); // view-only create menu
        player.openInventory(inv);
    }

    public void renderCreate(Player player, OrderHolder holder, Inventory inv) {
        inv.clear();

        // Left: a question glyph until chosen, then the real item icon. The
        // amount and reserve summary follow the draft as soon as the player edits it.
        inv.setItem(CR_MATERIAL, materialPlaceholder(player, holder.getDraftMaterial(),
                holder.getDraftEnchants(), holder.getDraftQuantity(), holder.getDraftPrice()));

        // Middle: the chiseled bookshelf opens quantity input. The amount stays
        // as a raw count, not a currency value.
        List<String> qLore = new ArrayList<>();
        qLore.add("&7" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.amount", "Amount:") + " &f" + holder.getDraftQuantity());
        qLore.add(" ");
        qLore.add("&7" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.enter-amount", "Click to enter the amount."));
        inv.setItem(CR_QUANTITY, labeled(Material.CHISELED_BOOKSHELF, "&f" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.quantity", "Quantity"), qLore));

        // Right: emerald -> price via sign. Price is shown formatted.
        List<String> pLore = new ArrayList<>();
        pLore.add("&7" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.price", "Price:") + " &a" + economy.format(holder.getDraftPrice()));
        pLore.add(" ");
        pLore.add("&7" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.enter-price", "Click to enter the price."));
        inv.setItem(CR_PRICE, labeled(Material.EMERALD, "&f" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.price", "Price"), pLore));

        // Confirm (below price) + Back (bottom-left).
        double total = holder.getDraftQuantity() * holder.getDraftPrice();
        inv.setItem(CR_CONFIRM, confirmButton(player, holder, total));
        inv.setItem(CR_BACK, GuiItems.backArrow(player));
    }

    private ItemStack materialPlaceholder(Player player, Material mat, Map<Enchantment, Integer> enchants,
                                          int quantity, double unitPrice) {
        if (mat == null || mat == Material.AIR) {
            ItemStack stack = new ItemStack(Material.KNOWLEDGE_BOOK);
            ItemMeta meta = stack.getItemMeta();
            if (meta != null) {
                meta.displayName(Text.of("&f" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.select-item", "Select Item")));
                meta.lore(Text.loreItalic(List.of("&7" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.choose-item1", "Click to choose the item"), "&7" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.choose-item2", "you want to buy."))));
                stack.setItemMeta(meta);
            }
            return stack;
        }

        int shownAmount = Math.max(1, Math.min(mat.getMaxStackSize(), quantity));
        ItemStack stack = draftStack(mat, enchants, shownAmount);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.of("&a" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.buying", "Buying:") + " &f" + pretty(mat)));
        List<String> lore = new ArrayList<>();
        lore.add("&7" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.amount", "Amount:")
                + " &f" + quantity);
        lore.add("&7" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.price-each", "Price per item:")
                + " &a" + economy.format(unitPrice));
        lore.add("&7" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.reserve", "Reserve:")
                + " &a" + economy.format(quantity * unitPrice));
        lore.add(" ");
        lore.add("&7" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.choose-another", "Click to choose another item."));
        meta.lore(Text.loreItalic(lore));
        stack.setItemMeta(meta);
        return stack;
    }

    private ItemStack draftStack(Material material, Map<Enchantment, Integer> enchants, int amount) {
        ItemStack stack = new ItemStack(material, Math.max(1, Math.min(material.getMaxStackSize(), amount)));
        if (enchants != null && !enchants.isEmpty()) {
            ItemMeta meta = stack.getItemMeta();
            if (meta != null) {
                enchants.forEach((enchantment, level) -> meta.addEnchant(enchantment, level, true));
                stack.setItemMeta(meta);
            }
        }
        return stack;
    }

    private ItemStack confirmButton(Player player, OrderHolder holder, double total) {
        boolean valid = holder.getDraftMaterial() != null
                && holder.getDraftMaterial() != Material.AIR
                && holder.getDraftQuantity() >= 1
                && holder.getDraftPrice() >= manager.getMinPrice()
                && economy.has(player.getUniqueId(), total);

        ItemStack stack = new ItemStack(valid ? Material.LIME_DYE : Material.RED_DYE);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.of((valid ? "&f" : "&7") + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.confirm", "Confirm")));
        List<String> lore = new ArrayList<>();
        if (holder.getDraftMaterial() == null) {
            lore.add("&7" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.select-first", "Select an item first."));
        } else if (!economy.has(player.getUniqueId(), total)) {
            lore.add("&7" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.reserve", "Reserve:") + " &a" + economy.format(total));
            lore.add("&7" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.cant-afford", "You can't afford that."));
        } else {
            lore.add("&7" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.reserve", "Reserve:") + " &a" + economy.format(total));
            lore.add("&7" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.click-confirm", "Click to Confirm"));
        }
        meta.lore(Text.loreItalic(lore));
        stack.setItemMeta(meta);
        return stack;
    }

    // -------------------------------------------------- ITEM SELECTOR (6 rows)

    public void openItemSelector(Player player, OrderHolder createHolder, int page, String filter) {
        List<Material> items = new ArrayList<>(SelectableItems.all());
        if (filter != null && !filter.isEmpty()) {
            String f = filter.toLowerCase(Locale.ROOT);
            items.removeIf(m -> !m.name().toLowerCase(Locale.ROOT).contains(f)
                    && !pretty(m).toLowerCase(Locale.ROOT).contains(f));
        }

        int totalPages = Math.max(1, (int) Math.ceil(items.size() / (double) CONTENT_SLOTS));
        page = Math.max(0, Math.min(page, totalPages - 1));

        OrderHolder holder = OrderHolder.itemSelector(page, filter);
        // Carry the current draft so we can return to the form.
        if (createHolder != null) {
            holder.setCarriedMaterial(createHolder.getDraftMaterial());
            holder.setCarriedQuantity(createHolder.getDraftQuantity());
            holder.setCarriedPrice(createHolder.getDraftPrice());
            holder.setCarriedEnchants(createHolder.getDraftEnchants());
        }

        String t = title(player, "selector-title", "gui.selector-title", "&8Select Item");
        if (filter != null && !filter.isEmpty()) {
            t = t + " &7(" + filter + ")";
        }
        Inventory inv = Bukkit.createInventory(holder, SIZE, Text.of(t));
        holder.setInventory(inv);

        int start = page * CONTENT_SLOTS;
        for (int i = 0; i < CONTENT_SLOTS; i++) {
            int idx = start + i;
            if (idx >= items.size()) break;
            inv.setItem(i, selectorIcon(player, items.get(idx)));
        }

        inv.setItem(SEL_BACK, GuiItems.backArrow(player));
        inv.setItem(SEL_SEARCH, GuiItems.search(player, filter));
        if (page > 0) inv.setItem(SEL_PREV, GuiItems.previousArrow(player, page));
        if (page < totalPages - 1) inv.setItem(SEL_NEXT, GuiItems.nextArrow(player, page + 2));

        GuiGuard.markAll(inv); // view-only item selector
        player.openInventory(inv);
    }

    private ItemStack selectorIcon(Player player, Material mat) {
        ItemStack stack = new ItemStack(mat);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.of("&f" + pretty(mat)));
        meta.lore(Text.loreItalic(List.of("&7" + de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.click-select", "Click to select this item."))));
        stack.setItemMeta(meta);
        return stack;
    }

    /** Materials on the current selector page, for click resolution. */
    public List<Material> selectorItemsFor(OrderHolder holder) {
        List<Material> items = new ArrayList<>(SelectableItems.all());
        String filter = holder.getSelectorFilter();
        if (filter != null && !filter.isEmpty()) {
            String f = filter.toLowerCase(Locale.ROOT);
            items.removeIf(m -> !m.name().toLowerCase(Locale.ROOT).contains(f)
                    && !pretty(m).toLowerCase(Locale.ROOT).contains(f));
        }
        return items;
    }

    // -------------------------------------------------- FULFIL INPUT (6 rows, no buttons)

    /** Opens the plain drop-in chest for fulfilling an order. */
    public void openFulfilInput(Player player, BuyOrder order) {
        OrderHolder holder = OrderHolder.fulfilInput(order.getId());
        Inventory inv = Bukkit.createInventory(holder, FULFIL_INPUT_SIZE,
                Text.of(title(player, "fulfil-title", "gui.fulfil-title", "&8Deliver") + " &7> &f" + pretty(order.getMaterial())));
        holder.setInventory(inv);
        // Completely empty: the player drops matching items (or filled shulkers) in.
        player.openInventory(inv);
    }

    // -------------------------------------------------- FULFIL CONFIRM (3 rows)

    public void openFulfilConfirm(Player player, BuyOrder order, int amount,
                                  java.util.List<ItemStack> emptiedShulkers) {
        OrderHolder holder = OrderHolder.fulfilConfirm(order.getId(), amount);
        if (emptiedShulkers != null) {
            holder.getEmptiedShulkers().addAll(emptiedShulkers);
        }
        Inventory inv = Bukkit.createInventory(holder, FC_SIZE, Text.of(title(player, "fulfil-confirm-title", "gui.fulfil-confirm-title", "&8Confirm Delivery")));
        holder.setInventory(inv);

        double total = amount * order.getPricePerUnit();

        // Middle: the delivered item with amount and total payout.
        ItemStack item = order.buildItemStack();
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Text.of("&f" + pretty(order.getMaterial())));
        List<net.kyori.adventure.text.Component> lore = new ArrayList<>();
        lore.add(Text.of("&7Delivering: &e" + de.simpleeco.order.util.NumberUtil.abbreviate(amount)));
        lore.add(Text.of("&7Price Per Item: &a" + economy.format(order.getPricePerUnit())));
        lore.add(Text.of("&7You get: &a" + economy.format(total)));
        meta.lore(lore);
        item.setItemMeta(meta);
        inv.setItem(FC_ITEM, item);

        // Decline on the left, Confirm on the right.
        inv.setItem(FC_CONFIRM_LEFT, declineButton());
        inv.setItem(FC_CONFIRM_RIGHT, confirmDeliverButton(total));

        GuiGuard.markAll(inv); // view-only confirm (item is only a preview)
        player.openInventory(inv);
    }

    private ItemStack confirmDeliverButton(double total) {
        ItemStack stack = new ItemStack(Material.LIME_DYE);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.of("&fConfirm"));
        List<String> lore = new ArrayList<>();
        lore.add("&7You get: &a" + economy.format(total));
        lore.add("&7Click to Confirm");
        meta.lore(Text.loreItalic(lore));
        stack.setItemMeta(meta);
        return stack;
    }

    private ItemStack declineButton() {
        ItemStack stack = new ItemStack(Material.RED_DYE);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.of("&cCancel"));
        meta.lore(Text.loreItalic(List.of("&7Click to cancel.")));
        stack.setItemMeta(meta);
        return stack;
    }

    // -------------------------------------------------- COLLECT (6 rows)

    /**
     * Opens the collect view: the delivered (pending-claim) items are shown as
     * real, takeable stacks in the top 5 rows. Bottom row has page arrows,
     * a Drop-all button, a Sell-all button (if SellWorth prices the item), and Back.
     */
    public void openCollect(Player player, BuyOrder order, int page) {
        OrderHolder holder = OrderHolder.collect(order.getId());

        int pending = order.getPendingClaim();
        int maxStack = order.getMaterial().getMaxStackSize();
        int perPage = COLLECT_CONTENT;               // stacks per page
        int capacity = perPage * maxStack;           // items per page

        int totalPages = Math.max(1, (int) Math.ceil(pending / (double) capacity));
        page = Math.max(0, Math.min(page, totalPages - 1));
        holder.setCollectPage(page);

        Inventory inv = Bukkit.createInventory(holder, COLLECT_SIZE,
                Text.of(title(player, "collect-title", "gui.collect-title", "&8Collect") + " &7> &f" + pretty(order.getMaterial())));
        holder.setInventory(inv);

        // Fill this page with as many items as fit, capped at the pending amount.
        int shownStart = page * capacity;
        int shownThisPage = Math.max(0, Math.min(capacity, pending - shownStart));
        int remaining = shownThisPage;
        for (int i = 0; i < perPage && remaining > 0; i++) {
            int give = Math.min(maxStack, remaining);
            inv.setItem(i, order.buildItemStack(give));
            remaining -= give;
        }
        holder.setShownAmount(shownThisPage);

        // Bottom nav row.
        inv.setItem(COL_BACK, GuiItems.backArrow(player));
        inv.setItem(COL_DROP_ALL, dropAllButton(shownThisPage));
        if (worth.canSell(order.getMaterial())) {
            inv.setItem(COL_SELL_ALL, sellAllButton(order, pending));
        }
        if (page > 0) inv.setItem(COL_PREV, GuiItems.previousArrow(player, page));
        if (page < totalPages - 1) inv.setItem(COL_NEXT, GuiItems.nextArrow(player, page + 2));

        // Mark ONLY the nav row: the top content rows are real, takeable items and
        // must stay unmarked so collecting them works normally.
        GuiGuard.markRange(inv, COLLECT_CONTENT, COLLECT_SIZE);
        player.openInventory(inv);
    }

    private ItemStack dropAllButton(int shownThisPage) {
        ItemStack stack = new ItemStack(Material.DROPPER);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.of(GuiItems.NAV + "Drop All"));
        meta.lore(Text.loreItalic(List.of(
                "&7Drops the &f" + shownThisPage + "&7 items on",
                "&7this page in front of you.")));
        stack.setItemMeta(meta);
        return stack;
    }

    private ItemStack sellAllButton(BuyOrder order, int pending) {
        double unit = worth.unitPrice(order.getMaterial());
        double total = unit * pending;
        ItemStack stack = new ItemStack(Material.GOLD_INGOT);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.of(GuiItems.NAV + "Sell All"));
        meta.lore(Text.loreItalic(List.of(
                "&7Amount: &f" + pending,
                "&7Price Per Item: &a" + economy.format(unit),
                "&7You get: &a" + economy.format(total),
                " ",
                "&7Click to sell everything.")));
        stack.setItemMeta(meta);
        return stack;
    }

    // -------------------------------------------------- SELL CONFIRM (3 rows)

    /**
     * Native DIALOG version of the sell confirmation: the item is a real dialog
     * body item, and both buttons carry an icon glyph in front of the label.
     * Nothing is consumed here - the actual claim + payout happens on confirm.
     */
    public void openSellConfirm(Player player, BuyOrder order, int amount) {
        org.bukkit.plugin.java.JavaPlugin plugin =
                de.simpleeco.order.util.DialogUi.self("Order");

        double unit = worth.unitPrice(order.getMaterial());
        double total = unit * amount;

        net.kyori.adventure.text.Component title = net.kyori.adventure.text.Component.text(
                        de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.sell-confirm-title", "Confirm Sell")
                                .replace("&8", ""),
                        de.simpleeco.order.util.DialogUi.ACCENT)
                .decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false);

        java.util.List<io.papermc.paper.registry.data.dialog.body.DialogBody> body = new java.util.ArrayList<>();
        body.add(de.simpleeco.order.util.DialogUi.itemBody(order.buildItemStack()));
        body.add(de.simpleeco.order.util.DialogUi.text(
                de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.selling", "Selling")
                        + ": " + de.simpleeco.order.util.NumberUtil.abbreviate(amount),
                de.simpleeco.order.util.DialogUi.MUTED));
        body.add(de.simpleeco.order.util.DialogUi.text(
                de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.price-each", "Price per item")
                        + ": " + economy.format(unit),
                de.simpleeco.order.util.DialogUi.MUTED));
        body.add(de.simpleeco.order.util.DialogUi.text(
                de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.you-get", "You get")
                        + ": " + economy.format(total),
                de.simpleeco.order.util.DialogUi.POSITIVE));

        io.papermc.paper.registry.data.dialog.ActionButton confirm = de.simpleeco.order.util.DialogUi.button(
                plugin, "money",
                de.simpleeco.order.util.CoreI18n.gui(player, "common-gui.confirm", "Confirm"),
                de.simpleeco.order.util.CoreI18n.gui(player, "order-gui.items.confirm-lore", "Click to confirm"),
                150, de.simpleeco.order.util.DialogUi.POSITIVE,
                de.simpleeco.order.util.DialogUi.click(p -> {
                    p.closeDialog();
                    org.bukkit.Bukkit.getScheduler().runTask(plugin,
                            () -> listener.confirmCollectSell(p, order, amount));
                }));
        io.papermc.paper.registry.data.dialog.ActionButton decline = de.simpleeco.order.util.DialogUi.button(
                plugin, "cancel",
                de.simpleeco.order.util.CoreI18n.gui(player, "common-gui.cancel", "Cancel"),
                de.simpleeco.order.util.CoreI18n.gui(player, "common-gui.return-prev", "Return to the previous menu."),
                150, de.simpleeco.order.util.DialogUi.NEGATIVE,
                de.simpleeco.order.util.DialogUi.click(p -> {
                    p.closeDialog();
                    org.bukkit.Bukkit.getScheduler().runTask(plugin,
                            () -> openCollect(p, order, 0));
                }));

        de.simpleeco.order.util.DialogUi.confirm(player, title, body, confirm, decline);
    }

    // ------------------------------------------------------------ HELPERS

    public int countPlain(Player player, Material material) {
        int count = 0;
        for (ItemStack stack : player.getInventory().getStorageContents()) {
            if (isPlain(stack, material)) {
                count += stack.getAmount();
            }
        }
        return count;
    }

    /**
     * Whether a stack counts as a deliverable unit of {@code material}.
     * We accept a custom display name and lore (e.g. the price tag SellWorth
     * adds to inventory items) because the order owner is given freshly-made
     * plain items on claim anyway. We still reject enchanted or damaged items
     * so players don't accidentally hand over valuable gear at a flat price.
     */
    public boolean isPlain(ItemStack stack, Material material) {
        if (stack == null || stack.getType() != material) {
            return false;
        }
        if (!stack.getEnchantments().isEmpty()) {
            return false;
        }
        if (stack.hasItemMeta()) {
            ItemMeta meta = stack.getItemMeta();
            if (meta != null) {
                if (meta.hasEnchants()) {
                    return false;
                }
                if (meta instanceof org.bukkit.inventory.meta.EnchantmentStorageMeta esm
                        && !esm.getStoredEnchants().isEmpty()) {
                    return false;
                }
                if (meta instanceof org.bukkit.inventory.meta.Damageable dmg && dmg.hasDamage()) {
                    return false;
                }
            }
        }
        return true;
    }

    /** Exact material + enchantment match for an order (custom names/lore remain acceptable). */
    public boolean matchesOrderItem(ItemStack stack, BuyOrder order) {
        if (stack == null || order == null || stack.getType() != order.getMaterial()) return false;
        if (!stack.getEnchantments().equals(order.getEnchantments())) return false;
        if (stack.hasItemMeta()) {
            ItemMeta meta = stack.getItemMeta();
            if (meta instanceof org.bukkit.inventory.meta.EnchantmentStorageMeta esm
                    && !esm.getStoredEnchants().isEmpty()) return false;
            if (meta instanceof org.bukkit.inventory.meta.Damageable dmg && dmg.hasDamage()) return false;
        }
        return true;
    }

    private ItemStack labeled(Material mat, String name, List<String> lore) {
        ItemStack stack = new ItemStack(mat);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.of(name));
        meta.lore(Text.lore(lore));
        stack.setItemMeta(meta);
        return stack;
    }

    private String safeName(String n) {
        return n != null ? n : "Unknown";
    }

    public String pretty(Material material) {
        String[] parts = material.name().toLowerCase().split("_");
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (p.isEmpty()) continue;
            sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1)).append(' ');
        }
        return sb.toString().trim();
    }
}
