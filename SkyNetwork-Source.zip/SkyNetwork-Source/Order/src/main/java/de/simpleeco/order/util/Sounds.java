package de.simpleeco.order.util;

import de.simpleeco.economy.api.SimplePrefsAPI;
import de.simpleeco.order.economy.PrefsBridge;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

/**
 * Plays menu sound effects, honouring the per-player "Menu Sounds" toggle
 * (KEY_GUI_SOUNDS) shared across the suite.
 */
public final class Sounds {

    private final PrefsBridge prefs;

    public Sounds(PrefsBridge prefs) {
        this.prefs = prefs;
    }

    /** A soft click when navigating or selecting. */
    public void click(Player player) {
        play(player, Sound.UI_BUTTON_CLICK, 0.6f, 1.2f);
    }

    /** A positive chime on a successful action (e.g. an order created/fulfilled). */
    public void success(Player player) {
        play(player, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 1.2f);
    }

    /** A villager "no" when something is refused (not enough money, limit, etc.). */
    public void deny(Player player) {
        play(player, Sound.ENTITY_VILLAGER_NO, 0.7f, 1.0f);
    }

    private void play(Player player, Sound sound, float volume, float pitch) {
        if (prefs.get(player.getUniqueId(), SimplePrefsAPI.KEY_GUI_SOUNDS, true)) {
            player.playSound(player.getLocation(), sound, volume, pitch);
        }
    }
}
