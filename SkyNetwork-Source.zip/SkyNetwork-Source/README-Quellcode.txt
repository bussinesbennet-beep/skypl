SkyNetwork: Quellcode der vorhandenen Plugins Auction, Order und Shop

Enthalten sind die bestehenden Maven-Projekte mit Java-Quellcode, plugin.yml, Konfigurationsressourcen und pom.xml. Es wurden keine Ersatzprojekte erstellt.

Voraussetzung: JDK 25 oder neuer und Maven.

Der Reactor-Build für alle Netzwerk- und vorhandenen Plugin-Projekte:
  mvn -f pom.xml package -DskipTests

Die gebauten Plugin-JARs liegen nach dem Reactor-Build im jeweiligen target-Ordner.
