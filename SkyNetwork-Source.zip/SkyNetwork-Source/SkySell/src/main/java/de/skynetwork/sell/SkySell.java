package de.skynetwork.sell;

import de.simpleeco.economy.api.SimpleEconomyAPI;
import de.simpleeco.economy.api.SimplePrefsAPI;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.BlockInventoryHolder;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.block.ShulkerBox;
import org.bukkit.plugin.java.JavaPlugin;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class SkySell extends JavaPlugin implements Listener {
    private static final String PRICE_PREFIX="§a$";
    private SimpleEconomyAPI economy;
    private SimplePrefsAPI prefs;
    private static final class SellHolder implements InventoryHolder { Inventory inventory; @Override public Inventory getInventory(){return inventory;} }

    @Override public void onEnable(){saveDefaultConfig();economy=Bukkit.getServicesManager().load(SimpleEconomyAPI.class);prefs=Bukkit.getServicesManager().load(SimplePrefsAPI.class);if(economy==null){getLogger().severe("SimpleEconomy service is missing.");getServer().getPluginManager().disablePlugin(this);return;}getServer().getPluginManager().registerEvents(this,this);}
    private double price(Material material){if(material==Material.AIR||!material.isItem())return 0;String key=material.name();if(getConfig().contains("sell-prices."+key))return Math.max(0,getConfig().getDouble("sell-prices."+key));String n=key;if(n.contains("NETHERITE"))return 32;if(n.contains("DIAMOND"))return 4;if(n.contains("EMERALD"))return 2.5;if(n.contains("ANCIENT_DEBRIS"))return 8;if(n.endsWith("_ORE"))return n.contains("GOLD")?1:n.contains("IRON")?.5:n.contains("COPPER")?.2:n.contains("REDSTONE")?.15:n.contains("LAPIS")?.2:n.contains("COAL")?.25:1.0;if(n.endsWith("_LOG")||n.endsWith("_STEM"))return .2;if(n.contains("RAW_"))return .5;if(material.isEdible())return .15;if(n.contains("ARMOR")||n.contains("SWORD")||n.contains("PICKAXE")||n.contains("AXE")||n.contains("SHOVEL")||n.contains("HOE"))return 1.0;return Math.max(0,getConfig().getDouble("default-price",.1));}
    private String money(double amount){String formatted=economy.format(amount),symbol=economy.getCurrencySymbol();return formatted.startsWith(symbol)?formatted.substring(symbol.length()):formatted;}
    private double itemValue(ItemStack item){if(item==null||item.getType().isAir())return 0;double unit=price(item.getType());if(item.getItemMeta() instanceof BlockStateMeta stateMeta&&stateMeta.getBlockState() instanceof ShulkerBox box){for(ItemStack inner:box.getInventory().getContents())if(inner!=null&&!inner.getType().isAir())unit+=itemValue(inner);}return unit*item.getAmount();}
    private void priceItem(ItemStack item,boolean enabled){if(item==null||item.getType().isAir())return;ItemMeta meta=item.getItemMeta();if(meta==null)return;List<Component> lore=meta.lore()==null?new ArrayList<>():new ArrayList<>(meta.lore());lore.removeIf(c->{String plain=net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText().serialize(c);return plain.startsWith("Sell value: ")||plain.startsWith("$");});if(enabled)lore.add(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserialize(PRICE_PREFIX+money(itemValue(item)/Math.max(1,item.getAmount()))).decoration(TextDecoration.ITALIC,false));meta.lore(lore.isEmpty()?null:lore);item.setItemMeta(meta);}
    private boolean worthLoreEnabled(Player p){return prefs==null||prefs.get(p.getUniqueId(),SimplePrefsAPI.KEY_ITEM_WORTH_LORE,true);}
    private void priceInventory(Inventory inventory,boolean enabled){for(ItemStack item:inventory.getContents())priceItem(item,enabled);}
    private boolean ordinaryInventory(Inventory inventory){return inventory.getHolder() instanceof BlockInventoryHolder;}
    private void openSell(Player p){if(!p.hasPermission("skynetwork.sell")){p.sendMessage(Component.text("You don't have permission to sell items."));return;}SellHolder holder=new SellHolder();holder.inventory=Bukkit.createInventory(holder,54,Component.text("Sell Items").decoration(TextDecoration.ITALIC,false));p.openInventory(holder.inventory);}
    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] args){if(!(sender instanceof Player p)){sender.sendMessage("Players only.");return true;}openSell(p);return true;}
    @EventHandler public void join(PlayerJoinEvent e){Bukkit.getScheduler().runTask(this,()->priceInventory(e.getPlayer().getInventory(),worthLoreEnabled(e.getPlayer())));}
    @EventHandler public void pickup(EntityPickupItemEvent e){if(e.getEntity() instanceof Player p)priceItem(e.getItem().getItemStack(),worthLoreEnabled(p));}
    @EventHandler public void open(InventoryOpenEvent e){if(e.getPlayer() instanceof Player p&&ordinaryInventory(e.getInventory()))Bukkit.getScheduler().runTask(this,()->priceInventory(e.getInventory(),worthLoreEnabled(p)));}
    @EventHandler public void click(InventoryClickEvent e){if(e.getView().getTopInventory().getHolder() instanceof SellHolder)return;Bukkit.getScheduler().runTask(this,()->{if(e.getWhoClicked() instanceof Player p){boolean enabled=worthLoreEnabled(p);priceInventory(p.getInventory(),enabled);if(ordinaryInventory(e.getView().getTopInventory()))priceInventory(e.getView().getTopInventory(),enabled);}});}
    @EventHandler public void close(InventoryCloseEvent e){if(!(e.getInventory().getHolder() instanceof SellHolder)||!(e.getPlayer() instanceof Player p))return;double total=0;for(ItemStack item:e.getInventory().getContents())if(item!=null&&!item.getType().isAir())total+=itemValue(item);if(total<=0){p.sendMessage(Component.text("No sellable items were placed."));return;}if(!economy.deposit(p.getUniqueId(),total)){p.sendMessage(Component.text("Sale failed. Your items were returned."));for(ItemStack item:e.getInventory().getContents())if(item!=null&&!item.getType().isAir()){var overflow=p.getInventory().addItem(item.clone());overflow.values().forEach(left->p.getWorld().dropItemNaturally(p.getLocation(),left));}e.getInventory().clear();return;}e.getInventory().clear();String formatted=money(total);p.sendMessage(Component.text("+"+formatted).color(net.kyori.adventure.text.format.NamedTextColor.GREEN));p.sendActionBar(Component.text("+"+formatted).color(net.kyori.adventure.text.format.NamedTextColor.GREEN));}
}
