package de.simpleeco.economy.api;
import java.util.UUID;
public interface SimplePrefsAPI {
    String KEY_AH_CONFIRM="auction_confirm", KEY_ORDER_CONFIRM="order_confirm";
    String KEY_CHAT_MESSAGES="chat_messages", KEY_HOTBAR_MESSAGES="hotbar_messages", KEY_GUI_SOUNDS="gui_sounds", KEY_SHOP_QUICK_BUY="shop_quick_buy";
    String KEY_PAYMENTS="network_payments", KEY_PAYMENT_NOTIFICATIONS="payment_notifications", KEY_PAY_ALERTS="pay_alerts", KEY_NETWORK_CHAT="network_chat", KEY_PUBLIC_CHAT=KEY_NETWORK_CHAT, KEY_PRIVATE_MESSAGES="private_messages", KEY_DIALOGS="dialogs_enabled";
    String KEY_SERVER_CHAT_MESSAGES="server_chat_messages", KEY_DEATH_MESSAGES="death_messages", KEY_TELEPORT_ALERTS="teleport_alerts", KEY_BOUNTY_ALERTS="bounty_alerts", KEY_AUCTION_ALERTS="auction_alerts", KEY_ORDER_ALERTS="order_alerts";
    String KEY_ITEM_WORTH_LORE="item_worth_lore", KEY_TPA_CONFIRM="teleport_confirm_menus", KEY_SCOREBOARD="scoreboard", KEY_TPA_REQUESTS="teleport_requests", KEY_TPA_HERE_REQUESTS="teleport_here_requests";
    String KEY_FAST_CRYSTALS="fast_crystals", KEY_TOTEM_PARTICLES="totem_particles", KEY_EXPLOSION_PARTICLES="explosion_particles", KEY_EXPLOSION_SOUNDS="explosion_sounds", KEY_COMBAT_TIMER="show_combat_timer", KEY_PHANTOM_SPAWNING="phantom_spawning", KEY_NIGHT_VISION="night_vision", KEY_AH_QUICK_SELL="auction_quick_sell";
    boolean get(UUID player, String key, boolean fallback);
    void set(UUID player, String key, boolean value);
}
