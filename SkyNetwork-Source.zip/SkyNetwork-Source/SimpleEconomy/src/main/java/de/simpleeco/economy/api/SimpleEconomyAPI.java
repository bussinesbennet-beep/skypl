package de.simpleeco.economy.api;
import java.util.UUID;
public interface SimpleEconomyAPI {
    double getBalance(UUID player);
    boolean has(UUID player, double amount);
    boolean withdraw(UUID player, double amount);
    boolean deposit(UUID player, double amount);
    boolean setBalance(UUID player, double amount);
    boolean resetBalance(UUID player);
    String format(double amount);
    String getCurrencySymbol();
}
