package de.simpleeco.economy.api;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;

import java.util.Locale;
import java.util.UUID;

/** Stable bright hexadecimal name tint derived from a player's network UUID. */
public final class PlayerNameColor {
    private PlayerNameColor() {}
    public static String hex(UUID id){int rgb=java.awt.Color.HSBtoRGB((id.hashCode()&0xffff)/65536.0f,0.68f,1.0f)&0xffffff;return String.format(Locale.ROOT,"#%06X",rgb);}
    public static Component component(UUID id,String name){return Component.text(name,TextColor.fromHexString(hex(id)));}
}
