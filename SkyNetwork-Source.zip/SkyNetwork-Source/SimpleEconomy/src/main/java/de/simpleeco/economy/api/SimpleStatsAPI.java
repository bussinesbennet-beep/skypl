package de.simpleeco.economy.api;
import java.util.UUID;
public interface SimpleStatsAPI {
    String KEY_AUCTION_SPENT="auction_spent", KEY_AUCTION_MADE="auction_made";
    String KEY_ORDER_EARNED="order_earned", KEY_ORDER_SPENT="order_spent", KEY_SHOP_SPENT="shop_spent";
    double get(UUID player, String key);
    void add(UUID player, String key, double amount);
}
