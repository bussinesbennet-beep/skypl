package de.simpleeco.economy;

import de.simpleeco.economy.api.SimpleEconomyAPI;
import de.simpleeco.economy.api.SimplePrefsAPI;
import de.simpleeco.economy.api.SimpleStatsAPI;
import de.simpleeco.economy.api.PlayerNameColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.ServicePriority;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.event.Listener;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerJoinEvent;

import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;
import java.util.UUID;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import org.bukkit.plugin.messaging.Messenger;

public final class SimpleEconomyPlugin extends JavaPlugin implements SimpleEconomyAPI, SimpleStatsAPI, SimplePrefsAPI, Listener {
    private static final String NETWORK_CHANNEL = "skynetwork:network";
    private Connection connection;
    private final Object lock = new Object();

    @Override public void onEnable() {
        saveDefaultConfig();
        try {
            Path db = getDataFolder().toPath().resolve(getConfig().getString("database.file", "../network-data/economy.db")).normalize();
            Files.createDirectories(db.getParent());
            connection = DriverManager.getConnection("jdbc:sqlite:" + db.toAbsolutePath());
            try (var s = connection.createStatement()) {
                s.execute("PRAGMA busy_timeout=10000"); s.execute("PRAGMA journal_mode=WAL");
                s.execute("CREATE TABLE IF NOT EXISTS accounts(uuid TEXT PRIMARY KEY, balance REAL NOT NULL DEFAULT 0)");
                s.execute("CREATE TABLE IF NOT EXISTS stats(uuid TEXT NOT NULL, k TEXT NOT NULL, v REAL NOT NULL DEFAULT 0, PRIMARY KEY(uuid,k))");
                s.execute("CREATE TABLE IF NOT EXISTS prefs(uuid TEXT NOT NULL, k TEXT NOT NULL, v INTEGER NOT NULL, PRIMARY KEY(uuid,k))");
                s.execute("CREATE TABLE IF NOT EXISTS player_names(name TEXT PRIMARY KEY, uuid TEXT NOT NULL)");
            }
        } catch (Exception e) { getLogger().severe("Could not open shared economy database: " + e.getMessage()); getServer().getPluginManager().disablePlugin(this); return; }
        var services = Bukkit.getServicesManager();
        getServer().getMessenger().registerOutgoingPluginChannel(this, NETWORK_CHANNEL);
        services.register(SimpleEconomyAPI.class, this, this, ServicePriority.Highest);
        services.register(SimpleStatsAPI.class, this, this, ServicePriority.Highest);
        services.register(SimplePrefsAPI.class, this, this, ServicePriority.Highest);
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("SimpleEconomy enabled with shared SQLite storage.");
    }

    @Override public void onDisable() { synchronized (lock) { try { if (connection != null) connection.close(); } catch (SQLException ignored) {} } }
    private void ensure(UUID id) throws SQLException { try (PreparedStatement p=connection.prepareStatement("INSERT OR IGNORE INTO accounts(uuid,balance) VALUES(?,?)")) { p.setString(1,id.toString()); p.setDouble(2,getConfig().getDouble("starting-balance",0)); p.executeUpdate(); } }
    @Override public double getBalance(UUID id) { synchronized(lock) { try { ensure(id); try (PreparedStatement p=connection.prepareStatement("SELECT balance FROM accounts WHERE uuid=?")) { p.setString(1,id.toString()); try(ResultSet r=p.executeQuery()){return r.next()?r.getDouble(1):0;} } } catch(SQLException e){getLogger().warning(e.getMessage());return 0;} } }
    @Override public boolean has(UUID id,double n) { return n>=0 && getBalance(id)>=n; }
    @Override public boolean withdraw(UUID id,double n) { if(!Double.isFinite(n)||n<0)return false; synchronized(lock){try{ensure(id);try(PreparedStatement p=connection.prepareStatement("UPDATE accounts SET balance=balance-? WHERE uuid=? AND balance>=?")){p.setDouble(1,n);p.setString(2,id.toString());p.setDouble(3,n);return p.executeUpdate()==1;} }catch(SQLException e){getLogger().warning(e.getMessage());return false;}} }
    @Override public boolean deposit(UUID id,double n) { if(!Double.isFinite(n)||n<0)return false; synchronized(lock){try{ensure(id);try(PreparedStatement p=connection.prepareStatement("UPDATE accounts SET balance=balance+? WHERE uuid=?")){p.setDouble(1,n);p.setString(2,id.toString());return p.executeUpdate()==1;} }catch(SQLException e){getLogger().warning(e.getMessage());return false;}} }
    @Override public boolean setBalance(UUID id,double n){if(!Double.isFinite(n)||n<0)return false;synchronized(lock){try{ensure(id);try(PreparedStatement p=connection.prepareStatement("UPDATE accounts SET balance=? WHERE uuid=?")){p.setDouble(1,n);p.setString(2,id.toString());return p.executeUpdate()==1;}}catch(SQLException e){getLogger().warning(e.getMessage());return false;}}}
    @Override public boolean resetBalance(UUID id){return setBalance(id,0);}
    @EventHandler public void onJoin(PlayerJoinEvent e){synchronized(lock){try(PreparedStatement p=connection.prepareStatement("INSERT INTO player_names(name,uuid) VALUES(?,?) ON CONFLICT(name) DO UPDATE SET uuid=excluded.uuid")){p.setString(1,e.getPlayer().getName().toLowerCase(Locale.ROOT));p.setString(2,e.getPlayer().getUniqueId().toString());p.executeUpdate();}catch(SQLException ex){getLogger().warning(ex.getMessage());}}}
    private UUID findUuid(String name){try{return UUID.fromString(name);}catch(IllegalArgumentException ignored){}synchronized(lock){try(PreparedStatement p=connection.prepareStatement("SELECT uuid FROM player_names WHERE name=?")){p.setString(1,name.toLowerCase(Locale.ROOT));try(ResultSet r=p.executeQuery()){if(r.next())return UUID.fromString(r.getString(1));}}catch(SQLException e){getLogger().warning(e.getMessage());}}return null;}
    @Override public String getCurrencySymbol(){return getConfig().getString("currency-symbol","$");}
    @Override public String format(double n){double abs=Math.abs(n);String[] suffix={"","K","M","B","T"};double[] scale={1,1_000d,1_000_000d,1_000_000_000d,1_000_000_000_000d};int idx=0;for(int i=scale.length-1;i>0;i--)if(abs>=scale[i]){idx=i;break;}var f=new DecimalFormat(idx==0?"#,##0.##":"#,##0.##",DecimalFormatSymbols.getInstance(Locale.US));return getCurrencySymbol()+f.format(n/scale[idx])+suffix[idx];}
    private static double parseAmount(String raw){if(raw==null)return Double.NaN;String value=raw.trim().replace(",",".");if(value.isEmpty())return Double.NaN;double factor=1;char last=Character.toUpperCase(value.charAt(value.length()-1));if(last=='K'||last=='M'||last=='B'||last=='T'){factor=switch(last){case 'K'->1_000d;case 'M'->1_000_000d;case 'B'->1_000_000_000d;default->1_000_000_000_000d;};value=value.substring(0,value.length()-1);}try{double result=Double.parseDouble(value)*factor;return Double.isFinite(result)?result:Double.NaN;}catch(NumberFormatException ex){return Double.NaN;}}
    @Override public double get(UUID id,String key){synchronized(lock){try(PreparedStatement p=connection.prepareStatement("SELECT v FROM stats WHERE uuid=? AND k=?")){p.setString(1,id.toString());p.setString(2,key);try(ResultSet r=p.executeQuery()){return r.next()?r.getDouble(1):0;}}catch(SQLException e){return 0;}}}
    @Override public void add(UUID id,String key,double n){if(!Double.isFinite(n))return;synchronized(lock){try(PreparedStatement p=connection.prepareStatement("INSERT INTO stats(uuid,k,v) VALUES(?,?,?) ON CONFLICT(uuid,k) DO UPDATE SET v=v+excluded.v")){p.setString(1,id.toString());p.setString(2,key);p.setDouble(3,n);p.executeUpdate();}catch(SQLException e){getLogger().warning(e.getMessage());}}}
    @Override public boolean get(UUID id,String key,boolean fallback){synchronized(lock){try(PreparedStatement p=connection.prepareStatement("SELECT v FROM prefs WHERE uuid=? AND k=?")){p.setString(1,id.toString());p.setString(2,key);try(ResultSet r=p.executeQuery()){return r.next()?r.getInt(1)!=0:fallback;}}catch(SQLException e){return fallback;}}}
    @Override public void set(UUID id,String key,boolean value){synchronized(lock){try(PreparedStatement p=connection.prepareStatement("INSERT INTO prefs(uuid,k,v) VALUES(?,?,?) ON CONFLICT(uuid,k) DO UPDATE SET v=excluded.v")){p.setString(1,id.toString());p.setString(2,key);p.setInt(3,value?1:0);p.executeUpdate();}catch(SQLException e){getLogger().warning(e.getMessage());}}}

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if(command.getName().equalsIgnoreCase("balance")||command.getName().equalsIgnoreCase("bal")){
            if(args.length==0 && sender instanceof Player p){sender.sendMessage("§7Balance: §a"+format(getBalance(p.getUniqueId())));return true;}
            if(args.length==1 && sender.hasPermission("simpleeconomy.balance.others")){Player p=Bukkit.getPlayerExact(args[0]);if(p!=null)sender.sendMessage(net.kyori.adventure.text.Component.text().append(PlayerNameColor.component(p.getUniqueId(),p.getName())).append(net.kyori.adventure.text.Component.text("§7: §a"+format(getBalance(p.getUniqueId())))).build());else sender.sendMessage("§cPlayer must be online.");return true;}
            return true;
        }
        if(command.getName().equalsIgnoreCase("pay")){
            if(!(sender instanceof Player p)||args.length!=2)return true;
            Player target=Bukkit.getPlayerExact(args[0]);UUID targetId=target==null?findUuid(args[0]):target.getUniqueId();double n=parseAmount(args[1]);
            if(targetId==null||targetId.equals(p.getUniqueId())||!Double.isFinite(n)||n<=0){p.sendMessage("§cInvalid player or amount.");return true;}
            SimplePrefsAPI prefs=Bukkit.getServicesManager().load(SimplePrefsAPI.class);if(prefs!=null&&!prefs.get(targetId,SimplePrefsAPI.KEY_PAYMENTS,true)){p.sendMessage("§cThat player is not accepting payments.");return true;}
            if(withdraw(p.getUniqueId(),n)){deposit(targetId,n);String targetName=target==null?args[0]:target.getName();p.sendMessage(net.kyori.adventure.text.Component.text().append(net.kyori.adventure.text.Component.text("You sent ")).append(net.kyori.adventure.text.Component.text(format(n),net.kyori.adventure.text.format.NamedTextColor.GREEN)).append(net.kyori.adventure.text.Component.text(" to ")).append(PlayerNameColor.component(targetId,targetName)).build());boolean alerts=prefs==null||(prefs.get(targetId,SimplePrefsAPI.KEY_PAYMENT_NOTIFICATIONS,true)&&prefs.get(targetId,SimplePrefsAPI.KEY_PAY_ALERTS,true));if(alerts){if(target!=null){var notice=net.kyori.adventure.text.Component.text().append(net.kyori.adventure.text.Component.text("You received ")).append(net.kyori.adventure.text.Component.text(format(n),net.kyori.adventure.text.format.NamedTextColor.GREEN)).append(net.kyori.adventure.text.Component.text(" from ")).append(PlayerNameColor.component(p.getUniqueId(),p.getName())).build();if(prefs==null||prefs.get(targetId,SimplePrefsAPI.KEY_SERVER_CHAT_MESSAGES,true))target.sendMessage(notice);if(prefs==null||prefs.get(targetId,SimplePrefsAPI.KEY_HOTBAR_MESSAGES,true))target.sendActionBar(notice);if(prefs==null||prefs.get(targetId,SimplePrefsAPI.KEY_GUI_SOUNDS,true))target.playSound(target.getLocation(),org.bukkit.Sound.BLOCK_NOTE_BLOCK_PLING,0.45f,1.7f);}else sendPaymentNotice(p,targetId,p.getName(),format(n));}}else p.sendMessage("§cInsufficient balance.");return true;
        }
        if(command.getName().equalsIgnoreCase("eco")){
            if(!sender.hasPermission("simpleeconomy.admin")){sender.sendMessage("§cYou don't have permission.");return true;}
            if(args.length<2)return true;
            UUID id=findUuid(args[1]);if(id==null){sender.sendMessage("§cPlayer not found in network history.");return true;}
            String action=args[0].toLowerCase(Locale.ROOT);
            if(action.equals("reset")){resetBalance(id);sender.sendMessage("§aReset "+args[1]+"'s balance to $0.");return true;}
            if(args.length!=3||(!action.equals("give")&&!action.equals("set")))return true;
            double amount=parseAmount(args[2]);
            if(!Double.isFinite(amount)||amount<0||(!action.equals("set")&&amount==0)){sender.sendMessage("§cAmount must be positive (or zero for set).");return true;}
            boolean ok=action.equals("give")?deposit(id,amount):setBalance(id,amount);
            if(ok)sender.sendMessage("§a"+action+" §f"+format(amount)+" §ato §f"+args[1]+"§a. New balance: §f"+format(getBalance(id)));else sender.sendMessage("§cCould not update balance.");return true;
        }
        return false;
    }

    private void sendPaymentNotice(Player source,UUID target,String sender,String amount){try{ByteArrayOutputStream bytes=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(bytes);out.writeUTF("PAY_NOTICE");out.writeUTF(target.toString());out.writeUTF(source.getUniqueId().toString());out.writeUTF(sender);out.writeUTF(amount);source.sendPluginMessage(this,NETWORK_CHANNEL,bytes.toByteArray());}catch(Exception ex){getLogger().warning("Could not deliver cross-server payment notice: "+ex.getMessage());}}

    private java.util.List<String> knownNames(String prefix){java.util.List<String> names=new java.util.ArrayList<>();synchronized(lock){try(PreparedStatement q=connection.prepareStatement("SELECT name FROM player_names WHERE name LIKE ? ORDER BY name LIMIT 100")){q.setString(1,prefix.toLowerCase(Locale.ROOT)+"%");try(ResultSet r=q.executeQuery()){while(r.next())names.add(r.getString(1));}}catch(SQLException e){getLogger().warning(e.getMessage());}}for(Player p:Bukkit.getOnlinePlayers())if(p.getName().toLowerCase(Locale.ROOT).startsWith(prefix.toLowerCase(Locale.ROOT))&&!names.contains(p.getName()))names.add(p.getName());return names;}
    @Override public java.util.List<String> onTabComplete(CommandSender sender,Command command,String alias,String[] args){if(command.getName().equalsIgnoreCase("pay")&&args.length==1)return knownNames(args[0]);if(command.getName().equalsIgnoreCase("eco")){if(!sender.hasPermission("simpleeconomy.admin"))return java.util.List.of();if(args.length==1)return java.util.List.of("give","set","reset").stream().filter(x->x.startsWith(args[0].toLowerCase(Locale.ROOT))).toList();if(args.length==2)return knownNames(args[1]);}if((command.getName().equalsIgnoreCase("balance")||command.getName().equalsIgnoreCase("bal"))&&args.length==1&&sender.hasPermission("simpleeconomy.balance.others"))return knownNames(args[0]);return java.util.List.of();}
}
