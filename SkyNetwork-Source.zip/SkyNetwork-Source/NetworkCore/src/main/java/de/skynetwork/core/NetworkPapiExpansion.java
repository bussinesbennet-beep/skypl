package de.skynetwork.core;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;

public final class NetworkPapiExpansion extends PlaceholderExpansion {
    private final SkyNetworkCore plugin;

    public NetworkPapiExpansion(SkyNetworkCore plugin) {
        this.plugin = plugin;
    }

    @Override public String getIdentifier() { return "skynetwork"; }
    @Override public String getAuthor() { return "SkyNetwork"; }
    @Override public String getVersion() { return plugin.getDescription().getVersion(); }
    @Override public boolean persist() { return true; }

    @Override
    public String onRequest(OfflinePlayer player, String params) {
        return player == null ? "" : plugin.placeholder(player, params);
    }
}
