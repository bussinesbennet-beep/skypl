# SkyNetwork implementation notes

The deployable five-instance layout is in `../SkyNetwork-Servers`.

* `NetworkTab` is a Velocity 4.3.1 plugin. It keeps remote proxy players in
  each viewer's tab list and routes teleport requests and server transfers.
* `NetworkCore` is installed on every Paper backend. It provides cross-server
  TPA, `/rtp`, nine homes with permission-based slots, dimension worlds, and
  the requested English colored/clickable request message.
* `SimpleEconomy` publishes the API used by the supplied Auction, Order, and
  Shop projects. Balances, economy preferences/stats, auction listings,
  orders, homes, and shop stock use shared local data files.
* Paper projects compile against Paper 26.3 build 242 and Java 25. Maven
  reactor compilation succeeded. The built plugin JARs are copied to the
  appropriate proxy/backend `plugins` folders.

Auction claims use SQLite `DELETE ... RETURNING` so only one backend can claim
a listing. Order fulfilment uses an SQLite immediate transaction so multiple
backends cannot overfill the same order. The shared SQLite files assume every
backend runs on this same PC and local disk; do not place these files on a
network share or run them across multiple PCs.

Paper's EULA files are left false for you to review and accept before startup.
