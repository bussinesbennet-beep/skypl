package de.skynetwork.rtp.paper;

import de.simpleeco.economy.api.SimplePrefsAPI;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.messaging.PluginMessageListener;
import org.bukkit.scheduler.BukkitTask;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class NetworkRTPPlugin extends JavaPlugin implements Listener, TabExecutor, PluginMessageListener {
    private static final String CHANNEL="networkrtp:rtp";
    private static final LegacyComponentSerializer AMP=LegacyComponentSerializer.builder().character('&').hexColors().build();
    private static final MiniMessage MINI=MiniMessage.miniMessage();
    private final Map<UUID,BukkitTask> countdowns=new ConcurrentHashMap<>();
    private final Map<UUID,UUID> activeRequests=new ConcurrentHashMap<>();
    private final java.util.Random random=new java.util.Random();
    private SimplePrefsAPI prefs;
    private static final class MenuHolder implements InventoryHolder { Inventory inventory; public Inventory getInventory(){return inventory;} }

    @Override public void onEnable(){saveDefaultConfig();prefs=Bukkit.getServicesManager().load(SimplePrefsAPI.class);Bukkit.getPluginManager().registerEvents(this,this);Bukkit.getMessenger().registerOutgoingPluginChannel(this,CHANNEL);Bukkit.getMessenger().registerIncomingPluginChannel(this,CHANNEL,this);if(getCommand("rtp")!=null){getCommand("rtp").setExecutor(this);getCommand("rtp").setTabCompleter(this);}getLogger().info("NetworkRTP Paper enabled.");}
    @Override public void onDisable(){countdowns.values().forEach(BukkitTask::cancel);countdowns.clear();activeRequests.clear();}
    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] args){if(!(sender instanceof Player player))return true;if(!player.hasPermission("networkrtp.use"))return true;if(args.length==0){openSelection(player);return true;}String key=args[0].toLowerCase(Locale.ROOT);if(key.equals("world"))key="overworld";if(!getConfig().isConfigurationSection("worlds."+key)){openSelection(player);return true;}beginCountdown(player,key);return true;}
    @Override public List<String> onTabComplete(CommandSender sender,Command command,String alias,String[] args){if(args.length!=1)return List.of();String prefix=args[0].toLowerCase(Locale.ROOT);return List.of("world","nether","end").stream().filter(x->x.startsWith(prefix)).toList();}

    private void openSelection(Player player){if(player.getProtocolVersion()>=771){try{openDialog(player);return;}catch(Throwable failure){getLogger().fine("Dialog RTP menu unavailable for "+player.getName()+": "+failure.getMessage());}}openInventory(player);}
    private void openDialog(Player player){List<DialogBody> body=new ArrayList<>();for(String key:List.of("overworld","end","nether")){String root="worlds."+key;ItemStack icon=new ItemStack(material(key));ItemMeta meta=icon.getItemMeta();meta.displayName(AMP.deserialize("&f"+name(key)).decoration(TextDecoration.ITALIC,false));meta.lore(lore(key));icon.setItemMeta(meta);body.add(DialogBody.item(icon).showDecorations(true).showTooltip(true).width(24).height(24).build());for(String line:loreText(key))body.add(DialogBody.plainMessage(AMP.deserialize(line),300));}
        var options=net.kyori.adventure.text.event.ClickCallback.Options.builder().uses(net.kyori.adventure.text.event.ClickCallback.UNLIMITED_USES).lifetime(java.time.Duration.ofMinutes(2)).build();List<ActionButton> buttons=new ArrayList<>();for(String key:List.of("overworld","end","nether")){final String destination=key;buttons.add(ActionButton.builder(AMP.deserialize("&f"+name(key)).decoration(TextDecoration.ITALIC,false)).tooltip(AMP.deserialize("&7Randomly teleport into the "+name(key))).width(300).action(DialogAction.customClick((response,audience)->{if(audience instanceof Player p){p.closeDialog();beginCountdown(p,destination);}},options)).build());}
        var base=DialogBase.builder(Component.text("Random Teleport").decoration(TextDecoration.ITALIC,false)).canCloseWithEscape(true).pause(false).afterAction(DialogBase.DialogAfterAction.NONE).body(body).build();player.showDialog(io.papermc.paper.dialog.Dialog.create(factory->factory.empty().base(base).type(DialogType.multiAction(buttons).columns(1).build())));
    }
    private void openInventory(Player player){MenuHolder holder=new MenuHolder();Inventory inv=Bukkit.createInventory(holder,27,Component.text("Random Teleport").decoration(TextDecoration.ITALIC,false));holder.inventory=inv;inv.setItem(10,menuItem("overworld"));inv.setItem(13,menuItem("end"));inv.setItem(16,menuItem("nether"));player.openInventory(inv);}
    private ItemStack menuItem(String key){ItemStack item=new ItemStack(material(key));ItemMeta meta=item.getItemMeta();meta.displayName(AMP.deserialize("&f"+name(key)).decoration(TextDecoration.ITALIC,false));meta.lore(lore(key));item.setItemMeta(meta);return item;}
    private List<Component> lore(String key){return loreText(key).stream().map(s->(Component)AMP.deserialize(s).decoration(TextDecoration.ITALIC,false)).toList();}
    private List<String> loreText(String key){return switch(key){case "overworld"->List.of("&7Click to Randomly Teleport","&7into the Overworld");case "end"->List.of("&7Click to Randomly","&7Teleport into the End");default->List.of("&7Click to Randomly Teleport","&7into the Nether");};}
    private String name(String key){return switch(key){case "overworld"->"Overworld";case "end"->"End";default->"Nether";};}
    private Material material(String key){String configured=getConfig().getString("worlds."+key+".icon",switch(key){case "overworld"->"DIRT_PATH";case "end"->"END_STONE_BRICKS";default->"WARPED_NYLIUM";});Material found=Material.matchMaterial(configured);return found==null?Material.STONE:found;}
    @EventHandler public void menuClick(InventoryClickEvent event){if(!(event.getWhoClicked() instanceof Player player)||!(event.getView().getTopInventory().getHolder() instanceof MenuHolder))return;event.setCancelled(true);if(event.getClickedInventory()!=event.getView().getTopInventory())return;String key=switch(event.getRawSlot()){case 10->"overworld";case 13->"end";case 16->"nether";default->null;};if(key!=null){player.closeInventory();beginCountdown(player,key);}}
    @EventHandler public void menuDrag(InventoryDragEvent event){if(event.getView().getTopInventory().getHolder() instanceof MenuHolder)event.setCancelled(true);}

    private void beginCountdown(Player player,String key){if(countdowns.containsKey(player.getUniqueId())||activeRequests.containsKey(player.getUniqueId()))return;int seconds=Math.max(1,getConfig().getInt("countdown",5));UUID originalWorld=player.getWorld().getUID();final int[] left={seconds};BukkitTask task=Bukkit.getScheduler().runTaskTimer(this,()->{if(!player.isOnline()||!player.getWorld().getUID().equals(originalWorld)){cancel(player,true);return;}if(left[0]<=0){BukkitTask old=countdowns.remove(player.getUniqueId());if(old!=null)old.cancel();UUID request=UUID.randomUUID();activeRequests.put(player.getUniqueId(),request);player.sendActionBar(message("teleporting","&aTeleporting..."));send("REQUEST",request.toString(),player.getUniqueId().toString(),key,Boolean.toString(player.hasPermission("networkrtp.bypass")));return;}String color=getConfig().getString("worlds."+key+".color",key.equals("overworld")?"#2BD23D":key.equals("nether")?"#FD8B8B":"#AEFFBE");String value="<"+color+">"+left[0];String template=getConfig().getString("messages.countdown","&7You will teleport in %time%");String[] parts=template.split("%time%",2);Component bar=AMP.deserialize(parts[0]).append(MINI.deserialize(value));if(parts.length>1)bar=bar.append(AMP.deserialize(parts[1]));player.sendActionBar(bar);left[0]--;},0L,20L);countdowns.put(player.getUniqueId(),task);}
    @EventHandler public void quit(PlayerQuitEvent event){Player player=event.getPlayer();BukkitTask task=countdowns.remove(player.getUniqueId());if(task!=null)task.cancel();activeRequests.remove(player.getUniqueId());}
    @EventHandler public void death(PlayerDeathEvent event){cancel(event.getEntity(),true);}
    @EventHandler public void changedWorld(PlayerChangedWorldEvent event){cancel(event.getPlayer(),true);}
    @EventHandler public void teleport(PlayerTeleportEvent event){if(event.getTo()!=null&&!event.getFrom().getWorld().equals(event.getTo().getWorld()))cancel(event.getPlayer(),true);}
    private void cancel(Player player,boolean notify){BukkitTask task=countdowns.remove(player.getUniqueId());if(task!=null){task.cancel();if(notify)player.sendActionBar(message("cancelled","&cTeleport cancelled!"));}UUID id=activeRequests.remove(player.getUniqueId());if(id!=null)send("CANCEL",id.toString(),player.getUniqueId().toString());}

    @Override public void onPluginMessageReceived(String channel,Player carrier,byte[] data){if(!CHANNEL.equals(channel))return;try(DataInputStream in=new DataInputStream(new ByteArrayInputStream(data))){String action=in.readUTF();UUID request=UUID.fromString(in.readUTF());UUID id=UUID.fromString(in.readUTF());Player player=Bukkit.getPlayer(id);if(player==null)return;if(action.equals("DELIVER")){UUID current=activeRequests.putIfAbsent(id,request);if(current!=null&&!current.equals(request))return;String destination=in.readUTF();generate(player,request,destination,0);}else if(action.equals("MESSAGE")){UUID current=activeRequests.get(id);if(current==null||!current.equals(request))return;String key=in.readUTF();String fallback=in.readUTF();activeRequests.remove(id,request);notify(player,key.equals("raw")?AMP.deserialize(fallback):message(key,fallback));}}catch(Exception exception){getLogger().warning("Invalid RTP proxy message: "+exception.getMessage());}}
    private void generate(Player player,UUID request,String key,int attempt){if(!player.isOnline()||!request.equals(activeRequests.get(player.getUniqueId())))return;String path="worlds."+key;World world=Bukkit.getWorld(getConfig().getString(path+".world",key.equals("overworld")?"world":key.equals("nether")?"nether_world":"end_world"));if(world==null){finish(player,request,false,"no-location");return;}int max=Math.max(1,getConfig().getInt("max-attempts",50));if(attempt>=max){finish(player,request,false,"no-location");return;}int radius=Math.max(100,getConfig().getInt(path+".radius",5000));int min=Math.max(0,Math.min(radius-1,getConfig().getInt(path+".min-radius",0)));int x=random.nextInt(-radius,radius+1),z=random.nextInt(-radius,radius+1);if(Math.abs(x)<min&&Math.abs(z)<min){generate(player,request,key,attempt+1);return;}Location point=new Location(world,x+0.5,world.getMinHeight()+1,z+0.5);world.getChunkAtAsync(x>>4,z>>4,true).whenComplete((chunk,error)->Bukkit.getScheduler().runTask(this,()->{if(error!=null||chunk==null){generate(player,request,key,attempt+1);return;}Location safe=safeLocation(world,x,z,key);if(safe==null){generate(player,request,key,attempt+1);return;}if(!request.equals(activeRequests.get(player.getUniqueId())))return;player.teleportAsync(safe).whenComplete((ok,teleportError)->Bukkit.getScheduler().runTask(this,()->{if(teleportError!=null||!Boolean.TRUE.equals(ok)){generate(player,request,key,attempt+1);return;}finish(player,request,true,"teleporting");}));}));}
    private Location safeLocation(World world,int x,int z,String key){var border=world.getWorldBorder();Location center=new Location(world,x+0.5,world.getMinHeight(),z+0.5);if(!border.isInside(center))return null;int y=world.getHighestBlockYAt(x,z);if(key.equals("end")&&y<48)return null;if(key.equals("nether")&&(y>=world.getMaxHeight()-16||y<world.getMinHeight()+5))return null;if(y<world.getMinHeight()+1||y>world.getMaxHeight()-3)return null;Block ground=world.getBlockAt(x,y,z);Block feet=world.getBlockAt(x,y+1,z);Block head=world.getBlockAt(x,y+2,z);if(!ground.getType().isSolid()||!feet.isPassable()||!head.isPassable())return null;if(hazard(ground.getType())||hazard(feet.getType())||hazard(head.getType()))return null;return new Location(world,x+0.5,y+1,z+0.5,random.nextFloat()*360f,0f);}
    private boolean hazard(Material material){return switch(material){case LAVA,WATER,FIRE,SOUL_FIRE,CACTUS,MAGMA_BLOCK,CAMPFIRE,SOUL_CAMPFIRE,POWDER_SNOW,SWEET_BERRY_BUSH,WITHER_ROSE,POINTED_DRIPSTONE->true;default->false;};}
    private void finish(Player player,UUID request,boolean success,String message){if(!activeRequests.remove(player.getUniqueId(),request))return;notify(player,message(message,success?"&aYou were randomly teleported.":"&cNo safe location found!"));if(success)send("RESULT",request.toString(),player.getUniqueId().toString(),"SUCCESS");else send("RESULT",request.toString(),player.getUniqueId().toString(),"FAIL");}
    private void notify(Player player,Component component){if(prefs==null||prefs.get(player.getUniqueId(),SimplePrefsAPI.KEY_SERVER_CHAT_MESSAGES,true))player.sendMessage(component);if(prefs==null||prefs.get(player.getUniqueId(),SimplePrefsAPI.KEY_HOTBAR_MESSAGES,true))player.sendActionBar(component);if(prefs==null||prefs.get(player.getUniqueId(),SimplePrefsAPI.KEY_GUI_SOUNDS,true))player.playSound(player.getLocation(),org.bukkit.Sound.BLOCK_NOTE_BLOCK_PLING,0.35f,1.65f);}
    private Component message(String key,String fallback){return AMP.deserialize(getConfig().getString("messages."+key,fallback)).decoration(TextDecoration.ITALIC,false);}
    private void send(String action,String... values){try{ByteArrayOutputStream bytes=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(bytes);out.writeUTF(action);for(String value:values)out.writeUTF(value);Player carrier=null;if(values.length>1)try{carrier=Bukkit.getPlayer(UUID.fromString(values[1]));}catch(IllegalArgumentException ignored){}if(carrier==null)carrier=Bukkit.getOnlinePlayers().stream().findFirst().orElse(null);if(carrier!=null)carrier.sendPluginMessage(this,CHANNEL,bytes.toByteArray());}catch(Exception exception){getLogger().warning("Could not send RTP message to Velocity: "+exception.getMessage());}}
}
