package de.skynetwork.staff;

import io.papermc.paper.event.player.AsyncChatEvent;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Statistic;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerEditBookEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.inventory.AnvilInventory;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.permissions.PermissionAttachment;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.Normalizer;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

public final class NetworkStaffPlugin extends JavaPlugin implements Listener, TabExecutor {
    private static final LegacyComponentSerializer AMP = LegacyComponentSerializer.builder().character('&').hexColors().build();
    private static final PlainTextComponentSerializer PLAIN = PlainTextComponentSerializer.plainText();
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").withZone(ZoneId.systemDefault());
    private static final List<String> CATEGORIES = List.of("Hacking", "Exploiting", "Account Scamming", "Real Money Trading", "Harassment", "Hate Speech", "Threats", "Doxxing", "Impersonation", "Advertising", "Spam", "Ban Evasion", "Voice Chat Abuse", "Griefing", "Scamming", "Other");
    private static final List<String> PUNISHMENT_WORDS = List.of("mute", "ban", "wipe", "kick", "freeze");
    private final Map<UUID, PermissionAttachment> voiceAttachments = new ConcurrentHashMap<>();
    private final Map<UUID, String> frozenActors = new ConcurrentHashMap<>();
    private final List<String> blockedTerms = new ArrayList<>();
    private final Object dataLock = new Object();
    private Path playerDatabase;
    private Path auctionsDatabase;
    private Path ordersDatabase;
    private Path playerShops;
    private StaffActionLogger audit;
    private PunishmentService punishments;

    private static final class ActionsHolder implements InventoryHolder {
        final StaffActionFilter filter; final int page; final List<StaffAction> actions;
        Inventory inventory;
        ActionsHolder(StaffActionFilter filter, int page, List<StaffAction> actions) { this.filter=filter;this.page=page;this.actions=actions; }
        @Override public Inventory getInventory() { return inventory; }
    }

    @Override public void onEnable() {
        saveDefaultConfig(); reloadTerms();
        try {
            playerDatabase = configuredPath("staff-actions.player-database-file", "../../../network-data/economy.db");
            auctionsDatabase = configuredPath("staff-actions.auctions-database-file", "../../../network-data/auctions.db");
            ordersDatabase = configuredPath("staff-actions.orders-database-file", "../../../network-data/orders.db");
            playerShops = configuredPath("staff-actions.player-shops-directory", "../../../network-data/player-shops");
            Path auditPath = configuredPath("staff-actions.database-file", "../../../network-data/staff-actions.db");
            Path fallback = getDataFolder().toPath().resolve(getConfig().getString("staff-actions.fallback-file", "staff-actions-fallback.log")).normalize();
            audit = new StaffActionLogger(this, auditPath, fallback); audit.initialize(); ensurePlayerSchema();
        } catch (Exception exception) {
            getLogger().severe("NetworkStaff cannot safely open shared data: " + exception.getMessage());
            getServer().getPluginManager().disablePlugin(this); return;
        }
        punishments = new PunishmentService(this);
        for (String name : List.of("staffactions","ban","unban","reportban","reportunban","mute","unmute","kick","freeze","unfreeze","warn","offend","punish","wipe","staffnote")) {
            if (getCommand(name) != null) { getCommand(name).setExecutor(this); getCommand(name).setTabCompleter(this); }
        }
        getServer().getPluginManager().registerEvents(this, this);
        for (Player player : Bukkit.getOnlinePlayers()) cacheProtection(player);
        Bukkit.getScheduler().runTaskTimer(this, () -> Bukkit.getOnlinePlayers().forEach(this::enforcePlayer), 20L, 20L);
        getLogger().info("NetworkStaff is active; audit log and protection cache use shared storage.");
    }

    @Override public void onDisable() {
        voiceAttachments.values().forEach(PermissionAttachment::remove); voiceAttachments.clear();
        if (audit != null) audit.close();
    }

    Path configuredPath(String key, String fallback) throws IOException {
        Path path = getDataFolder().toPath().resolve(getConfig().getString(key, fallback)).normalize().toAbsolutePath();
        Path parent = Files.isDirectory(path) ? path : path.getParent(); if (parent != null) Files.createDirectories(parent);
        return path;
    }

    private Connection dataConnection() throws SQLException {
        Connection connection = DriverManager.getConnection("jdbc:sqlite:" + playerDatabase.toAbsolutePath());
        try (var statement = connection.createStatement()) { statement.execute("PRAGMA busy_timeout=10000"); }
        return connection;
    }

    private void ensurePlayerSchema() throws SQLException {
        try (Connection connection=dataConnection();var statement=connection.createStatement()) {
            statement.execute("CREATE TABLE IF NOT EXISTS moderation_status(uuid TEXT PRIMARY KEY,name TEXT NOT NULL,muted_until INTEGER NOT NULL DEFAULT 0,mute_reason TEXT NOT NULL DEFAULT '',banned_until INTEGER NOT NULL DEFAULT 0,ban_reason TEXT NOT NULL DEFAULT '')");
            statement.execute("CREATE TABLE IF NOT EXISTS moderation_cases(id INTEGER PRIMARY KEY AUTOINCREMENT,uuid TEXT NOT NULL,name TEXT NOT NULL,category TEXT NOT NULL,action TEXT NOT NULL,details TEXT NOT NULL,actor TEXT NOT NULL,created INTEGER NOT NULL)");
            statement.execute("CREATE TABLE IF NOT EXISTS player_names(name TEXT PRIMARY KEY,uuid TEXT NOT NULL)");
            statement.execute("CREATE TABLE IF NOT EXISTS player_wipes(owner TEXT PRIMARY KEY,created INTEGER NOT NULL)");
            statement.execute("CREATE TABLE IF NOT EXISTS player_state(owner TEXT PRIMARY KEY,data BLOB NOT NULL,updated INTEGER NOT NULL)");
            for (String column : List.of("mute_actor TEXT NOT NULL DEFAULT 'SYSTEM'","ban_actor TEXT NOT NULL DEFAULT 'SYSTEM'","frozen_until INTEGER NOT NULL DEFAULT 0","freeze_reason TEXT NOT NULL DEFAULT ''","freeze_actor TEXT NOT NULL DEFAULT 'SYSTEM'")) {
                try { statement.execute("ALTER TABLE moderation_status ADD COLUMN " + column); } catch (SQLException duplicate) { if (!duplicate.getMessage().toLowerCase(Locale.ROOT).contains("duplicate column")) throw duplicate; }
            }
        }
    }

    LegacyComponentSerializer serializer() { return AMP; }
    Component legacy(String message) { return AMP.deserialize(message).decoration(TextDecoration.ITALIC, false); }
    StaffActionLogger audit() { return audit; }

    String serverName() {
        var core = Bukkit.getPluginManager().getPlugin("SkyNetworkCore");
        if (core instanceof JavaPlugin plugin) return plugin.getConfig().getString("network.server-id", "paper");
        return getConfig().getString("server-name", "paper");
    }

    void logAction(String type, StaffActor actor, UUID target, String targetName, String reason, String result, String details) {
        if (audit == null) return;
        if (result.equals("FAILED") && !getConfig().getBoolean("staff-actions.log-failed-actions", true)) return;
        if (result.equals("BLOCKED") && !getConfig().getBoolean("staff-actions.log-blocked-actions", true)) return;
        String actorType=actor.type();
        if (actorType.equals("CONSOLE") && !getConfig().getBoolean("staff-actions.log-console-actions", true)) return;
        if (actorType.equals("SYSTEM") && !getConfig().getBoolean("staff-actions.log-system-actions", true)) return;
        audit.record(new StaffAction(UUID.randomUUID().toString(),type.toUpperCase(Locale.ROOT),actorType,actor.uuid(),actor.name(),target,targetName,reason,serverName(),System.currentTimeMillis(),result,details));
    }

    private boolean permitted(CommandSender sender, String permission, String action, String[] args) {
        if (sender.hasPermission(permission)) return true;
        StaffActor actor=StaffActor.from(sender,this); UUID target=args.length==0?null:lookup(args[0]);
        logAction(action,actor,target,args.length==0?"":args[0],args.length>1?String.join(" ",args):"","FAILED","Permission denied");
        sender.sendMessage(legacy("&cYou don't have permission.")); return false;
    }

    UUID lookup(String name) {
        Player online=Bukkit.getPlayerExact(name); if(online!=null)return online.getUniqueId();
        try { return UUID.fromString(name); } catch(IllegalArgumentException ignored) { }
        try(Connection connection=dataConnection();PreparedStatement query=connection.prepareStatement("SELECT uuid FROM player_names WHERE lower(name)=lower(?) LIMIT 1")) {
            query.setString(1,name);try(ResultSet result=query.executeQuery()){if(result.next())return UUID.fromString(result.getString(1));}
        } catch(Exception exception) { getLogger().warning("Player lookup failed: "+exception.getMessage()); }
        return null;
    }

    private String cachedName(UUID uuid, String fallback) {
        Player online=Bukkit.getPlayer(uuid);if(online!=null)return online.getName();
        try(Connection connection=dataConnection();PreparedStatement query=connection.prepareStatement("SELECT name FROM player_names WHERE uuid=? ORDER BY rowid DESC LIMIT 1")) { query.setString(1,uuid.toString());try(ResultSet row=query.executeQuery()){if(row.next())return row.getString(1);} }
        catch(Exception ignored) { }
        return fallback==null?uuid.toString():fallback;
    }

    private long duration(String value) {
        if(value.equalsIgnoreCase("perm")||value.equalsIgnoreCase("permanent"))return Long.MAX_VALUE;
        var matcher=Pattern.compile("(?i)(\\d+)([smhdw])").matcher(value);if(!matcher.matches())return -1;
        try { long factor=switch(matcher.group(2).toLowerCase(Locale.ROOT)){case "s"->1_000L;case "m"->60_000L;case "h"->3_600_000L;case "d"->86_400_000L;default->604_800_000L;};return Math.addExact(System.currentTimeMillis(),Math.multiplyExact(Long.parseLong(matcher.group(1)),factor)); }
        catch(ArithmeticException|NumberFormatException exception){return -1;}
    }

    private record Status(long mutedUntil,String muteReason,String muteActor,long bannedUntil,String banReason,String banActor,long frozenUntil,String freezeReason,String freezeActor) { }
    private Status status(UUID uuid) {
        try(Connection connection=dataConnection();PreparedStatement query=connection.prepareStatement("SELECT * FROM moderation_status WHERE uuid=?")) {
            query.setString(1,uuid.toString());try(ResultSet row=query.executeQuery()){if(!row.next())return new Status(0,"","SYSTEM",0,"","SYSTEM",0,"","SYSTEM");return new Status(row.getLong("muted_until"),row.getString("mute_reason"),row.getString("mute_actor"),row.getLong("banned_until"),row.getString("ban_reason"),row.getString("ban_actor"),row.getLong("frozen_until"),row.getString("freeze_reason"),row.getString("freeze_actor"));}
        } catch(SQLException exception){getLogger().warning("Could not read moderation status: "+exception.getMessage());return new Status(0,"","SYSTEM",0,"","SYSTEM",0,"","SYSTEM");}
    }

    boolean updateModerationStatus(UUID uuid,String name,String action,long expires,String reason,String actor) {
        String column,reasonColumn,actorColumn;
        switch(action.toUpperCase(Locale.ROOT)) {
            case "MUTE" -> {column="muted_until";reasonColumn="mute_reason";actorColumn="mute_actor";}
            case "BAN","REPORT_BAN" -> {column="banned_until";reasonColumn="ban_reason";actorColumn="ban_actor";}
            case "FREEZE" -> {column="frozen_until";reasonColumn="freeze_reason";actorColumn="freeze_actor";}
            default -> {return false;}
        }
        synchronized(dataLock) {
            try(Connection connection=dataConnection();PreparedStatement query=connection.prepareStatement("INSERT INTO moderation_status(uuid,name,"+column+","+reasonColumn+","+actorColumn+") VALUES(?,?,?,?,?) ON CONFLICT(uuid) DO UPDATE SET name=excluded.name,"+column+"=excluded."+column+","+reasonColumn+"=excluded."+reasonColumn+","+actorColumn+"=excluded."+actorColumn)) {
                query.setString(1,uuid.toString());query.setString(2,name);query.setLong(3,expires);query.setString(4,reason);query.setString(5,actor);query.executeUpdate();return true;
            } catch(SQLException exception){getLogger().warning("Could not update moderation status: "+exception.getMessage());return false;}
        }
    }

    private boolean clearModeration(UUID uuid,String name,String action,String actor) {
        String column,reasonColumn,actorColumn;
        switch(action){case "UNMUTE"->{column="muted_until";reasonColumn="mute_reason";actorColumn="mute_actor";}case "UNBAN","REPORT_UNBAN"->{column="banned_until";reasonColumn="ban_reason";actorColumn="ban_actor";}case "UNFREEZE"->{column="frozen_until";reasonColumn="freeze_reason";actorColumn="freeze_actor";}default->{return false;}}
        try(Connection connection=dataConnection();PreparedStatement query=connection.prepareStatement("INSERT INTO moderation_status(uuid,name,"+column+","+reasonColumn+","+actorColumn+") VALUES(?,?,0,'',?) ON CONFLICT(uuid) DO UPDATE SET name=excluded.name,"+column+"=0,"+reasonColumn+"='',"+actorColumn+"=excluded."+actorColumn)) {
            query.setString(1,uuid.toString());query.setString(2,name);query.setString(3,actor);query.executeUpdate();return true;
        } catch(SQLException exception){getLogger().warning("Could not clear moderation status: "+exception.getMessage());return false;}
    }

    boolean protectionAllows(CommandSender sender,UUID target,String targetName,String action,StaffActor actor) {
        String key=switch(action.toUpperCase(Locale.ROOT)){case "BAN","REPORT_BAN"->"block-ban";case "MUTE"->"block-mute";case "KICK"->"block-kick";case "FREEZE"->"block-freeze";case "WIPE"->"block-wipe";case "WARN","OFFEND"->"block-warn";default->"block-"+action.toLowerCase(Locale.ROOT);};
        if(!getConfig().getBoolean("protection.enabled",true)||!getConfig().getBoolean("protection."+key,true))return true;
        String permission=getConfig().getString("protection.permission","networkstaff.protected");
        Player online=Bukkit.getPlayer(target);
        StaffActionLogger.ProtectionState state;
        if(online!=null){state=online.hasPermission(permission)?StaffActionLogger.ProtectionState.PROTECTED:StaffActionLogger.ProtectionState.UNPROTECTED;audit.updateProtection(target,online.getName(),state==StaffActionLogger.ProtectionState.PROTECTED);}
        else state=audit.protection(target,java.util.concurrent.TimeUnit.DAYS.toMillis(getConfig().getLong("protection.cache-max-age-days",30)));
        boolean protectedPlayer=state==StaffActionLogger.ProtectionState.PROTECTED || (state==StaffActionLogger.ProtectionState.UNKNOWN&&getConfig().getBoolean("protection.unknown-offline-blocks-punishment",true));
        boolean override=getConfig().getBoolean("protection.allow-explicit-override",false)&&sender.hasPermission(getConfig().getString("protection.override-permission","networkstaff.protected.override"));
        if(!protectedPlayer||override){if(override&&protectedPlayer)logAction("PROTECTION_OVERRIDE",actor,target,targetName,action,"SUCCESS","Explicit override permission used");return true;}
        String details=state==StaffActionLogger.ProtectionState.PROTECTED?"BLOCKED – PROTECTED PLAYER":"BLOCKED – protection state is unknown; fail-closed policy";
        logAction(action,actor,target,targetName,"", "BLOCKED",details);
        sender.sendMessage(legacy("&cThis player is protected from moderation actions."));return false;
    }

    void enforcePlayer(Player player) {
        UUID uuid=player.getUniqueId();cacheProtection(player);Status current=status(uuid);long now=System.currentTimeMillis();
        if(current.bannedUntil()==Long.MAX_VALUE||current.bannedUntil()>now){player.kick(banScreen(uuid));return;}
        if(current.mutedUntil()>0&&(current.mutedUntil()==Long.MAX_VALUE||current.mutedUntil()>now)){
            if(!voiceAttachments.containsKey(uuid)){PermissionAttachment attachment=player.addAttachment(this);attachment.setPermission("voicechat.speak",false);voiceAttachments.put(uuid,attachment);}
        } else {PermissionAttachment attachment=voiceAttachments.remove(uuid);if(attachment!=null)attachment.remove();}
        if(current.frozenUntil()>now||current.frozenUntil()==Long.MAX_VALUE)frozenActors.put(uuid,current.freezeActor());else frozenActors.remove(uuid);
    }

    private void cacheProtection(Player player) { audit.updateProtection(player.getUniqueId(),player.getName(),player.hasPermission(getConfig().getString("protection.permission","networkstaff.protected"))); }

    private boolean active(long expires) { return expires==Long.MAX_VALUE||expires>System.currentTimeMillis(); }
    private Component banScreen(UUID uuid) {
        Status current=status(uuid);String actor=current.banActor()==null||current.banActor().isBlank()?"SYSTEM":current.banActor();
        StringBuilder text=new StringBuilder("&cBanned on ").append(DATE.format(Instant.now())).append("\n&fUsername: &c").append(cachedName(uuid,uuid.toString())).append("\n&fReason: &c").append(current.banReason()).append("\n&fBanned by: &c").append(actor);
        if(current.bannedUntil()!=Long.MAX_VALUE)text.append("\n&fTime Left: &c").append(formatRemaining(Math.max(0,current.bannedUntil()-System.currentTimeMillis())));
        String link=getConfig().getString("discord-link","https://discord.gg/CHANGE-ME");return AMP.deserialize(text.toString()+"\n\n&eYou can submit an unban application\n&e"+link).clickEvent(ClickEvent.openUrl(link)).decoration(TextDecoration.ITALIC,false);
    }

    private String formatRemaining(long millis) { long seconds=Math.max(0,millis/1000);long days=seconds/86400;seconds%=86400;long hours=seconds/3600;seconds%=3600;long minutes=seconds/60;seconds%=60;return (days>0?days+"d ":"")+(hours>0?hours+"h ":"")+(minutes>0?minutes+"m ":"")+seconds+"s"; }

    private void sendProxyKick(CommandSender sender,UUID target,String targetName,String reason) {
        if(sender instanceof Player carrier){try{java.io.ByteArrayOutputStream bytes=new java.io.ByteArrayOutputStream();java.io.DataOutputStream out=new java.io.DataOutputStream(bytes);out.writeUTF("STAFF_KICK");out.writeUTF(target.toString());out.writeUTF(targetName);out.writeUTF(reason);out.writeUTF(sender.getName());carrier.sendPluginMessage(this,"skynetwork:network",bytes.toByteArray());}catch(IOException exception){logAction("KICK",StaffActor.from(sender,this),target,targetName,reason,"FAILED","Could not route kick to Velocity: "+exception.getMessage());}}
        else logAction("KICK",StaffActor.from(sender,this),target,targetName,reason,"FAILED","No remote-player route available to console command");
    }

    private static final class WipeResult { final List<String> changes=new ArrayList<>();final List<String> failures=new ArrayList<>(); }
    private WipeResult wipePlayer(UUID target,String name) {
        WipeResult outcome=new WipeResult();
        try(Connection connection=dataConnection()) {
            connection.setAutoCommit(false);
            try {
                for(String table:List.of("accounts","stats","prefs","homes","player_state","player_profiles"))try(PreparedStatement delete=connection.prepareStatement("DELETE FROM "+table+" WHERE "+(table.equals("accounts")||table.equals("stats")||table.equals("prefs")?"uuid":"owner")+"=?")){delete.setString(1,target.toString());outcome.changes.add(table+"="+delete.executeUpdate());}
                try(PreparedStatement wipe=connection.prepareStatement("INSERT INTO player_wipes(owner,created) VALUES(?,?) ON CONFLICT(owner) DO UPDATE SET created=excluded.created")){wipe.setString(1,target.toString());wipe.setLong(2,System.currentTimeMillis());wipe.executeUpdate();}
                connection.commit();
            } catch(Exception exception){connection.rollback();throw exception;}
        } catch(Exception exception){outcome.failures.add("player database: "+exception.getMessage());}
        deleteFromDatabase(auctionsDatabase,"DELETE FROM listings WHERE seller=?",target,"auctions",outcome);
        deleteFromDatabase(ordersDatabase,"DELETE FROM orders WHERE owner=?",target,"orders",outcome);
        try {
            Path base=playerShops.toAbsolutePath().normalize();Path file=base.resolve(target+".yml").normalize();
            if(!file.startsWith(base))throw new IOException("resolved shop path escaped configured directory");
            boolean deleted=Files.deleteIfExists(file);outcome.changes.add("player-shop-file="+(deleted?"deleted":"absent"));
        } catch(IOException exception){outcome.failures.add("player shop: "+exception.getMessage());}
        Player local=Bukkit.getPlayer(target);if(local!=null)clearInventory(local);
        return outcome;
    }

    private void deleteFromDatabase(Path path,String sql,UUID target,String label,WipeResult outcome) {
        try(Connection connection=DriverManager.getConnection("jdbc:sqlite:"+path.toAbsolutePath());PreparedStatement query=connection.prepareStatement(sql)) {try(var statement=connection.createStatement()){statement.execute("PRAGMA busy_timeout=10000");}query.setString(1,target.toString());outcome.changes.add(label+"="+query.executeUpdate());}
        catch(Exception exception){outcome.failures.add(label+" database: "+exception.getMessage());}
    }

    private void clearInventory(Player player) { player.getInventory().clear();player.getInventory().setArmorContents(null);player.getInventory().setExtraContents(null);player.getEnderChest().clear();player.setLevel(0);player.setExp(0);player.setTotalExperience(0);player.updateInventory(); }

    private void reloadTerms(){blockedTerms.clear();for(String term:getConfig().getStringList("filter.blocked-terms")){String value=normalize(term);if(!value.isBlank())blockedTerms.add(value);}}
    private String normalize(String input){String value=Normalizer.normalize(input,Normalizer.Form.NFKD).toLowerCase(Locale.ROOT).replaceAll("§[0-9a-fk-orx]","").replaceAll("&[0-9a-fk-orx]","").replace('0','o').replace('1','i').replace('3','e').replace('4','a').replace('5','s').replace('7','t');return value.replaceAll("\\p{M}+","").replaceAll("[^\\p{L}\\p{N}]+"," ").trim().replaceAll("\\s+"," ");}
    private boolean containsBlocked(String text){String normalized=normalize(text);if(normalized.isBlank())return false;for(String term:blockedTerms){if(Pattern.compile("(?<![\\p{L}\\p{N}])"+Pattern.quote(term)+"(?![\\p{L}\\p{N}])").matcher(normalized).find())return true;String compact=term.replace(" ","");for(String word:normalized.split(" "))if(word.equals(compact))return true;}return false;}

    private boolean blockedText(Player player,String channel,String text) {
        Status current=status(player.getUniqueId());if(active(current.mutedUntil())){player.sendMessage(legacy("&cYou are muted by &e"+current.muteActor()+"&c. Reason: &e"+current.muteReason()));return true;}
        if(player.hasPermission("networkstaff.filter.bypass")||!getConfig().getBoolean("filter.enabled",true)||!containsBlocked(text))return false;
        StaffActor actor=StaffActor.from(player,this);logAction("FILTER_BLOCK_"+channel.toUpperCase(Locale.ROOT),actor,player.getUniqueId(),player.getName(),"","BLOCKED","Blocked text in "+channel);
        player.sendMessage(legacy("&cThat message was blocked by the network filter."));return true;
    }

    @EventHandler(priority=EventPriority.LOWEST) public void chat(AsyncChatEvent event){if(blockedText(event.getPlayer(),"CHAT",PLAIN.serialize(event.message())))event.setCancelled(true);}
    @EventHandler(priority=EventPriority.LOWEST) public void sign(SignChangeEvent event){String text=event.lines().stream().map(PLAIN::serialize).reduce((a,b)->a+" | "+b).orElse("");if(blockedText(event.getPlayer(),"SIGN",text))event.setCancelled(true);}
    @EventHandler(priority=EventPriority.LOWEST) public void book(PlayerEditBookEvent event){BookMeta meta=event.getNewBookMeta();String text=(meta.hasTitle()?meta.getTitle()+" ":"")+String.join(" ",meta.getPages());if(blockedText(event.getPlayer(),"BOOK",text))event.setCancelled(true);}
    @EventHandler(priority=EventPriority.LOWEST) public void anvil(PrepareAnvilEvent event){if(event.getView().getPlayer() instanceof Player player){String text=event.getInventory().getRenameText();if(text!=null&&blockedText(player,"ANVIL",text))event.setResult(null);}}
    @EventHandler(priority=EventPriority.LOWEST) public void anvilClick(InventoryClickEvent event){if(event.getWhoClicked() instanceof Player player&&event.getInventory() instanceof AnvilInventory inventory&&event.getRawSlot()==2){String text=inventory.getRenameText();if(text!=null&&blockedText(player,"ANVIL",text))event.setCancelled(true);}}
    @EventHandler(priority=EventPriority.LOWEST) public void commandText(PlayerCommandPreprocessEvent event){String message=event.getMessage();Status current=status(event.getPlayer().getUniqueId());if(active(current.mutedUntil())){String root=message.substring(1).split(" ",2)[0].toLowerCase(Locale.ROOT);if(!List.of("help","home","rtp","whereami","balance","bal","unmute","staffactions").contains(root)){event.setCancelled(true);event.getPlayer().sendMessage(legacy("&cYou are muted and cannot use communication commands."));return;}}if(blockedText(event.getPlayer(),"COMMAND",message))event.setCancelled(true);}

    @EventHandler public void join(PlayerJoinEvent event){Player player=event.getPlayer();cacheProtection(player);try(Connection connection=dataConnection();PreparedStatement query=connection.prepareStatement("INSERT INTO player_names(name,uuid) VALUES(?,?) ON CONFLICT(name) DO UPDATE SET uuid=excluded.uuid")){query.setString(1,player.getName().toLowerCase(Locale.ROOT));query.setString(2,player.getUniqueId().toString());query.executeUpdate();}catch(SQLException exception){getLogger().warning(exception.getMessage());}Bukkit.getScheduler().runTaskLater(this,()->enforcePlayer(player),1L);}
    @EventHandler public void quit(PlayerQuitEvent event){PermissionAttachment attachment=voiceAttachments.remove(event.getPlayer().getUniqueId());if(attachment!=null)attachment.remove();frozenActors.remove(event.getPlayer().getUniqueId());}
    @EventHandler public void movement(PlayerMoveEvent event){String actor=frozenActors.get(event.getPlayer().getUniqueId());if(actor==null||event.getTo()==null)return;if(event.getFrom().getX()!=event.getTo().getX()||event.getFrom().getY()!=event.getTo().getY()||event.getFrom().getZ()!=event.getTo().getZ())event.setTo(event.getFrom());}
    @EventHandler public void interact(PlayerInteractEvent event){if(frozenActors.containsKey(event.getPlayer().getUniqueId()))event.setCancelled(true);}
    @EventHandler public void gameMode(PlayerGameModeChangeEvent event){Bukkit.getScheduler().runTask(this,()->logAction("GAMEMODE",StaffActor.system(this),event.getPlayer().getUniqueId(),event.getPlayer().getName(),"","SUCCESS",event.getPlayer().getGameMode()+" -> "+event.getNewGameMode()));}
    @EventHandler public void teleport(PlayerTeleportEvent event){if(event.getCause()==PlayerTeleportEvent.TeleportCause.COMMAND)logAction("TELEPORT",StaffActor.system(this),event.getPlayer().getUniqueId(),event.getPlayer().getName(),"","SUCCESS","Command teleport; cause=COMMAND");}
    @EventHandler public void death(PlayerDeathEvent event){/* keep death messages and inventory semantics owned by the game/server config */}


    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] args){
        String cmd=command.getName().toLowerCase(Locale.ROOT);
        if(cmd.equals("staffactions"))return staffActions(sender,args);
        if(cmd.equals("staffnote"))return staffNote(sender,args);
        if(cmd.equals("ban")||cmd.equals("reportban")||cmd.equals("mute")){String perm=cmd.equals("mute")?"networkstaff.mute":"networkstaff.ban";if(!permitted(sender,perm,cmd.toUpperCase(Locale.ROOT),args))return true;if(args.length<3)return failed(sender,cmd,args,"Expected target, duration, and reason");UUID target=lookup(args[0]);long expiry=duration(args[1]);if(target==null||expiry<0)return failed(sender,cmd,args,"Unknown target or duration");String reason=String.join(" ",Arrays.copyOfRange(args,2,args.length));punishments.apply(sender,target,cachedName(target,args[0]),cmd.equals("mute")?"MUTE":cmd.equals("reportban")?"REPORT_BAN":"BAN",expiry,reason,cmd.equals("reportban")?"Report ban":"");return true;}
        if(cmd.equals("unban")||cmd.equals("reportunban")||cmd.equals("unmute")||cmd.equals("unfreeze")){String permission=cmd.equals("unmute")?"networkstaff.mute":cmd.equals("unfreeze")?"networkstaff.freeze":"networkstaff.ban";if(!permitted(sender,permission,cmd.toUpperCase(Locale.ROOT),args))return true;if(args.length<1)return failed(sender,cmd,args,"Missing player");UUID target=lookup(args[0]);if(target==null)return failed(sender,cmd,args,"Unknown player");String action=cmd.equals("unban")?"UNBAN":cmd.equals("reportunban")?"REPORT_UNBAN":cmd.equals("unmute")?"UNMUTE":"UNFREEZE";boolean changed=clearModeration(target,cachedName(target,args[0]),action,sender.getName());logAction(action,StaffActor.from(sender,this),target,cachedName(target,args[0]),"",changed?"SUCCESS":"FAILED","Status revoked");if(changed){sender.sendMessage(legacy("&a"+action.toLowerCase(Locale.ROOT)+" completed for &e"+args[0]+"&a."));Player local=Bukkit.getPlayer(target);if(local!=null)enforcePlayer(local);}return true;}
        if(cmd.equals("kick")){if(!permitted(sender,"networkstaff.kick","KICK",args))return true;if(args.length<1)return failed(sender,cmd,args,"Missing player");UUID target=lookup(args[0]);if(target==null)return failed(sender,cmd,args,"Unknown player");String reason=args.length>1?String.join(" ",Arrays.copyOfRange(args,1,args.length)):"Kicked by staff";if(!punishments.allow(sender,target,cachedName(target,args[0]),"KICK"))return true;Player local=Bukkit.getPlayer(target);if(local!=null){local.kick(legacy("&cYou were kicked from the network\n&7Reason: &e"+reason+"\n&7Kicked by: &e"+sender.getName()));logAction("KICK",StaffActor.from(sender,this),target,local.getName(),reason,"SUCCESS","Local kick");}else{sendProxyKick(sender,target,cachedName(target,args[0]),reason);sender.sendMessage(legacy("&aKick request sent for &e"+args[0]+"&a."));logAction("KICK",StaffActor.from(sender,this),target,args[0],reason,"SUCCESS","Routed to Velocity");}return true;}
        if(cmd.equals("freeze")){if(!permitted(sender,"networkstaff.freeze","FREEZE",args))return true;if(args.length<3)return failed(sender,cmd,args,"Expected player, duration, and reason");UUID target=lookup(args[0]);long expiry=duration(args[1]);if(target==null||expiry<0)return failed(sender,cmd,args,"Unknown player or duration");String reason=String.join(" ",Arrays.copyOfRange(args,2,args.length));punishments.apply(sender,target,cachedName(target,args[0]),"FREEZE",expiry,reason,"");return true;}
        if(cmd.equals("warn")){if(!permitted(sender,"networkstaff.warn","WARN",args))return true;if(args.length<2)return failed(sender,cmd,args,"Expected player and reason");UUID target=lookup(args[0]);if(target==null)return failed(sender,cmd,args,"Unknown player");String reason=String.join(" ",Arrays.copyOfRange(args,1,args.length));if(!punishments.allow(sender,target,cachedName(target,args[0]),"WARN"))return true;logAction("WARN",StaffActor.from(sender,this),target,cachedName(target,args[0]),reason,"SUCCESS","Warning issued");Player local=Bukkit.getPlayer(target);if(local!=null)local.sendMessage(legacy("&cYou received a warning from &e"+sender.getName()+"&c: &f"+reason));sender.sendMessage(legacy("&aWarning recorded for &e"+args[0]+"&a."));return true;}
        if(cmd.equals("offend"))return offend(sender,args);
        if(cmd.equals("punish"))return punish(sender,args);
        if(cmd.equals("wipe"))return wipeCommand(sender,args);
        return true;
    }

    private boolean failed(CommandSender sender,String cmd,String[] args,String details){logAction(cmd.toUpperCase(Locale.ROOT),StaffActor.from(sender,this),args.length==0?null:lookup(args[0]),args.length==0?"":args[0],args.length>1?String.join(" ",args):"","FAILED",details);return true;}

    private int categoryEnd(String[] args,int start){for(int end=args.length;end>start;end--){String candidate=String.join(" ",Arrays.copyOfRange(args,start,end));if(CATEGORIES.stream().anyMatch(value->value.equalsIgnoreCase(candidate)))return end;}return -1;}

    private boolean offend(CommandSender sender,String[] args){if(!permitted(sender,"networkstaff.punish","OFFEND",args))return true;if(args.length<2)return failed(sender,"offend",args,"Missing target or category");UUID target=lookup(args[0]);int end=categoryEnd(args,1);if(target==null||end<0)return failed(sender,"offend",args,"Player or preset category not found");String category=String.join(" ",Arrays.copyOfRange(args,1,end));String details=end<args.length?String.join(" ",Arrays.copyOfRange(args,end,args.length)):"";if(!punishments.allow(sender,target,cachedName(target,args[0]),"OFFEND"))return true;recordCase(target,cachedName(target,args[0]),category,"OFFEND",details,StaffActor.from(sender,this));logAction("OFFEND",StaffActor.from(sender,this),target,cachedName(target,args[0]),category,"SUCCESS",details);sender.sendMessage(legacy("&aCase recorded for &e"+args[0]+"&a."));return true;}

    private boolean punish(CommandSender sender,String[] args){if(!permitted(sender,"networkstaff.punish","PUNISH",args))return true;if(args.length<4)return failed(sender,"punish",args,"Missing target/category/action");UUID target=lookup(args[0]);int actionIndex=-1;for(int i=2;i<args.length;i++)if(PUNISHMENT_WORDS.contains(args[i].toLowerCase(Locale.ROOT))){actionIndex=i;break;}if(target==null||actionIndex<0)return failed(sender,"punish",args,"Could not parse preset category and action");String category=String.join(" ",Arrays.copyOfRange(args,1,actionIndex));if(CATEGORIES.stream().noneMatch(value->value.equalsIgnoreCase(category)))return failed(sender,"punish",args,"Preset category not found");String action=args[actionIndex].toLowerCase(Locale.ROOT);if(action.equals("wipe")){String reason=String.join(" ",Arrays.copyOfRange(args,actionIndex+1,args.length));return executeWipe(sender,target,cachedName(target,args[0]),reason.isBlank()?category:category+": "+reason);}if(actionIndex+2>=args.length)return failed(sender,"punish",args,"Missing duration or reason");long expiry=duration(args[actionIndex+1]);if(expiry<0)return failed(sender,"punish",args,"Invalid duration");String reason=String.join(" ",Arrays.copyOfRange(args,actionIndex+2,args.length));if(action.equals("kick")){if(!punishments.allow(sender,target,cachedName(target,args[0]),"KICK"))return true;Player local=Bukkit.getPlayer(target);if(local!=null)local.kick(legacy("&cYou were kicked\n&7Reason: &e"+reason+"\n&7Kicked by: &e"+sender.getName()));logAction("PUNISH_KICK",StaffActor.from(sender,this),target,cachedName(target,args[0]),reason,"SUCCESS",category);return true;}punishments.apply(sender,target,cachedName(target,args[0]),action.toUpperCase(Locale.ROOT),expiry,reason,category);return true;}

    private boolean wipeCommand(CommandSender sender,String[] args){if(!permitted(sender,"networkstaff.wipe","WIPE",args))return true;if(args.length<1)return failed(sender,"wipe",args,"Missing player");UUID target=lookup(args[0]);if(target==null)return failed(sender,"wipe",args,"Unknown player");String reason=args.length>1?String.join(" ",Arrays.copyOfRange(args,1,args.length)):"Wipe";return executeWipe(sender,target,cachedName(target,args[0]),reason);}

    private boolean executeWipe(CommandSender sender,UUID target,String name,String reason){StaffActor actor=StaffActor.from(sender,this);if(!punishments.allow(sender,target,name,"WIPE"))return true;WipeResult result=wipePlayer(target,name);String details=String.join(", ",result.changes)+(result.failures.isEmpty()?"":"; FAILED: "+String.join("; ",result.failures));logAction("WIPE",actor,target,name,reason,result.failures.isEmpty()?"SUCCESS":"FAILED",details);if(result.failures.isEmpty())sender.sendMessage(legacy("&aWiped inventory, enderchest, money, stats, auctions, orders and personal shop data for &e"+name+"&a."));else sender.sendMessage(legacy("&cWipe partially failed; see staffactions details: &f"+String.join("; ",result.failures)));return true;}

    private void recordCase(UUID target,String name,String category,String action,String details,StaffActor actor){try(Connection connection=dataConnection();PreparedStatement query=connection.prepareStatement("INSERT INTO moderation_cases(uuid,name,category,action,details,actor,created) VALUES(?,?,?,?,?,?,?)")){query.setString(1,target.toString());query.setString(2,name);query.setString(3,category);query.setString(4,action);query.setString(5,details);query.setString(6,actor.name());query.setLong(7,System.currentTimeMillis());query.executeUpdate();}catch(SQLException exception){logAction(action,actor,target,name,category,"FAILED","Case record failed: "+exception.getMessage());}}

    private boolean staffNote(CommandSender sender,String[] args){if(!permitted(sender,"networkstaff.notes","STAFF_NOTE",args))return true;if(args.length<2)return failed(sender,"staffnote",args,"Missing subcommand or target");String sub=args[0].toLowerCase(Locale.ROOT);StaffActor actor=StaffActor.from(sender,this);if(sub.equals("add")){if(args.length<3)return failed(sender,"staffnote",args,"Missing note text");UUID target=lookup(args[1]);if(target==null)return failed(sender,"staffnote",args,"Unknown player");String note=String.join(" ",Arrays.copyOfRange(args,2,args.length));audit.addNote(target,cachedName(target,args[1]),actor,note).thenAccept(ok->Bukkit.getScheduler().runTask(this,()->{logAction("STAFF_NOTE_CREATE",actor,target,cachedName(target,args[1]),"",ok?"SUCCESS":"FAILED",note);sender.sendMessage(legacy(ok?"&aStaff note created.":"&cCould not create staff note."));}));return true;}if(sub.equals("edit")||sub.equals("delete")){if(args.length<(sub.equals("edit")?3:2))return failed(sender,"staffnote",args,"Invalid note arguments");long id;try{id=Long.parseLong(args[1]);}catch(NumberFormatException exception){return failed(sender,"staffnote",args,"Invalid note id");}String text=sub.equals("edit")?String.join(" ",Arrays.copyOfRange(args,2,args.length)):"";(sub.equals("edit")?audit.updateNote(id,text):audit.deleteNote(id)).thenAccept(ok->Bukkit.getScheduler().runTask(this,()->{logAction(sub.equals("edit")?"STAFF_NOTE_EDIT":"STAFF_NOTE_DELETE",actor,null,"","",ok?"SUCCESS":"FAILED","note_id="+id+(text.isBlank()?"":"; "+text));sender.sendMessage(legacy(ok?"&aStaff note updated.":"&cStaff note was not found."));}));return true;}return failed(sender,"staffnote",args,"Unknown note operation");}

    private boolean staffActions(CommandSender sender,String[] args){if(!(sender instanceof Player player)){sender.sendMessage(legacy("&cPlayers only."));return true;}if(!permitted(sender,"networkstaff.staffactions","STAFF_ACTIONS",args))return true;StaffActionFilter filter=StaffActionFilter.empty();int page=0;boolean scoped=args.length>0;
        if(scoped&&!player.hasPermission("networkstaff.staffactions.all")&&!player.hasPermission("networkstaff.staffactions.search")){sender.sendMessage(legacy("&cYou need networkstaff.staffactions.search to apply log filters."));return true;}
        if(args.length==0){if(!player.hasPermission("networkstaff.staffactions.all"))filter=new StaffActionFilter(player.getUniqueId(),null,null,null,null,null,null);}
        else {String option=args[0].toLowerCase(Locale.ROOT);if(option.equals("reload")){if(!permitted(sender,"networkstaff.staffactions.reload","STAFF_ACTIONS_RELOAD",args))return true;reloadConfig();reloadTerms();logAction("STAFF_ACTIONS_RELOAD",StaffActor.from(sender,this),null,"","","SUCCESS","NetworkStaff config reloaded");sender.sendMessage(legacy("&aNetworkStaff config reloaded."));return true;}if(option.equals("page")){if(args.length>1)try{page=Math.max(0,Integer.parseInt(args[1])-1);}catch(NumberFormatException ignored){} }
            else if(option.equals("staff")&&args.length>1){UUID id=lookup(args[1]);filter=new StaffActionFilter(id,args[1],null,null,null,null,null);}
            else if(option.equals("search")&&args.length>1)filter=new StaffActionFilter(null,null,null,null,null,null,String.join(" ",Arrays.copyOfRange(args,1,args.length)));
            else if(option.equals("type")&&args.length>1)filter=new StaffActionFilter(null,null,null,args[1],null,null,null);
            else if(option.equals("server")&&args.length>1)filter=new StaffActionFilter(null,null,null,null,args[1],null,null);
            else if(option.equals("date")&&args.length>1)filter=new StaffActionFilter(null,null,null,null,null,args[1],null);
            else filter=new StaffActionFilter(null,null,args[0],null,null,null,null);
        }
        openActions(player,filter,page);return true;
    }

    void openActions(Player player,StaffActionFilter filter,int page){int size=Math.max(1,Math.min(20,getConfig().getInt("staff-actions.pagination-size",10)));int offset=Math.max(0,page)*size;audit.page(filter,offset,size+1).thenAccept(rows->Bukkit.getScheduler().runTask(this,()->{if(!player.isOnline())return;boolean more=rows.size()>size;List<StaffAction> visible=more?rows.subList(0,size):rows;if(player.getProtocolVersion()>=771){try{openActionDialog(player,filter,page,size,visible,more);return;}catch(Throwable exception){getLogger().fine("Dialog UI unavailable; using inventory fallback: "+exception.getMessage());}}openActionInventory(player,filter,page,size,visible,more);}));}

    private void openActionDialog(Player player,StaffActionFilter filter,int page,int size,List<StaffAction> rows,boolean more){
        var options=net.kyori.adventure.text.event.ClickCallback.Options.builder().uses(net.kyori.adventure.text.event.ClickCallback.UNLIMITED_USES).lifetime(java.time.Duration.ofMinutes(5)).build();List<ActionButton> buttons=new ArrayList<>();
        for(StaffAction action:rows){String summary="#"+action.actionId().substring(0,8)+" "+action.actionType()+" "+(action.targetName().isBlank()?"":"- "+action.targetName());buttons.add(ActionButton.builder(Component.text(summary).decoration(TextDecoration.ITALIC,false)).tooltip(Component.text(action.actorName()+" | "+DATE.format(Instant.ofEpochMilli(action.timestamp()))+" | "+action.result())).action(DialogAction.customClick((response,audience)->{if(audience instanceof Player viewer){sendDetails(viewer,action);openActions(viewer,filter,page);}},options)).build());}
        if(page>0)buttons.add(ActionButton.builder(legacy("&fPrevious page")).action(DialogAction.customClick((r,a)->{if(a instanceof Player viewer)openActions(viewer,filter,page-1);},options)).build());
        if(more)buttons.add(ActionButton.builder(legacy("&fNext page")).action(DialogAction.customClick((r,a)->{if(a instanceof Player viewer)openActions(viewer,filter,page+1);},options)).build());
        if(buttons.isEmpty())buttons.add(ActionButton.builder(legacy("&7No actions found")).build());
        var base=DialogBase.builder(legacy("&8Network Staff Actions")).canCloseWithEscape(true).pause(false).afterAction(DialogBase.DialogAfterAction.NONE).body(List.of(io.papermc.paper.registry.data.dialog.body.DialogBody.plainMessage(net.kyori.adventure.text.Component.text("Page "+(page+1)+(filter.keyword()==null?"":" | Search: "+filter.keyword())).decoration(TextDecoration.ITALIC,false),320))).build();
        player.showDialog(io.papermc.paper.dialog.Dialog.create(factory->factory.empty().base(base).type(DialogType.multiAction(buttons).columns(2).build())));
    }

    private void openActionInventory(Player player,StaffActionFilter filter,int page,int size,List<StaffAction> rows,boolean more){ActionsHolder holder=new ActionsHolder(filter,page,rows);Inventory inventory=Bukkit.createInventory(holder,54,Component.text("Network Staff Actions "+(page+1)).decoration(TextDecoration.ITALIC,false));holder.inventory=inventory;for(int i=0;i<rows.size()&&i<size&&i<45;i++){StaffAction action=rows.get(i);Material icon=action.result().equals("BLOCKED")?Material.BARRIER:action.result().equals("FAILED")?Material.REDSTONE_BLOCK:Material.PAPER;ItemStack item=new ItemStack(icon);var meta=item.getItemMeta();meta.displayName(legacy("&f"+action.actionType()+" &7#"+action.actionId().substring(0,8)));List<Component> lore=new ArrayList<>();lore.add(legacy("&7Actor: &f"+action.actorName()));lore.add(legacy("&7Target: &f"+(action.targetName().isBlank()?"-":action.targetName())));lore.add(legacy("&7Result: "+(action.result().equals("SUCCESS")?"&a":action.result().equals("BLOCKED")?"&c":"&e")+action.result()));lore.add(legacy("&7Time: &f"+DATE.format(Instant.ofEpochMilli(action.timestamp()))));if(getConfig().getBoolean("staff-actions.show-server",true))lore.add(legacy("&7Server: &f"+action.serverName()));lore.add(legacy("&7Click to view details"));meta.lore(lore);meta.displayName(meta.displayName().decoration(TextDecoration.ITALIC,false));item.setItemMeta(meta);inventory.setItem(i,item);}if(page>0)put(inventory,45,Material.ARROW,"&fPrevious page");put(inventory,49,Material.BOOK,"&7Page &f"+(page+1));if(more)put(inventory,53,Material.ARROW,"&fNext page");player.openInventory(inventory);}
    private void put(Inventory inventory,int slot,Material material,String title){ItemStack item=new ItemStack(material);var meta=item.getItemMeta();meta.displayName(legacy(title));item.setItemMeta(meta);inventory.setItem(slot,item);}

    private void sendDetails(Player viewer,StaffAction action){viewer.sendMessage(legacy("&8&m--------------------------------"));viewer.sendMessage(legacy("&fAction ID: &7"+action.actionId()));viewer.sendMessage(legacy("&fType: &e"+action.actionType()+" &7| Result: &f"+action.result()));viewer.sendMessage(legacy("&fActor: &e"+action.actorName()+" &7("+action.actorType()+")"));if(action.actorUuid()!=null)viewer.sendMessage(legacy("&fActor UUID: &7"+action.actorUuid()));viewer.sendMessage(legacy("&fTarget: &e"+(action.targetName().isBlank()?"-":action.targetName())));if(action.targetUuid()!=null)viewer.sendMessage(legacy("&fTarget UUID: &7"+action.targetUuid()));viewer.sendMessage(legacy("&fReason: &7"+(action.reason().isBlank()?"-":action.reason())));viewer.sendMessage(legacy("&fTime: &7"+DATE.format(Instant.ofEpochMilli(action.timestamp()))));if(getConfig().getBoolean("staff-actions.show-server",true))viewer.sendMessage(legacy("&fServer: &7"+action.serverName()));viewer.sendMessage(legacy("&fDetails: &7"+(viewer.hasPermission("networkstaff.staffactions.sensitive")?action.details():"[restricted]")));viewer.sendMessage(legacy("&8&m--------------------------------"));}

    @EventHandler public void actionMenuClick(InventoryClickEvent event){if(!(event.getWhoClicked() instanceof Player player)||!(event.getView().getTopInventory().getHolder() instanceof ActionsHolder holder))return;event.setCancelled(true);if(event.getClickedInventory()!=event.getView().getTopInventory())return;int slot=event.getRawSlot();if(slot<holder.actions.size())sendDetails(player,holder.actions.get(slot));else if(slot==45&&holder.page>0)openActions(player,holder.filter,holder.page-1);else if(slot==53)openActions(player,holder.filter,holder.page+1);}
    @EventHandler public void actionMenuDrag(InventoryDragEvent event){if(event.getView().getTopInventory().getHolder() instanceof ActionsHolder)event.setCancelled(true);}

    @Override public List<String> onTabComplete(CommandSender sender,Command command,String alias,String[] args){String cmd=command.getName().toLowerCase(Locale.ROOT);if(args.length==1){return switch(cmd){case "punish","offend"->knownNames(args[0]);case "staffactions"->List.of("staff","search","type","server","date","page","reload","all").stream().filter(v->v.startsWith(args[0].toLowerCase(Locale.ROOT))).toList();case "staffnote"->List.of("add","edit","delete").stream().filter(v->v.startsWith(args[0].toLowerCase(Locale.ROOT))).toList();default->knownNames(args[0]);};}if((cmd.equals("offend")||cmd.equals("punish"))&&args.length==2)return CATEGORIES.stream().filter(v->v.toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))).toList();if(cmd.equals("punish")&&args.length>2)return List.of("mute","ban","wipe","kick","freeze").stream().filter(v->v.startsWith(args[args.length-1].toLowerCase(Locale.ROOT))).toList();if(List.of("ban","reportban","mute","freeze").contains(cmd)&&args.length==2)return List.of("30m","2h","1d","7d","perm");if(args.length==1)return knownNames(args[0]);return List.of();}
    private List<String> knownNames(String prefix){List<String> names=new ArrayList<>();try(Connection connection=dataConnection();PreparedStatement query=connection.prepareStatement("SELECT name FROM player_names WHERE lower(name) LIKE ? ORDER BY name LIMIT 100")){query.setString(1,prefix.toLowerCase(Locale.ROOT)+"%");try(ResultSet rows=query.executeQuery()){while(rows.next())names.add(rows.getString(1));}}catch(SQLException ignored){}for(Player player:Bukkit.getOnlinePlayers())if(player.getName().toLowerCase(Locale.ROOT).startsWith(prefix.toLowerCase(Locale.ROOT))&&!names.contains(player.getName()))names.add(player.getName());return names;}


}