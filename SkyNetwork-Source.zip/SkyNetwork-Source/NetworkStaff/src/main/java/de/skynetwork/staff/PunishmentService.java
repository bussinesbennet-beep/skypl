package de.skynetwork.staff;

import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

/** The only entry point used by NetworkStaff commands to apply restrictions. */
public final class PunishmentService {
    private final NetworkStaffPlugin plugin;

    PunishmentService(NetworkStaffPlugin plugin) { this.plugin = plugin; }

    public boolean apply(CommandSender sender, UUID target, String targetName, String action,
                         long expiresAt, String reason, String category) {
        StaffActor actor = StaffActor.from(sender, plugin);
        if (!plugin.protectionAllows(sender, target, targetName, action, actor)) return false;
        boolean updated = plugin.updateModerationStatus(target, targetName, action, expiresAt, reason, actor.name());
        if (!updated) {
            plugin.logAction(action.toUpperCase(), actor, target, targetName, reason, "FAILED", category+"; status storage failed");
            sender.sendMessage(plugin.legacy("&cThe punishment could not be saved."));
            return false;
        }
        plugin.logAction(action.toUpperCase(), actor, target, targetName, reason, "SUCCESS", category);
        Player local = Bukkit.getPlayer(target);
        if (local != null) plugin.enforcePlayer(local);
        sender.sendMessage(plugin.legacy("&a"+action+" applied to &e"+targetName+"&a."));
        return true;
    }

    public boolean allow(CommandSender sender, UUID target, String targetName, String action) {
        return plugin.protectionAllows(sender,target,targetName,action,StaffActor.from(sender,plugin));
    }
}
