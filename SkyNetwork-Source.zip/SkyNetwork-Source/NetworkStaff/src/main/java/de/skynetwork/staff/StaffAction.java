package de.skynetwork.staff;

import java.util.UUID;

public record StaffAction(String actionId, String actionType, String actorType, UUID actorUuid,
                          String actorName, UUID targetUuid, String targetName, String reason,
                          String serverName, long timestamp, String result, String details) { }
