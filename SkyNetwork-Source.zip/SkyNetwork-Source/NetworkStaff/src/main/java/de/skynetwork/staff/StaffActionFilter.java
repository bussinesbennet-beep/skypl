package de.skynetwork.staff;

import java.util.UUID;

public record StaffActionFilter(UUID actorUuid, String actorName, String targetName,
                               String actionType, String serverName, String date, String keyword) {
    public static StaffActionFilter empty() { return new StaffActionFilter(null, null, null, null, null, null, null); }
}
