package de.skynetwork.staff;

import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

public record StaffActor(String type, UUID uuid, String name) {
    public static StaffActor from(CommandSender sender, NetworkStaffPlugin plugin) {
        if (sender instanceof Player player) return new StaffActor("PLAYER", player.getUniqueId(), player.getName());
        if (sender instanceof ConsoleCommandSender) return new StaffActor("CONSOLE", null,
                plugin.getConfig().getString("actor-display.console-name", "CONSOLE"));
        return new StaffActor("SYSTEM", null, plugin.getConfig().getString("actor-display.system-name", "SYSTEM"));
    }

    public static StaffActor system(NetworkStaffPlugin plugin) {
        return new StaffActor("SYSTEM", null, plugin.getConfig().getString("actor-display.system-name", "SYSTEM"));
    }
}
