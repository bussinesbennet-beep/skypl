package de.skynetwork.staff;

import org.bukkit.plugin.java.JavaPlugin;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;

/** Append-only audit storage shared by all backend instances on this host. */
public final class StaffActionLogger implements AutoCloseable {
    public enum ProtectionState { PROTECTED, UNPROTECTED, UNKNOWN }
    private final JavaPlugin plugin;
    private final Path database;
    private final Path fallback;
    private final ExecutorService writer = Executors.newSingleThreadExecutor(r -> {
        Thread thread = new Thread(r, "NetworkStaff-AuditWriter"); thread.setDaemon(true); return thread;
    });

    public StaffActionLogger(JavaPlugin plugin, Path database, Path fallback) {
        this.plugin = plugin; this.database = database; this.fallback = fallback;
    }

    public void initialize() throws SQLException, IOException {
        Files.createDirectories(database.toAbsolutePath().getParent());
        try (Connection connection = connect(); var statement = connection.createStatement()) {
            statement.execute("CREATE TABLE IF NOT EXISTS staff_actions (action_id TEXT PRIMARY KEY, action_type TEXT NOT NULL, actor_type TEXT NOT NULL, actor_uuid TEXT, actor_name TEXT NOT NULL, target_uuid TEXT, target_name TEXT NOT NULL DEFAULT '', reason TEXT NOT NULL DEFAULT '', server_name TEXT NOT NULL, timestamp INTEGER NOT NULL, result TEXT NOT NULL, details TEXT NOT NULL DEFAULT '')");
            statement.execute("CREATE INDEX IF NOT EXISTS idx_staff_actions_time ON staff_actions(timestamp DESC)");
            statement.execute("CREATE INDEX IF NOT EXISTS idx_staff_actions_actor ON staff_actions(actor_uuid,timestamp DESC)");
            statement.execute("CREATE INDEX IF NOT EXISTS idx_staff_actions_target ON staff_actions(target_uuid,timestamp DESC)");
            statement.execute("CREATE TABLE IF NOT EXISTS staff_protected (uuid TEXT PRIMARY KEY, name TEXT NOT NULL, protected INTEGER NOT NULL, checked_at INTEGER NOT NULL)");
            statement.execute("CREATE TABLE IF NOT EXISTS staff_notes (note_id INTEGER PRIMARY KEY AUTOINCREMENT, target_uuid TEXT NOT NULL, target_name TEXT NOT NULL, actor_type TEXT NOT NULL, actor_uuid TEXT, actor_name TEXT NOT NULL, note TEXT NOT NULL, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)");
        }
    }

    private Connection connect() throws SQLException {
        Connection connection = DriverManager.getConnection("jdbc:sqlite:" + database.toAbsolutePath());
        try (var statement = connection.createStatement()) { statement.execute("PRAGMA busy_timeout=10000"); }
        return connection;
    }

    public void record(StaffAction action) {
        if (!plugin.getConfig().getBoolean("staff-actions.enabled", true)) return;
        writer.execute(() -> {
            String sql = "INSERT OR IGNORE INTO staff_actions(action_id,action_type,actor_type,actor_uuid,actor_name,target_uuid,target_name,reason,server_name,timestamp,result,details) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
            try (Connection connection = connect(); PreparedStatement query = connection.prepareStatement(sql)) {
                query.setString(1, action.actionId()); query.setString(2, action.actionType());
                query.setString(3, action.actorType()); setUuid(query, 4, action.actorUuid()); query.setString(5, safe(action.actorName()));
                setUuid(query, 6, action.targetUuid()); query.setString(7, safe(action.targetName()));
                query.setString(8, safe(action.reason())); query.setString(9, safe(action.serverName()));
                query.setLong(10, action.timestamp()); query.setString(11, action.result()); query.setString(12, safe(action.details()));
                query.executeUpdate();
            } catch (SQLException exception) {
                writeFallback(action, exception);
            }
        });
    }

    private static void setUuid(PreparedStatement query, int index, UUID value) throws SQLException {
        if (value == null) query.setNull(index, Types.VARCHAR); else query.setString(index, value.toString());
    }

    private static String safe(String value) { return value == null ? "" : value.replace('\u0000', ' '); }

    private void writeFallback(StaffAction action, SQLException failure) {
        String row = String.join("\t", action.actionId(), action.actionType(), action.actorType(),
                String.valueOf(action.actorUuid()), safe(action.actorName()), String.valueOf(action.targetUuid()),
                safe(action.targetName()), safe(action.reason()), safe(action.serverName()),
                Long.toString(action.timestamp()), action.result(), safe(action.details()).replace('\n',' ')) + System.lineSeparator();
        try {
            Files.createDirectories(fallback.toAbsolutePath().getParent());
            Files.writeString(fallback, row, java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.APPEND);
            plugin.getLogger().log(Level.SEVERE, "Audit database unavailable; wrote action {0} to the local fallback file.", action.actionId());
        } catch (IOException ioException) {
            plugin.getLogger().log(Level.SEVERE, "Could not persist staff audit action " + action.actionId(), failure);
            plugin.getLogger().log(Level.SEVERE, "Audit fallback also failed", ioException);
        }
    }

    public CompletableFuture<List<StaffAction>> page(StaffActionFilter filter, int offset, int limit) {
        return CompletableFuture.supplyAsync(() -> {
            List<StaffAction> actions = new ArrayList<>();
            StringBuilder sql = new StringBuilder("SELECT * FROM staff_actions WHERE 1=1");
            List<Object> values = new ArrayList<>();
            if (filter.actorUuid() != null) { sql.append(" AND actor_uuid=?"); values.add(filter.actorUuid().toString()); }
            if (filter.actorName() != null) { sql.append(" AND lower(actor_name) LIKE ?"); values.add("%"+filter.actorName().toLowerCase()+"%"); }
            if (filter.targetName() != null) { sql.append(" AND (lower(target_name) LIKE ? OR target_uuid=?)"); values.add("%"+filter.targetName().toLowerCase()+"%"); values.add(filter.targetName()); }
            if (filter.actionType() != null) { sql.append(" AND lower(action_type)=?"); values.add(filter.actionType().toLowerCase()); }
            if (filter.serverName() != null) { sql.append(" AND lower(server_name)=?"); values.add(filter.serverName().toLowerCase()); }
            if (filter.date() != null) { sql.append(" AND date(timestamp/1000,'unixepoch','localtime')=?"); values.add(filter.date()); }
            if (filter.keyword() != null) { sql.append(" AND (lower(action_type) LIKE ? OR lower(actor_name) LIKE ? OR lower(target_name) LIKE ? OR lower(reason) LIKE ? OR lower(details) LIKE ? OR lower(action_id) LIKE ?)"); for (int i=0;i<6;i++) values.add("%"+filter.keyword().toLowerCase()+"%"); }
            sql.append(" ORDER BY timestamp DESC LIMIT ? OFFSET ?"); values.add(Math.max(1,Math.min(50,limit))); values.add(Math.max(0,offset));
            try (Connection connection=connect(); PreparedStatement query=connection.prepareStatement(sql.toString())) {
                for (int i=0;i<values.size();i++) query.setObject(i+1,values.get(i));
                try (ResultSet rows=query.executeQuery()) { while(rows.next()) actions.add(row(rows)); }
            } catch (SQLException exception) { plugin.getLogger().warning("Could not read staff action log: "+exception.getMessage()); }
            return actions;
        }, writer);
    }

    private StaffAction row(ResultSet row) throws SQLException {
        return new StaffAction(row.getString("action_id"),row.getString("action_type"),row.getString("actor_type"),
                parseUuid(row.getString("actor_uuid")),row.getString("actor_name"),parseUuid(row.getString("target_uuid")),
                row.getString("target_name"),row.getString("reason"),row.getString("server_name"),row.getLong("timestamp"),
                row.getString("result"),row.getString("details"));
    }

    private UUID parseUuid(String value) { try { return value==null?null:UUID.fromString(value); } catch(IllegalArgumentException ignored) { return null; } }

    public void updateProtection(UUID uuid, String name, boolean protectedPlayer) {
        writer.execute(() -> { try(Connection connection=connect();PreparedStatement query=connection.prepareStatement("INSERT INTO staff_protected(uuid,name,protected,checked_at) VALUES(?,?,?,?) ON CONFLICT(uuid) DO UPDATE SET name=excluded.name,protected=excluded.protected,checked_at=excluded.checked_at")) { query.setString(1,uuid.toString());query.setString(2,safe(name));query.setInt(3,protectedPlayer?1:0);query.setLong(4,System.currentTimeMillis());query.executeUpdate(); } catch(SQLException exception) { plugin.getLogger().warning("Could not update protected-player cache: "+exception.getMessage()); } });
    }

    public ProtectionState protection(UUID uuid, long maxAgeMillis) {
        try(Connection connection=connect();PreparedStatement query=connection.prepareStatement("SELECT protected,checked_at FROM staff_protected WHERE uuid=?")) {
            query.setString(1,uuid.toString());try(ResultSet row=query.executeQuery()){if(!row.next()||System.currentTimeMillis()-row.getLong("checked_at")>maxAgeMillis)return ProtectionState.UNKNOWN;return row.getInt("protected")==1?ProtectionState.PROTECTED:ProtectionState.UNPROTECTED;}
        }catch(SQLException exception){plugin.getLogger().warning("Protection permission lookup failed closed: "+exception.getMessage());return ProtectionState.UNKNOWN;}
    }

    public CompletableFuture<Boolean> addNote(UUID target, String targetName, StaffActor actor, String note) {
        return CompletableFuture.supplyAsync(() -> { try(Connection connection=connect();PreparedStatement query=connection.prepareStatement("INSERT INTO staff_notes(target_uuid,target_name,actor_type,actor_uuid,actor_name,note,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",java.sql.Statement.RETURN_GENERATED_KEYS)) { long now=System.currentTimeMillis();query.setString(1,target.toString());query.setString(2,targetName);query.setString(3,actor.type());setUuid(query,4,actor.uuid());query.setString(5,actor.name());query.setString(6,note);query.setLong(7,now);query.setLong(8,now);query.executeUpdate();try(ResultSet keys=query.getGeneratedKeys()){return keys.next();} } catch(SQLException exception){plugin.getLogger().warning("Could not create staff note: "+exception.getMessage());return false;} },writer);
    }

    public CompletableFuture<Boolean> updateNote(long id, String note) {
        return CompletableFuture.supplyAsync(() -> { try(Connection connection=connect();PreparedStatement query=connection.prepareStatement("UPDATE staff_notes SET note=?,updated_at=? WHERE note_id=?")){query.setString(1,note);query.setLong(2,System.currentTimeMillis());query.setLong(3,id);return query.executeUpdate()>0;}catch(SQLException exception){return false;} },writer);
    }

    public CompletableFuture<Boolean> deleteNote(long id) {
        return CompletableFuture.supplyAsync(() -> { try(Connection connection=connect();PreparedStatement query=connection.prepareStatement("DELETE FROM staff_notes WHERE note_id=?")){query.setLong(1,id);return query.executeUpdate()>0;}catch(SQLException exception){return false;} },writer);
    }

    @Override public void close() { writer.shutdown(); }
}
