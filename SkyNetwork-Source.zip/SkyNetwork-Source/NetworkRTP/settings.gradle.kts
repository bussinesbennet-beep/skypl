rootProject.name = "NetworkRTP"
include("paper", "velocity")
