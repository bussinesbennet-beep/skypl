plugins {
    java
}

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    compileOnly("io.papermc.paper:paper-api:26.3.build.242-stable")
    compileOnly(files("../../SimpleEconomy/target/SimpleEconomy-1.0.0.jar"))
}

sourceSets {
    main {
        java.setSrcDirs(listOf("../../NetworkRTP-Paper/src/main/java"))
        resources.setSrcDirs(listOf("../../NetworkRTP-Paper/src/main/resources"))
    }
}

tasks.jar {
    archiveBaseName.set("NetworkRTP-Paper")
}
