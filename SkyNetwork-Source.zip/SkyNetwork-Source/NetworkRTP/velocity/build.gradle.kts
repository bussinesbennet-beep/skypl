plugins {
    java
}

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    compileOnly("com.velocitypowered:velocity-api:4.3.1")
    annotationProcessor("com.velocitypowered:velocity-api:4.3.1")
}

sourceSets {
    main {
        java.setSrcDirs(listOf("../../NetworkRTP-Velocity/src/main/java"))
        resources.setSrcDirs(listOf("../../NetworkRTP-Velocity/src/main/resources"))
    }
}

tasks.jar {
    archiveBaseName.set("NetworkRTP-Velocity")
}
