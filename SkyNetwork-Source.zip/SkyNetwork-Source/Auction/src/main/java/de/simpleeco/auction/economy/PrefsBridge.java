package de.simpleeco.auction.economy;

import de.simpleeco.economy.api.SimplePrefsAPI;
import org.bukkit.Bukkit;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.util.UUID;

/**
 * Optional bridge to SimpleEconomy's shared preference service. Used to read the
 * per-player "Auction Confirm" toggle. Degrades to defaults when unavailable.
 */
public class PrefsBridge {

    private SimplePrefsAPI prefs;

    public void resolve() {
        try {
            RegisteredServiceProvider<SimplePrefsAPI> rsp =
                    Bukkit.getServicesManager().getRegistration(SimplePrefsAPI.class);
            prefs = rsp != null ? rsp.getProvider() : null;
        } catch (Throwable t) {
            prefs = null;
        }
    }

    public boolean get(UUID uuid, String key, boolean def) {
        return prefs != null ? prefs.get(uuid, key, def) : def;
    }
}
