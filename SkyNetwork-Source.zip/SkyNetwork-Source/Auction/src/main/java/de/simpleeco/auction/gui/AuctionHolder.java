package de.simpleeco.auction.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

/**
 * Identifies an Auction GUI, its view (browse all vs. my listings) and page,
 * and remembers which listing id sits in each content slot for click handling.
 */
public class AuctionHolder implements InventoryHolder {

    public enum View { BROWSE, MINE }

    /** Sort order for the browse view. */
    public enum Sort {
        NEWEST("Newest"),
        OLDEST("Oldest"),
        PRICE_LOW("Lowest price"),
        PRICE_HIGH("Highest price"),
        ENDING_SOON("Ending soon");

        private final String label;
        Sort(String label) { this.label = label; }
        public String label() { return label; }
        public Sort next() { return values()[(ordinal() + 1) % values().length]; }
    }

    private final View view;
    private final int page;
    private final Sort sort;
    private final String filter;
    private Inventory inventory;
    // content slot index -> listing id (or -1 for none)
    private final List<Long> slotListings = new ArrayList<>();

    public AuctionHolder(View view, int page) {
        this(view, page, Sort.NEWEST, null);
    }

    public AuctionHolder(View view, int page, Sort sort) {
        this(view, page, sort, null);
    }

    public AuctionHolder(View view, int page, Sort sort, String filter) {
        this.view = view;
        this.page = page;
        this.sort = sort;
        this.filter = filter;
    }

    public View getView() { return view; }
    public int getPage() { return page; }
    public Sort getSort() { return sort; }
    /** Active search filter for the browse view, or null/empty for none. */
    public String getFilter() { return filter; }

    public void setInventory(Inventory inventory) { this.inventory = inventory; }

    public void mapSlot(int slot, long listingId) {
        while (slotListings.size() <= slot) {
            slotListings.add(-1L);
        }
        slotListings.set(slot, listingId);
    }

    public long listingAt(int slot) {
        if (slot < 0 || slot >= slotListings.size()) {
            return -1L;
        }
        return slotListings.get(slot);
    }

    @NotNull
    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
