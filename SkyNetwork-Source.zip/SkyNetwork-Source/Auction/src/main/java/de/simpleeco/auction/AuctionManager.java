package de.simpleeco.auction;

import de.simpleeco.auction.storage.AuctionStorage;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * In-memory registry of all auction listings plus the create/buy/expire/collect
 * logic. Persistence is delegated to {@link AuctionStorage}.
 */
public class AuctionManager {

    private final AuctionStorage storage;
    private final long listingDurationMillis;
    private final int maxListingsPerPlayer;

    // Keyed by listing id.
    private final ConcurrentHashMap<Long, Listing> listings = new ConcurrentHashMap<>();

    public AuctionManager(AuctionStorage storage, long listingDurationMillis, int maxListingsPerPlayer) {
        this.storage = storage;
        this.listingDurationMillis = listingDurationMillis;
        this.maxListingsPerPlayer = maxListingsPerPlayer;
    }

    public void loadAll() {
        listings.clear();
        for (Listing l : storage.loadAll()) {
            listings.put(l.getId(), l);
        }
    }

    public int getMaxListingsPerPlayer() {
        return maxListingsPerPlayer;
    }

    public long getListingDurationMillis() {
        return listingDurationMillis;
    }

    // ------------------------------------------------------------- queries

    public Listing byId(long id) {
        loadAll();
        return listings.get(id);
    }

    /** All currently active (buyable) listings, newest first. */
    public List<Listing> activeListings() {
        loadAll();
        return listings.values().stream()
                .filter(Listing::isActive)
                .sorted(Comparator.comparingLong(Listing::getCreatedAt).reversed())
                .collect(Collectors.toList());
    }

    /** All currently active (buyable) listings, ordered by the given comparator. */
    public List<Listing> activeListings(Comparator<Listing> order) {
        loadAll();
        return listings.values().stream()
                .filter(Listing::isActive)
                .sorted(order)
                .collect(Collectors.toList());
    }

    /** A player's active listings. */
    public List<Listing> activeListingsOf(UUID seller) {
        loadAll();
        return listings.values().stream()
                .filter(l -> l.isActive() && l.getSeller().equals(seller))
                .sorted(Comparator.comparingLong(Listing::getCreatedAt).reversed())
                .collect(Collectors.toList());
    }

    /** A player's expired listings awaiting collection. */
    public List<Listing> expiredListingsOf(UUID seller) {
        loadAll();
        return listings.values().stream()
                .filter(l -> l.getStatus() == Listing.Status.EXPIRED && l.getSeller().equals(seller))
                .sorted(Comparator.comparingLong(Listing::getExpiresAt))
                .collect(Collectors.toList());
    }

    /** Everything a player has that is active or waiting to be collected. */
    public List<Listing> allOf(UUID seller) {
        List<Listing> out = new ArrayList<>(activeListingsOf(seller));
        out.addAll(expiredListingsOf(seller));
        return out;
    }

    public int activeCountOf(UUID seller) {
        loadAll();
        return (int) listings.values().stream()
                .filter(l -> l.isActive() && l.getSeller().equals(seller))
                .count();
    }

    /** True if the player is at or over the active-listing limit (0 = unlimited). */
    public boolean atLimit(UUID seller) {
        return maxListingsPerPlayer > 0 && activeCountOf(seller) >= maxListingsPerPlayer;
    }

    // ------------------------------------------------------------- mutations

    /** Creates and persists a new active listing. */
    public Listing create(UUID seller, String sellerName, ItemStack item, double price) {
        long now = System.currentTimeMillis();
        long expires = now + listingDurationMillis;
        Listing listing = storage.insert(seller, sellerName, item, price, now, expires);
        if (listing != null) {
            listings.put(listing.getId(), listing);
        }
        return listing;
    }

    /**
     * Marks a listing sold and removes it from the registry/database. The caller
     * handles the money transfer and item delivery.
     */
    public void markSold(Listing listing) {
        listings.remove(listing.getId());
        storage.delete(listing.getId());
    }

    /**
     * Atomically claims a listing for purchase/collection: removes it from the
     * in-memory registry and returns it, or returns null if it was already gone
     * (already bought/cancelled by someone else on another thread/tick).
     *
     * <p>This is the dupe-proofing linchpin. Because {@link ConcurrentHashMap#remove}
     * returns the removed value atomically, only ONE caller can ever win the race
     * for a given listing id — the second concurrent buyer gets null and is
     * refunded/aborted before any money or item changes hands. The database row
     * is deleted only after the in-memory claim succeeds.
     */
    public Listing claim(long id) {
        Listing claimed = storage.claim(id);
        if (claimed != null) listings.remove(id);
        return claimed;
    }

    /**
     * Re-inserts a previously {@link #claim(long) claimed} listing back into the
     * registry and database (used to roll back a failed purchase). Because the
     * original row was deleted on claim, a fresh row is written and the in-memory
     * entry keeps the same object so open GUIs refresh consistently.
     */
    public void reinsert(Listing listing) {
        Listing restored = storage.insert(listing.getSeller(), listing.getSellerName(),
                listing.getItem(), listing.getPrice(), listing.getCreatedAt(),
                listing.getExpiresAt());
        if (restored != null) {
            listings.put(restored.getId(), restored);
        } else {
            // Storage failed; at least keep it in memory under the old id so the
            // item is never lost.
            listings.put(listing.getId(), listing);
        }
    }

    /** Marks an active listing as expired (item awaits collection). */
    public void markExpired(Listing listing) {
        listing.setStatus(Listing.Status.EXPIRED);
        storage.updateStatus(listing.getId(), Listing.Status.EXPIRED);
    }

    /** Removes a listing entirely (e.g. after the seller collected it / cancelled). */
    public void remove(Listing listing) {
        listings.remove(listing.getId());
        storage.delete(listing.getId());
    }

    /**
     * Sweeps all active listings and marks any whose time is up as expired.
     * @return the number of listings newly expired.
     */
    public int sweepExpired() {
        loadAll();
        long now = System.currentTimeMillis();
        int count = 0;
        for (Listing l : listings.values()) {
            if (l.isExpired(now)) {
                markExpired(l);
                count++;
            }
        }
        return count;
    }
}
