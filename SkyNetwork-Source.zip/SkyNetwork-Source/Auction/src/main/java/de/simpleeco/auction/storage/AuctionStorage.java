package de.simpleeco.auction.storage;

import de.simpleeco.auction.Listing;
import de.simpleeco.auction.util.ItemCodec;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * SQLite persistence for auction listings. A single table stores every listing,
 * including expired ones that are waiting to be collected back by their seller.
 */
public class AuctionStorage {

    private final JavaPlugin plugin;
    private final File databaseFile;
    private Connection connection;

    public AuctionStorage(JavaPlugin plugin, String fileName) {
        this.plugin = plugin;
        this.databaseFile = new File(plugin.getDataFolder(), fileName);
    }

    public void init() throws SQLException {
        File parent = databaseFile.getAbsoluteFile().getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) plugin.getLogger().warning("Could not create shared database folder: " + parent);
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException ignored) {
            // Paper ships a SQLite driver.
        }
        connection = DriverManager.getConnection("jdbc:sqlite:" + databaseFile.getAbsolutePath());
        try (Statement st = connection.createStatement()) {
            st.execute("PRAGMA busy_timeout=10000");
            st.execute("PRAGMA journal_mode=WAL");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS listings (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "seller TEXT NOT NULL, " +
                    "seller_name TEXT, " +
                    "item TEXT NOT NULL, " +
                    "price REAL NOT NULL, " +
                    "created_at INTEGER NOT NULL, " +
                    "expires_at INTEGER NOT NULL, " +
                    "status TEXT NOT NULL)");
        }
    }

    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Error closing database: " + e.getMessage());
        }
    }

    /** Inserts a new listing and returns it with its generated id. */
    public Listing insert(UUID seller, String sellerName, ItemStack item, double price,
                          long createdAt, long expiresAt) {
        String encoded = ItemCodec.encode(item);
        if (encoded == null) {
            return null;
        }
        String sql = "INSERT INTO listings (seller, seller_name, item, price, created_at, expires_at, status) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, seller.toString());
            ps.setString(2, sellerName);
            ps.setString(3, encoded);
            ps.setDouble(4, price);
            ps.setLong(5, createdAt);
            ps.setLong(6, expiresAt);
            ps.setString(7, Listing.Status.ACTIVE.name());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                long id = keys.next() ? keys.getLong(1) : -1;
                return new Listing(id, seller, sellerName, item, price, createdAt, expiresAt,
                        Listing.Status.ACTIVE);
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Could not insert listing: " + e.getMessage());
            return null;
        }
    }

    /** Loads every listing from the database. */
    public List<Listing> loadAll() {
        List<Listing> out = new ArrayList<>();
        String sql = "SELECT * FROM listings";
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Listing listing = fromRow(rs);
                if (listing != null) {
                    out.add(listing);
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Could not load listings: " + e.getMessage());
        }
        return out;
    }

    private Listing fromRow(ResultSet rs) throws SQLException {
        long id = rs.getLong("id");
        UUID seller;
        try {
            seller = UUID.fromString(rs.getString("seller"));
        } catch (IllegalArgumentException e) {
            return null;
        }
        ItemStack item = ItemCodec.decode(rs.getString("item"));
        if (item == null) {
            return null;
        }
        Listing.Status status;
        try {
            status = Listing.Status.valueOf(rs.getString("status"));
        } catch (IllegalArgumentException e) {
            status = Listing.Status.ACTIVE;
        }
        return new Listing(id, seller, rs.getString("seller_name"), item,
                rs.getDouble("price"), rs.getLong("created_at"), rs.getLong("expires_at"), status);
    }

    /** Updates a listing's status. */
    public void updateStatus(long id, Listing.Status status) {
        try (PreparedStatement ps = connection.prepareStatement(
                "UPDATE listings SET status = ? WHERE id = ?")) {
            ps.setString(1, status.name());
            ps.setLong(2, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().warning("Could not update listing status: " + e.getMessage());
        }
    }

    /** Deletes a listing permanently. */
    public void delete(long id) {
        try (PreparedStatement ps = connection.prepareStatement(
                "DELETE FROM listings WHERE id = ?")) {
            ps.setLong(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().warning("Could not delete listing: " + e.getMessage());
        }
    }

    /** Atomically removes and returns a listing, or null if another backend already claimed it. */
    public Listing claim(long id) {
        try (PreparedStatement ps = connection.prepareStatement("DELETE FROM listings WHERE id = ? RETURNING *")) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? fromRow(rs) : null; }
        } catch (SQLException e) {
            plugin.getLogger().warning("Could not claim listing: " + e.getMessage());
            return null;
        }
    }
}
