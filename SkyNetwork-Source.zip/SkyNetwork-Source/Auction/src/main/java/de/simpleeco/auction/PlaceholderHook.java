package de.simpleeco.auction;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;

import java.text.DecimalFormat;

/**
 * PlaceholderAPI expansion for the Auction plugin (identifier "auction").
 *
 * All numeric placeholders return PLAIN numbers (no currency symbol) so users
 * append symbols in their own templates.
 *
 * Supported:
 *   %auction_earned%        -> total Dollars earned by selling (formatted)
 *   %auction_earned_raw%    -> raw number
 *   %auction_spent%         -> total Dollars spent buying (formatted)
 *   %auction_spent_raw%     -> raw number
 *   %auction_active%        -> the player's number of active listings
 *   %auction_listings%      -> total active listings on the whole auction house
 */
public class PlaceholderHook extends PlaceholderExpansion {

    public static final String KEY_EARNED = "dollars_earned";
    public static final String KEY_SPENT = "dollars_spent";

    private final StatStore stats;
    private final AuctionManager manager;
    private final DecimalFormat fmt = new DecimalFormat("#,##0.##");

    public PlaceholderHook(StatStore stats, AuctionManager manager) {
        this.stats = stats;
        this.manager = manager;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "auction";
    }

    @Override
    public @NotNull String getAuthor() {
        return "SimpleEconomy";
    }

    @Override
    public @NotNull String getVersion() {
        return "1.0.0";
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        String p = params.toLowerCase();
        if (p.equals("listings")) {
            return String.valueOf(manager.activeListings().size());
        }
        if (player == null) {
            return "";
        }
        return switch (p) {
            case "earned" -> fmt.format(stats.get(player.getUniqueId(), KEY_EARNED));
            case "earned_raw" -> String.valueOf(stats.get(player.getUniqueId(), KEY_EARNED));
            case "spent" -> fmt.format(stats.get(player.getUniqueId(), KEY_SPENT));
            case "spent_raw" -> String.valueOf(stats.get(player.getUniqueId(), KEY_SPENT));
            case "active" -> String.valueOf(manager.activeCountOf(player.getUniqueId()));
            default -> null;
        };
    }
}
