package de.simpleeco.auction.util;

import net.kyori.adventure.text.Component;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Sign;
import org.bukkit.block.sign.Side;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

/**
 * Reusable "type text on a sign" prompt.
 *
 * Approach (works without NMS): temporarily place a real sign block near the
 * player (out of normal reach, at build-limit top or just below them), open its
 * edit screen, and read the typed lines from SignChangeEvent. The block is
 * always restored to its previous state afterwards.
 *
 * If sign editing cannot be opened on the running server for any reason, the
 * callback simply never fires for that attempt; callers should keep the GUI
 * flow resilient (we reopen menus after a short delay).
 */
public class SignInput implements Listener {

    private final JavaPlugin plugin;

    private static class Pending {
        final Location loc;
        final BlockState previous;
        final Consumer<String> onDone;

        Pending(Location loc, BlockState previous, Consumer<String> onDone) {
            this.loc = loc;
            this.previous = previous;
            this.onDone = onDone;
        }
    }

    private final Map<UUID, Pending> pending = new ConcurrentHashMap<>();

    public SignInput(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Opens a sign prompt for the player.
     *
     * @param player      the player
     * @param initial     up to 4 initial lines (may be null/empty)
     * @param onDone      receives the first non-empty typed line, trimmed
     */
    public void open(Player player, List<String> initial, Consumer<String> onDone) {
        // Choose a location for the temporary sign: just below the world's max
        // height above the player, so it never disturbs their surroundings.
        Location base = player.getLocation().getBlock().getLocation();
        int y = Math.min(player.getWorld().getMaxHeight() - 1, base.getBlockY() + 3);
        Location loc = new Location(player.getWorld(), base.getBlockX(), y, base.getBlockZ());

        Block block = loc.getBlock();
        BlockState previous = block.getState();

        // Place a temporary sign the player can see only in the edit UI.
        block.setType(Material.OAK_SIGN, false);
        BlockState state = block.getState();
        if (state instanceof Sign sign) {
            if (initial != null) {
                for (int i = 0; i < initial.size() && i < 4; i++) {
                    sign.getSide(Side.FRONT).line(i, Text.of(initial.get(i)));
                }
            }
            sign.update(true, false);
        }

        pending.put(player.getUniqueId(), new Pending(loc, previous, onDone));

        // Open the sign edit screen next tick (after the block change is sent).
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            try {
                player.openSign(((Sign) block.getState()));
            } catch (Throwable t) {
                // Fallback: if opening fails, clean up so we don't leak a sign.
                restore(player.getUniqueId());
            }
        });
    }

    @EventHandler
    public void onSignChange(SignChangeEvent event) {
        Pending p = pending.get(event.getPlayer().getUniqueId());
        if (p == null) {
            return;
        }
        // Make sure it's our sign location.
        if (!event.getBlock().getLocation().equals(p.loc)) {
            return;
        }

        // Read the lines; use the first non-empty one.
        String result = "";
        List<Component> lines = event.lines();
        for (Component c : lines) {
            String plain = net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer
                    .plainText().serialize(c).trim();
            if (!plain.isEmpty()) {
                result = plain;
                break;
            }
        }
        final String finalResult = result;

        // Restore the block after the event completes, and fire the callback.
        UUID id = event.getPlayer().getUniqueId();
        pending.remove(id);
        final Pending captured = p;
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            restoreState(captured);
            if (captured.onDone != null) {
                try {
                    captured.onDone.accept(finalResult);
                } catch (Throwable t) {
                    plugin.getLogger().warning("Sign input callback failed: " + t.getMessage());
                }
            }
        });
    }

    private void restoreState(Pending p) {
        if (p == null) {
            return;
        }
        try {
            p.previous.update(true, false);
        } catch (Throwable ignored) {
            p.loc.getBlock().setType(Material.AIR, false);
        }
    }

    private void restore(UUID playerId) {
        Pending p = pending.remove(playerId);
        restoreState(p);
    }

    /** Clean up any pending prompt for a player (e.g. on quit). */
    public void cancel(UUID playerId) {
        restore(playerId);
    }
}
