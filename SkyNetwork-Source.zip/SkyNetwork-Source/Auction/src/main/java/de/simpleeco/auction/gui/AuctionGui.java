package de.simpleeco.auction.gui;

import de.simpleeco.auction.AuctionManager;
import de.simpleeco.auction.Listing;
import de.simpleeco.auction.economy.EconomyBridge;
import de.simpleeco.auction.util.DialogUi;
import de.simpleeco.auction.util.GuiGuard;
import de.simpleeco.auction.util.Text;
import de.simpleeco.auction.util.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import net.kyori.adventure.text.Component;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Builds and opens the auction GUIs:
 *  - BROWSE: all active listings (buy on click), 5 content rows + nav row.
 *  - MINE:   the player's own active + expired listings (cancel / collect).
 *
 * No filler items are used. Nav row: prev | mine/browse toggle | info | sell | next.
 */
public class AuctionGui {

    public static final String NAV = "&#c6c7f2";

    public static final int SIZE = 54;
    public static final int CONTENT = 45; // slots 0..44

    // Browse nav (bottom row) — mirrors the Order board layout:
    //   45 prev | 47 my | 48 search | 49 refresh | 50 sort | 51 sell | 53 next
    public static final int PREV_SLOT = 45;
    public static final int MY_SLOT = 47;        // writable book (browse) / back arrow (mine)
    public static final int SEARCH_SLOT = 48;    // oak sign
    public static final int REFRESH_SLOT = 49;   // anvil, center
    public static final int SORT_SLOT = 50;      // compass
    public static final int SELL_SLOT = 51;      // gold-ingot sell action
    public static final int NEXT_SLOT = 53;

    // Confirmation GUI (27 slots): item preview, confirm and cancel.
    public static final int CONFIRM_ITEM_SLOT = 13;

    private final AuctionManager manager;
    private final EconomyBridge economy;
    private final FileConfiguration config;

    public AuctionGui(AuctionManager manager, EconomyBridge economy, FileConfiguration config) {
        this.manager = manager;
        this.economy = economy;
        this.config = config;
    }

    // ------------------------------------------------------------- BROWSE

    public void openBrowse(Player player, int page) {
        openBrowse(player, page, AuctionHolder.Sort.NEWEST, null);
    }

    public void openBrowse(Player player, int page, AuctionHolder.Sort sort) {
        openBrowse(player, page, sort, null);
    }

    public void openBrowse(Player player, int page, AuctionHolder.Sort sort, String filter) {
        List<Listing> all = manager.activeListings(comparatorFor(sort));
        if (filter != null && !filter.isEmpty()) {
            String f = filter.toLowerCase(java.util.Locale.ROOT);
            all = all.stream().filter(l -> matchesFilter(l, f)).collect(java.util.stream.Collectors.toList());
        }
        int totalPages = Math.max(1, (int) Math.ceil(all.size() / (double) CONTENT));
        page = Math.max(0, Math.min(page, totalPages - 1));

        AuctionHolder holder = new AuctionHolder(AuctionHolder.View.BROWSE, page, sort, filter);
        Inventory inv = Bukkit.createInventory(holder, SIZE,
                Text.of(de.simpleeco.auction.util.CoreI18n.gui(player, "auction-gui.browse-title", config.getString("gui.browse-title", "&8Auction House"))));
        holder.setInventory(inv);

        int start = page * CONTENT;
        int end = Math.min(all.size(), start + CONTENT);
        for (int i = start; i < end; i++) {
            Listing listing = all.get(i);
            int slot = i - start;
            inv.setItem(slot, renderBuyable(player, listing));
            holder.mapSlot(slot, listing.getId());
        }

        inv.setItem(MY_SLOT, GuiItems.myListings(player));
        inv.setItem(SEARCH_SLOT, GuiItems.search(player, filter));
        inv.setItem(REFRESH_SLOT, GuiItems.refresh(player));
        inv.setItem(SORT_SLOT, GuiItems.compass(player, sort));
        inv.setItem(SELL_SLOT, GuiItems.sellItem(player));
        if (page > 0) inv.setItem(PREV_SLOT, GuiItems.previousArrow(player, page));
        if (page < totalPages - 1) inv.setItem(NEXT_SLOT, GuiItems.nextArrow(player, page + 2));

        GuiGuard.markAll(inv);

        player.openInventory(inv);
    }

    /**
     * @return true if the listing matches a lowercase search term, checked
     * against the item's material name and its custom display name (if any).
     */
    public static boolean matchesFilter(Listing listing, String lowerTerm) {
        ItemStack item = listing.getItem();
        if (item == null) {
            return false;
        }
        String mat = item.getType().name().toLowerCase(java.util.Locale.ROOT).replace('_', ' ');
        if (mat.contains(lowerTerm)) {
            return true;
        }
        if (item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
            String display = net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer
                    .plainText().serialize(item.getItemMeta().displayName())
                    .toLowerCase(java.util.Locale.ROOT);
            return display.contains(lowerTerm);
        }
        return false;
    }

    // ------------------------------------------------------------- MINE

    public void openMine(Player player, int page) {
        List<Listing> mine = manager.allOf(player.getUniqueId());
        int totalPages = Math.max(1, (int) Math.ceil(mine.size() / (double) CONTENT));
        page = Math.max(0, Math.min(page, totalPages - 1));

        AuctionHolder holder = new AuctionHolder(AuctionHolder.View.MINE, page);
        Inventory inv = Bukkit.createInventory(holder, SIZE,
                Text.of(de.simpleeco.auction.util.CoreI18n.gui(player, "auction-gui.mine-title", config.getString("gui.mine-title", "&8Your Listings"))));
        holder.setInventory(inv);

        int start = page * CONTENT;
        int end = Math.min(mine.size(), start + CONTENT);
        for (int i = start; i < end; i++) {
            Listing listing = mine.get(i);
            int slot = i - start;
            inv.setItem(slot, renderOwned(player, listing));
            holder.mapSlot(slot, listing.getId());
        }

        inv.setItem(MY_SLOT, GuiItems.backArrow(player));       // 47: back to browse
        inv.setItem(SELL_SLOT, GuiItems.sellItem(player));      // 51: sell an item
        if (page > 0) inv.setItem(PREV_SLOT, GuiItems.previousArrow(player, page));
        if (page < totalPages - 1) inv.setItem(NEXT_SLOT, GuiItems.nextArrow(player, page + 2));

        GuiGuard.markAll(inv);

        player.openInventory(inv);
    }

    // ------------------------------------------------------------- renderers

    /** A listing shown in the browse view (click to buy). */
    private ItemStack renderBuyable(Player player, Listing listing) {
        ItemStack stack = listing.getItem().clone();
        ItemMeta meta = stack.getItemMeta();
        List<net.kyori.adventure.text.Component> lore = baseLore(meta);
        lore.add(Text.of("&7" + de.simpleeco.auction.util.CoreI18n.gui(player, "auction-gui.items.price", "Price:") + " &a" + economy.format(listing.getPrice())));
        lore.add(Text.of("&7" + de.simpleeco.auction.util.CoreI18n.gui(player, "auction-gui.items.seller", "Seller:") + " &f" + safeName(listing.getSellerName())));
        lore.add(Text.of("&7" + de.simpleeco.auction.util.CoreI18n.gui(player, "auction-gui.items.ends-in", "Ends in:") + " &f" + TimeUtil.shortDuration(listing.millisLeft(System.currentTimeMillis()))));
        lore.add(Text.italic("&7" + de.simpleeco.auction.util.CoreI18n.gui(player, "auction-gui.items.click-buy", "Click to buy this item")));
        meta.lore(lore);
        stack.setItemMeta(meta);
        return stack;
    }

    /** A listing shown in the "my listings" view (cancel or collect). */
    private ItemStack renderOwned(Player player, Listing listing) {
        ItemStack stack = listing.getItem().clone();
        ItemMeta meta = stack.getItemMeta();
        List<net.kyori.adventure.text.Component> lore = baseLore(meta);
        lore.add(Text.of("&7" + de.simpleeco.auction.util.CoreI18n.gui(player, "auction-gui.items.price", "Price:") + " &a" + economy.format(listing.getPrice())));
        if (listing.getStatus() == Listing.Status.EXPIRED) {
            lore.add(Text.of("&7" + de.simpleeco.auction.util.CoreI18n.gui(player, "auction-gui.items.status-expired", "Status: &cExpired")));
            lore.add(Text.italic("&7" + de.simpleeco.auction.util.CoreI18n.gui(player, "auction-gui.items.click-collect", "Click to collect your item back")));
        } else {
            lore.add(Text.of("&7" + de.simpleeco.auction.util.CoreI18n.gui(player, "auction-gui.items.ends-in", "Ends in:") + " &f" + TimeUtil.shortDuration(listing.millisLeft(System.currentTimeMillis()))));
            lore.add(Text.italic("&7" + de.simpleeco.auction.util.CoreI18n.gui(player, "auction-gui.items.click-cancel", "Click to cancel and take it back")));
        }
        meta.lore(lore);
        stack.setItemMeta(meta);
        return stack;
    }

    /** Preserves an item's own existing lore (if any) as the top of the tooltip. */
    private List<net.kyori.adventure.text.Component> baseLore(ItemMeta meta) {
        List<net.kyori.adventure.text.Component> lore = new ArrayList<>();
        if (meta != null && meta.hasLore() && meta.lore() != null) {
            lore.addAll(meta.lore());
        }
        return lore;
    }

    private String safeName(String name) {
        return name == null || name.isEmpty() ? "?" : name;
    }

    // ------------------------------------------------------------- sorting

    /** Maps a sort mode to its listing comparator. */
    public static Comparator<Listing> comparatorFor(AuctionHolder.Sort sort) {
        return switch (sort) {
            case NEWEST -> Comparator.comparingLong(Listing::getCreatedAt).reversed();
            case OLDEST -> Comparator.comparingLong(Listing::getCreatedAt);
            case PRICE_LOW -> Comparator.comparingDouble(Listing::getPrice)
                    .thenComparing(Comparator.comparingLong(Listing::getCreatedAt).reversed());
            case PRICE_HIGH -> Comparator.comparingDouble(Listing::getPrice).reversed()
                    .thenComparing(Comparator.comparingLong(Listing::getCreatedAt).reversed());
            case ENDING_SOON -> Comparator.comparingLong(Listing::getExpiresAt);
        };
    }

    // ------------------------------------------------------------- confirmation

    /** Opens a confirmation screen for buying a listing. */
    /**
     * Confirmation screen for buying a listing — rendered as a NATIVE DIALOG.
     *
     * <p>The API has no icon slot on buttons, so the item picture is shown as a
     * real {@link DialogBody} item (that is the genuinely native item render) and
     * the two buttons carry glyph icons in their labels.
     *
     * @param onConfirm run when the player confirms; may be null
     */
    public void openBuyConfirm(Player player, Listing listing, Runnable onConfirm) {
        Component title = Component.text(de.simpleeco.auction.util.CoreI18n.gui(player,
                "auction-gui.confirm-buy-title", "Confirm Purchase").replace("&8", ""),
                DialogUi.ACCENT).decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false);

        List<DialogBody> body = new ArrayList<>();
        body.add(DialogUi.itemBody(annotated(listing.getItem().clone(), player,
                de.simpleeco.auction.util.CoreI18n.gui(player, "auction-gui.items.price", "Price:") + " &a" + economy.format(listing.getPrice()),
                de.simpleeco.auction.util.CoreI18n.gui(player, "auction-gui.items.seller", "Seller:") + " &f" + safeName(listing.getSellerName()))));
        body.add(DialogUi.text(de.simpleeco.auction.util.CoreI18n.gui(player,
                "auction-gui.items.you-pay", "You pay:") + " " + economy.format(listing.getPrice()), DialogUi.POSITIVE));

        ActionButton buy = DialogUi.button(plugin(), "confirm",
                de.simpleeco.auction.util.CoreI18n.gui(player, "auction-gui.items.confirm", "Confirm"),
                de.simpleeco.auction.util.CoreI18n.gui(player, "auction-gui.items.click-confirm", "Click to Confirm"),
                150, DialogUi.POSITIVE,
                DialogUi.click(p -> {
                    // Close the dialog first: a chest GUI can only open once the
                    // dialog screen is gone, so the action runs next tick.
                    p.closeDialog();
                    if (onConfirm != null) {
                        org.bukkit.Bukkit.getScheduler().runTask(plugin(), onConfirm);
                    }
                }));
        ActionButton cancel = DialogUi.button(plugin(), "cancel",
                de.simpleeco.auction.util.CoreI18n.gui(player, "auction-gui.items.cancel", "Cancel"),
                de.simpleeco.auction.util.CoreI18n.gui(player, "auction-gui.items.back-ah", "Back to the auction house."),
                150, DialogUi.NEGATIVE, null);

        DialogUi.confirm(player, title, body, buy, cancel);
    }

    /** Confirmation screen for listing the held item at a price — a native dialog. */
    public void openSellConfirm(Player player, ItemStack toList, double price, Runnable onConfirm) {
        Component title = Component.text(de.simpleeco.auction.util.CoreI18n.gui(player,
                "auction-gui.confirm-sell-title", "Confirm Listing").replace("&8", ""),
                DialogUi.ACCENT).decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false);

        long hours = manager.getListingDurationMillis() / 3600_000L;
        List<DialogBody> body = new ArrayList<>();
        body.add(DialogUi.itemBody(annotated(toList.clone(), player,
                de.simpleeco.auction.util.CoreI18n.gui(player, "auction-gui.items.list-price", "List price:") + " &a" + economy.format(price),
                de.simpleeco.auction.util.CoreI18n.gui(player, "auction-gui.items.expires-after", "Expires after:") + " &f" + hours + "h")));

        ActionButton yes = DialogUi.button(plugin(), "confirm",
                de.simpleeco.auction.util.CoreI18n.gui(player, "auction-gui.items.confirm", "Confirm"),
                de.simpleeco.auction.util.CoreI18n.gui(player, "auction-gui.items.click-confirm", "Click to Confirm"),
                150, DialogUi.POSITIVE,
                DialogUi.click(p -> {
                    // Close the dialog first: a chest GUI can only open once the
                    // dialog screen is gone, so the action runs next tick.
                    p.closeDialog();
                    if (onConfirm != null) {
                        org.bukkit.Bukkit.getScheduler().runTask(plugin(), onConfirm);
                    }
                }));
        ActionButton no = DialogUi.button(plugin(), "cancel",
                de.simpleeco.auction.util.CoreI18n.gui(player, "auction-gui.items.cancel", "Cancel"),
                de.simpleeco.auction.util.CoreI18n.gui(player, "auction-gui.items.keep-item", "Keep the item, don't list it."),
                150, DialogUi.NEGATIVE, null);

        DialogUi.confirm(player, title, body, yes, no);
    }

    /** Adds display-only info lines under an item's existing lore. */
    private ItemStack annotated(ItemStack stack, Player player, String... lines) {
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) {
            return stack;
        }
        List<Component> lore = baseLore(meta);
        for (String line : lines) {
            lore.add(Text.of(line));
        }
        meta.lore(lore);
        stack.setItemMeta(meta);
        return stack;
    }

    /** The owning plugin, used for config-driven icons. */
    private org.bukkit.plugin.java.JavaPlugin plugin() {
        return (org.bukkit.plugin.java.JavaPlugin)
                org.bukkit.Bukkit.getPluginManager().getPlugin("Auction");
    }

}
