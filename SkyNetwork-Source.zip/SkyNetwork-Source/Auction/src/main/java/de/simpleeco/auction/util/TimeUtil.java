package de.simpleeco.auction.util;

/**
 * Formats durations like "2d 3h", "45m", "12s" for listing expiry displays.
 */
public final class TimeUtil {

    private TimeUtil() {
    }

    public static String shortDuration(long millis) {
        if (millis <= 0) {
            return "expired";
        }
        long totalSeconds = millis / 1000;
        long days = totalSeconds / 86400;
        long hours = (totalSeconds % 86400) / 3600;
        long minutes = (totalSeconds % 3600) / 60;
        long seconds = totalSeconds % 60;

        StringBuilder sb = new StringBuilder();
        if (days > 0) {
            sb.append(days).append("d ");
            if (hours > 0) sb.append(hours).append("h");
            return sb.toString().trim();
        }
        if (hours > 0) {
            sb.append(hours).append("h ");
            if (minutes > 0) sb.append(minutes).append("m");
            return sb.toString().trim();
        }
        if (minutes > 0) {
            sb.append(minutes).append("m ");
            if (seconds > 0) sb.append(seconds).append("s");
            return sb.toString().trim();
        }
        return seconds + "s";
    }
}
