package de.simpleeco.auction.gui;

import de.simpleeco.auction.util.CoreI18n;
import de.simpleeco.auction.util.Text;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/**
 * Navigation controls for the auction GUIs, using ordinary vanilla items only.
 * Labels and lore remain localized; no resource-pack models are required.
 */
public final class GuiItems {

    public static final String NAV = "&#c6c7f2";

    private GuiItems() {
    }

    public static ItemStack previousArrow(Player player, int previousPageNumber) {
        return simple(Material.ARROW,
                NAV + CoreI18n.gui(player, "common-gui.prev-page", "Previous Page"),
                "&7" + CoreI18n.gui(player, "common-gui.go-to-page", "Go to page {page}.",
                        "page", String.valueOf(previousPageNumber)));
    }

    public static ItemStack nextArrow(Player player, int nextPageNumber) {
        return simple(Material.ARROW,
                NAV + CoreI18n.gui(player, "common-gui.next-page", "Next Page"),
                "&7" + CoreI18n.gui(player, "common-gui.go-to-page", "Go to page {page}.",
                        "page", String.valueOf(nextPageNumber)));
    }

    public static ItemStack backArrow(Player player) {
        return simple(Material.ARROW,
                NAV + CoreI18n.gui(player, "common-gui.back", "Back"),
                "&7" + CoreI18n.gui(player, "common-gui.return-prev", "Return to the previous menu."));
    }

    private static String sortLabel(Player player, AuctionHolder.Sort mode) {
        return switch (mode) {
            case NEWEST -> CoreI18n.gui(player, "auction-gui.items.sort-newest", "Newest");
            case OLDEST -> CoreI18n.gui(player, "auction-gui.items.sort-oldest", "Oldest");
            case PRICE_LOW -> CoreI18n.gui(player, "auction-gui.items.sort-price-low", "Lowest price");
            case PRICE_HIGH -> CoreI18n.gui(player, "auction-gui.items.sort-price-high", "Highest price");
            case ENDING_SOON -> CoreI18n.gui(player, "auction-gui.items.sort-ending-soon", "Ending soon");
        };
    }

    /** Click-to-cycle sort control; compass appearance is vanilla. */
    public static ItemStack compass(Player player, AuctionHolder.Sort current) {
        ItemStack stack = new ItemStack(Material.COMPASS);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.of(NAV + CoreI18n.gui(player, "auction-gui.items.sorting", "Sorting")));
        List<String> lore = new ArrayList<>();
        for (AuctionHolder.Sort mode : AuctionHolder.Sort.values()) {
            lore.add((mode == current ? "&#AFAAFF\u2192 " : "&7  ") + sortLabel(player, mode));
        }
        meta.lore(Text.lore(lore));
        stack.setItemMeta(meta);
        return stack;
    }

    public static ItemStack myListings(Player player) {
        ItemStack stack = new ItemStack(Material.WRITABLE_BOOK);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.of(NAV + CoreI18n.gui(player, "auction-gui.items.my-listings", "My Listings")));
        meta.lore(Text.loreItalic(List.of("&7" + CoreI18n.gui(player, "auction-gui.items.my-listings-lore",
                "View and manage your listings."))));
        stack.setItemMeta(meta);
        return stack;
    }

    public static ItemStack sellItem(Player player) {
        ItemStack stack = new ItemStack(Material.GOLD_INGOT);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.of(NAV + CoreI18n.gui(player, "auction-gui.items.sell-item", "Sell an Item")));
        meta.lore(Text.loreItalic(List.of(
                "&7" + CoreI18n.gui(player, "auction-gui.items.sell-item-lore1", "Hold an item and click to list it,"),
                "&7" + CoreI18n.gui(player, "auction-gui.items.sell-item-lore2", "or use &f/ah sell <price>&7."))));
        stack.setItemMeta(meta);
        return stack;
    }

    public static ItemStack refresh(Player player) {
        ItemStack stack = new ItemStack(Material.CLOCK);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.of(NAV + CoreI18n.gui(player, "auction-gui.items.refresh", "Refresh")));
        meta.lore(Text.loreItalic(List.of("&7" + CoreI18n.gui(player, "auction-gui.items.refresh-lore",
                "Reload the auction house."))));
        stack.setItemMeta(meta);
        return stack;
    }

    public static ItemStack search(Player player, String currentFilter) {
        ItemStack stack = new ItemStack(Material.OAK_SIGN);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.of(NAV + CoreI18n.gui(player, "auction-gui.items.search", "Search")));
        List<String> lore = new ArrayList<>();
        if (currentFilter != null && !currentFilter.isEmpty()) {
            lore.add("&7" + CoreI18n.gui(player, "auction-gui.items.search-current", "Current:") + " &f" + currentFilter);
            lore.add("&7" + CoreI18n.gui(player, "auction-gui.items.search-change", "Click to change search."));
            lore.add("&7" + CoreI18n.gui(player, "auction-gui.items.search-clear", "Right-click to clear."));
        } else {
            lore.add("&7" + CoreI18n.gui(player, "auction-gui.items.search-hover", "Click to search for an item."));
        }
        meta.lore(Text.loreItalic(lore));
        stack.setItemMeta(meta);
        return stack;
    }

    private static ItemStack simple(Material material, String name, String loreLine) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.of(name));
        meta.lore(Text.loreItalic(List.of(loreLine)));
        stack.setItemMeta(meta);
        return stack;
    }
}
