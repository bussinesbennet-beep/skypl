package de.simpleeco.auction.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

/**
 * Identifies a confirmation GUI (buy or sell) and carries everything needed to
 * complete the action safely at confirm time.
 *
 * <p>Nothing here is trusted for the actual item/money transfer: on confirm the
 * listener re-fetches the live listing (BUY) or re-validates the held item
 * (SELL) and performs an atomic operation. This holder only carries display data
 * and the identifiers used for that re-validation, so a stale/edited GUI can
 * never cause a duplicate.
 */
public class ConfirmHolder implements InventoryHolder {

    public enum Type { BUY, SELL }

    private final Type type;
    private final long listingId;      // BUY: which listing to claim
    private final double price;        // BUY & SELL: agreed price
    private final ItemStack snapshot;  // BUY: display copy; SELL: the item to list (must still match hand)
    private Inventory inventory;

    private ConfirmHolder(Type type, long listingId, double price, ItemStack snapshot) {
        this.type = type;
        this.listingId = listingId;
        this.price = price;
        this.snapshot = snapshot;
    }

    public static ConfirmHolder buy(long listingId, double price, ItemStack display) {
        return new ConfirmHolder(Type.BUY, listingId, price, display);
    }

    public static ConfirmHolder sell(double price, ItemStack snapshot) {
        return new ConfirmHolder(Type.SELL, -1L, price, snapshot);
    }

    public Type getType() { return type; }
    public long getListingId() { return listingId; }
    public double getPrice() { return price; }
    public ItemStack getSnapshot() { return snapshot; }

    public void setInventory(Inventory inventory) { this.inventory = inventory; }

    @NotNull
    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
