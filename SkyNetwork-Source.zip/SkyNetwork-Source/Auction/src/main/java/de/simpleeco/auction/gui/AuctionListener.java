package de.simpleeco.auction.gui;

import de.simpleeco.auction.AuctionManager;
import de.simpleeco.auction.Listing;
import de.simpleeco.auction.PlaceholderHook;
import de.simpleeco.auction.StatStore;
import de.simpleeco.auction.economy.EconomyBridge;
import de.simpleeco.auction.util.NumberUtil;
import de.simpleeco.auction.util.SignInput;
import de.simpleeco.auction.util.Text;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;
import java.util.UUID;

/**
 * Handles all clicks in the auction GUIs: buying, cancelling/collecting your own
 * listings, page navigation, view toggling and starting a sell via the GUI.
 */
public class AuctionListener implements Listener {

    private final JavaPlugin plugin;
    private final AuctionManager manager;
    private final AuctionGui gui;
    private final EconomyBridge economy;
    private final StatStore stats;
    private final SignInput signInput;
    private final org.bukkit.configuration.file.FileConfiguration config;
    private final de.simpleeco.auction.economy.PrefsBridge prefs;
    private final de.simpleeco.auction.util.Sounds sounds;

    public AuctionListener(JavaPlugin plugin, AuctionManager manager, AuctionGui gui,
                           EconomyBridge economy, StatStore stats, SignInput signInput,
                           de.simpleeco.auction.economy.PrefsBridge prefs,
                           de.simpleeco.auction.util.Sounds sounds) {
        this.plugin = plugin;
        this.manager = manager;
        this.gui = gui;
        this.economy = economy;
        this.stats = stats;
        this.signInput = signInput;
        this.config = plugin.getConfig();
        this.prefs = prefs;
        this.sounds = sounds;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        Inventory top = event.getView().getTopInventory();

        // Confirmation GUI (buy / sell) has its own holder.
        if (top.getHolder() instanceof ConfirmHolder confirm) {
            if (!(event.getWhoClicked() instanceof Player p)) {
                return;
            }
            event.setCancelled(true);
            if (event.getClickedInventory() == null || !event.getClickedInventory().equals(top)) {
                return;
            }
            return;
        }

        if (!(top.getHolder() instanceof AuctionHolder holder)) {
            return;
        }
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        Inventory clicked = event.getClickedInventory();

        // Clicks in the player's OWN inventory (bottom) are allowed, so items can
        // be freely rearranged while the auction GUI is open — EXCEPT actions that
        // would move an item up into the auction inventory (shift-click, hotbar
        // swaps, collect-to-cursor), which we cancel to keep the GUI intact.
        if (clicked != null && !clicked.equals(top)) {
            InventoryAction action = event.getAction();
            if (action == InventoryAction.MOVE_TO_OTHER_INVENTORY
                    || action == InventoryAction.COLLECT_TO_CURSOR
                    || action == InventoryAction.HOTBAR_MOVE_AND_READD
                    || action == InventoryAction.HOTBAR_SWAP
                    || action == InventoryAction.UNKNOWN) {
                event.setCancelled(true);
            }
            return;
        }

        // From here on the click is inside the auction (top) inventory.
        event.setCancelled(true);
        if (clicked == null || !clicked.equals(top)) {
            return;
        }

        int slot = event.getRawSlot();

        // A soft click for the navigation/action buttons (content clicks get
        // their own success/deny feedback further down).
        switch (slot) {
            case AuctionGui.PREV_SLOT, AuctionGui.NEXT_SLOT, AuctionGui.MY_SLOT,
                 AuctionGui.SORT_SLOT, AuctionGui.SEARCH_SLOT, AuctionGui.REFRESH_SLOT,
                 AuctionGui.SELL_SLOT -> sounds.click(player);
            default -> { /* content slots handled below */ }
        }

        // Nav row handling is common to both views.
        switch (slot) {
            case AuctionGui.PREV_SLOT -> {
                openSame(player, holder, holder.getPage() - 1);
                return;
            }
            case AuctionGui.NEXT_SLOT -> {
                openSame(player, holder, holder.getPage() + 1);
                return;
            }
            case AuctionGui.MY_SLOT -> {
                // Browse: writable book -> open my listings. Mine: back arrow -> browse.
                if (holder.getView() == AuctionHolder.View.BROWSE) {
                    gui.openMine(player, 0);
                } else {
                    gui.openBrowse(player, 0);
                }
                return;
            }
            case AuctionGui.SORT_SLOT -> {
                // Only the browse view has a compass sorter; cycle to the next order.
                if (holder.getView() == AuctionHolder.View.BROWSE) {
                    gui.openBrowse(player, 0, holder.getSort().next(), holder.getFilter());
                }
                return;
            }
            case AuctionGui.SEARCH_SLOT -> {
                // Only the browse view has a search button.
                if (holder.getView() == AuctionHolder.View.BROWSE) {
                    if (event.getClick().isRightClick()) {
                        // Clear the filter.
                        gui.openBrowse(player, 0, holder.getSort(), null);
                    } else {
                        startSearchFromGui(player, holder.getSort());
                    }
                }
                return;
            }
            case AuctionGui.REFRESH_SLOT -> {
                // Only the browse view has a refresh (anvil), like the order board.
                if (holder.getView() == AuctionHolder.View.BROWSE) {
                    gui.openBrowse(player, holder.getPage(), holder.getSort(), holder.getFilter());
                }
                return;
            }
            case AuctionGui.SELL_SLOT -> {
                startSellFromGui(player);
                return;
            }
            default -> { /* fall through to content handling */ }
        }

        if (slot < 0 || slot >= AuctionGui.CONTENT) {
            return;
        }
        long listingId = holder.listingAt(slot);
        if (listingId < 0) {
            return;
        }
        Listing listing = manager.byId(listingId);
        if (listing == null) {
            // Stale view; refresh.
            openSame(player, holder, holder.getPage());
            return;
        }

        if (holder.getView() == AuctionHolder.View.BROWSE) {
            // Pre-checks before showing the confirmation screen (cheap early-outs;
            // the real, atomic checks happen again on confirm).
            if (listing.getSeller().equals(player.getUniqueId())) {
                send(player, "messages.own-listing");
                sounds.deny(player);
                return;
            }
            boolean wantConfirm = prefs.get(player.getUniqueId(),
                    de.simpleeco.economy.api.SimplePrefsAPI.KEY_AH_CONFIRM, true);
            if (wantConfirm) {
                gui.openBuyConfirm(player, listing, () -> confirmBuy(player,
                    ConfirmHolder.buy(listing.getId(), listing.getPrice(), listing.getItem().clone())));
            } else {
                // Confirmation disabled: buy immediately (same atomic path).
                confirmBuy(player, ConfirmHolder.buy(listing.getId(), listing.getPrice(),
                        listing.getItem().clone()));
            }
        } else {
            handleOwned(player, listing, holder);
        }
    }

    // ------------------------------------------------------- confirmation GUI

    private void confirmBuy(Player player, ConfirmHolder confirm) {
        long id = confirm.getListingId();
        Listing listing = manager.byId(id);
        if (listing == null || !listing.isActive()) {
            send(player, "messages.listing-gone");
            gui.openBrowse(player, 0);
            return;
        }
        if (listing.getSeller().equals(player.getUniqueId())) {
            send(player, "messages.own-listing");
            gui.openBrowse(player, 0);
            return;
        }
        if (!economy.isAvailable()) {
            send(player, "messages.economy-missing");
            sounds.deny(player);
            return;
        }
        double price = listing.getPrice();
        if (!economy.has(player.getUniqueId(), price)) {
            send(player, "messages.cannot-afford", "price", economy.format(price));
            sounds.deny(player);
            return;
        }
        if (!hasRoom(player, listing.getItem())) {
            send(player, "messages.inventory-full");
            sounds.deny(player);
            return;
        }

        // ATOMIC CLAIM: whoever removes the listing first wins; a second buyer
        // gets null here and is aborted with no money taken and no item given.
        Listing claimed = manager.claim(id);
        if (claimed == null) {
            send(player, "messages.listing-gone");
            gui.openBrowse(player, 0);
            return;
        }

        // Take the money only AFTER we own the claim. If withdrawal fails, put
        // the listing back so nothing is lost.
        if (!economy.withdraw(player.getUniqueId(), price)) {
            manager.reinsert(claimed);
            send(player, "messages.cannot-afford", "price", economy.format(price));
            gui.openBrowse(player, 0);
            return;
        }
        economy.deposit(claimed.getSeller(), price);

        // Record cross-plugin statistics: buyer spent, seller made.
        economy.recordAuctionSpent(player.getUniqueId(), price);
        economy.recordAuctionMade(claimed.getSeller(), price);

        // Deliver a fresh clone of the stored item (never the live reference).
        giveItem(player, claimed.getItem().clone());

        if (stats != null) {
            stats.add(player.getUniqueId(), PlaceholderHook.KEY_SPENT, price);
            stats.add(claimed.getSeller(), PlaceholderHook.KEY_EARNED, price);
        }

        send(player, "messages.bought",
                "item", itemName(claimed.getItem()),
                "price", economy.format(price));
        sounds.success(player);

        Player seller = plugin.getServer().getPlayer(claimed.getSeller());
        if (seller != null && seller.isOnline()) {
            sendTo(seller, "messages.sold-notify",
                    "item", itemName(claimed.getItem()),
                    "price", economy.format(price),
                    "buyer", player.getName());
        }
        gui.openBrowse(player, 0);
    }

    public void confirmSell(Player player, ConfirmHolder confirm) {
        ItemStack snapshot = confirm.getSnapshot();
        double price = confirm.getPrice();

        if (manager.atLimit(player.getUniqueId())) {
            send(player, "messages.limit-reached",
                    "limit", String.valueOf(manager.getMaxListingsPerPlayer()));
            gui.openBrowse(player, 0);
            return;
        }
        // The held item must STILL match exactly what we previewed, and hold at
        // least the same amount, or we abort (prevents listing an item the player
        // swapped away in the meantime → item creation dupe).
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand == null || hand.getType() == Material.AIR
                || !hand.isSimilar(snapshot) || hand.getAmount() < snapshot.getAmount()) {
            send(player, "messages.sell-item-changed");
            gui.openBrowse(player, 0);
            return;
        }

        // Remove EXACTLY the listed amount from the hand first, so the item is
        // consumed before the listing exists. Then create the listing from the
        // trusted snapshot.
        ItemStack toList = snapshot.clone();
        int newAmount = hand.getAmount() - snapshot.getAmount();
        if (newAmount <= 0) {
            player.getInventory().setItemInMainHand(null);
        } else {
            ItemStack remaining = hand.clone();
            remaining.setAmount(newAmount);
            player.getInventory().setItemInMainHand(remaining);
        }

        Listing listing = manager.create(player.getUniqueId(), player.getName(), toList, price);
        if (listing == null) {
            // Roll back: give the consumed item back.
            giveItem(player, toList);
            send(player, "messages.list-failed");
            gui.openBrowse(player, 0);
            return;
        }
        send(player, "messages.listed",
                "item", itemName(toList),
                "price", economy.format(price));
        sounds.success(player);
        gui.openMine(player, 0);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (top.getHolder() instanceof ConfirmHolder) {
            // Confirm screen is fully modal: never allow drags into it.
            int size = top.getSize();
            for (int raw : event.getRawSlots()) {
                if (raw < size) {
                    event.setCancelled(true);
                    return;
                }
            }
            return;
        }
        if (!(top.getHolder() instanceof AuctionHolder)) {
            return;
        }
        // Only cancel drags that touch a slot in the auction (top) inventory;
        // drags confined to the player's own inventory are fine.
        int topSize = top.getSize();
        for (int raw : event.getRawSlots()) {
            if (raw < topSize) {
                event.setCancelled(true);
                return;
            }
        }
    }

    // ------------------------------------------------------------- owned

    private void handleOwned(Player player, Listing listing, AuctionHolder holder) {
        if (!listing.getSeller().equals(player.getUniqueId())) {
            return;
        }
        if (!hasRoom(player, listing.getItem())) {
            send(player, "messages.inventory-full");
            return;
        }
        boolean expired = listing.getStatus() == Listing.Status.EXPIRED;
        // ATOMIC CLAIM: guarantees the item is handed back exactly once even if
        // the player double-clicks or it sells/expires on the same tick.
        Listing claimed = manager.claim(listing.getId());
        if (claimed == null) {
            openSame(player, holder, holder.getPage());
            return;
        }
        giveItem(player, claimed.getItem().clone());
        send(player, expired ? "messages.collected" : "messages.cancelled",
                "item", itemName(claimed.getItem()));
        sounds.success(player);
        openSame(player, holder, holder.getPage());
    }

    // ------------------------------------------------------------- selling

    /** Starts a sell for the item currently in the player's main hand, via a sign price prompt. */
    private void startSellFromGui(Player player) {
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand == null || hand.getType() == Material.AIR) {
            send(player, "messages.sell-no-item");
            sounds.deny(player);
            return;
        }
        if (manager.atLimit(player.getUniqueId())) {
            send(player, "messages.limit-reached",
                    "limit", String.valueOf(manager.getMaxListingsPerPlayer()));
            sounds.deny(player);
            return;
        }
        player.closeInventory();
        ItemStack snapshot = hand.clone();

        // Native dialog text field instead of a sign.
        java.util.List<io.papermc.paper.registry.data.dialog.body.DialogBody> body = new java.util.ArrayList<>();
        body.add(de.simpleeco.auction.util.DialogUi.itemBody(snapshot.clone()));
        body.add(de.simpleeco.auction.util.DialogUi.muted("e.g. 1000 or 1K"));

        de.simpleeco.auction.util.DialogUi.input(plugin, player,
                de.simpleeco.auction.util.DialogUi.title("Enter price"),
                body, "price", "Price", "", 16,
                "Continue", "Cancel",
                (p, typed) -> completeSell(p, snapshot, typed),
                null);
    }

    /** Validates the typed price and opens the sell confirmation if the item still matches. */
    private void completeSell(Player player, ItemStack snapshot, String input) {
        double price = NumberUtil.parse(input);
        if (Double.isNaN(price) || price <= 0) {
            send(player, "messages.invalid-price");
            gui.openBrowse(player, 0);
            return;
        }
        double min = config.getDouble("listing.min-price", 1);
        double max = config.getDouble("listing.max-price", 0);
        if (price < min) {
            send(player, "messages.price-too-low", "min", economy.format(min));
            gui.openBrowse(player, 0);
            return;
        }
        if (max > 0 && price > max) {
            send(player, "messages.price-too-high", "max", economy.format(max));
            gui.openBrowse(player, 0);
            return;
        }
        if (manager.atLimit(player.getUniqueId())) {
            send(player, "messages.limit-reached",
                    "limit", String.valueOf(manager.getMaxListingsPerPlayer()));
            gui.openBrowse(player, 0);
            return;
        }
        // Make sure the player still holds the same item.
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand == null || !hand.isSimilar(snapshot) || hand.getAmount() < snapshot.getAmount()) {
            send(player, "messages.sell-item-changed");
            gui.openBrowse(player, 0);
            return;
        }
        // Show the confirmation screen; the item is only consumed on confirm.
        ItemStack toList = snapshot.clone();
        gui.openSellConfirm(player, toList, price, () -> confirmSell(player,
                    ConfirmHolder.sell(price, toList.clone())));
    }

    // ------------------------------------------------------------- helpers

    private void openSame(Player player, AuctionHolder holder, int page) {
        if (holder.getView() == AuctionHolder.View.BROWSE) {
            gui.openBrowse(player, page, holder.getSort(), holder.getFilter());
        } else {
            gui.openMine(player, page);
        }
    }

    /** Opens a dialog with a text field to type a search term. */
    private void startSearchFromGui(Player player, AuctionHolder.Sort sort) {
        player.closeInventory();
        de.simpleeco.auction.util.DialogUi.input(plugin, player,
                de.simpleeco.auction.util.DialogUi.title("Search auction"),
                java.util.List.of(de.simpleeco.auction.util.DialogUi.muted("Type a keyword, e.g. diamond")),
                "search", "Search", "", 32,
                "Search", "Cancel",
                (p, typed) -> {
                    String term = typed == null ? "" : typed.trim();
                    gui.openBrowse(p, 0, sort, term.isEmpty() ? null : term);
                },
                (p) -> gui.openBrowse(p, 0, sort, null));
    }

    private boolean hasRoom(Player player, ItemStack item) {
        int free = 0;
        int max = item.getMaxStackSize();
        for (ItemStack s : player.getInventory().getStorageContents()) {
            if (s == null || s.getType() == Material.AIR) {
                free += max;
            } else if (s.isSimilar(item)) {
                free += Math.max(0, max - s.getAmount());
            }
        }
        return free >= item.getAmount();
    }

    private void giveItem(Player player, ItemStack item) {
        var leftover = player.getInventory().addItem(item.clone());
        for (ItemStack l : leftover.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), l);
        }
    }

    private String itemName(ItemStack item) {
        int amount = item.getAmount();
        String base;
        if (item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
            base = net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                    .legacyAmpersand().serialize(item.getItemMeta().displayName());
        } else {
            base = prettyMaterial(item.getType());
        }
        return amount > 1 ? amount + "x " + base : base;
    }

    private String prettyMaterial(Material material) {
        String[] parts = material.name().toLowerCase().split("_");
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (p.isEmpty()) continue;
            sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1)).append(' ');
        }
        return sb.toString().trim();
    }

    // ------------------------------------------------------------- messages

    private void send(Player player, String path, String... repl) {
        sendTo(player, path, repl);
    }

    private void sendTo(Player target, String path, String... repl) {
        String key = path.startsWith("messages.") ? path.substring("messages.".length()) : path;
        if (!config.getBoolean("message-toggles." + key, true)) {
            return;
        }
        String translated = de.simpleeco.auction.util.CoreI18n.translate(target, "auction." + key, repl);
        String text;
        if (translated != null) {
            text = config.getString("messages.prefix", "") + translated;
        } else {
            String raw = config.getString(path, "");
            if (raw == null || raw.isEmpty()) {
                return;
            }
            text = config.getString("messages.prefix", "") + raw;
        }
        for (int i = 0; i + 1 < repl.length; i += 2) {
            text = text.replace("{" + repl[i] + "}", repl[i + 1]);
        }
        net.kyori.adventure.text.Component component = Text.of(text);
        java.util.UUID id = target.getUniqueId();
        if (!prefs.get(id, de.simpleeco.economy.api.SimplePrefsAPI.KEY_AUCTION_ALERTS, true)) return;
        if (prefs.get(id, de.simpleeco.economy.api.SimplePrefsAPI.KEY_SERVER_CHAT_MESSAGES, true)
                && prefs.get(id, de.simpleeco.economy.api.SimplePrefsAPI.KEY_CHAT_MESSAGES, true)) {
            target.sendMessage(component);
        }
        if (prefs.get(id, de.simpleeco.economy.api.SimplePrefsAPI.KEY_HOTBAR_MESSAGES, true)) {
            target.sendActionBar(component);
        }
        if (prefs.get(id, de.simpleeco.economy.api.SimplePrefsAPI.KEY_GUI_SOUNDS, true)) {
            target.playSound(target.getLocation(), org.bukkit.Sound.BLOCK_NOTE_BLOCK_PLING, 0.35f, 1.65f);
        }
    }
}
