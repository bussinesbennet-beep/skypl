package de.simpleeco.auction;

import de.simpleeco.auction.economy.EconomyBridge;
import de.simpleeco.auction.gui.AuctionGui;
import de.simpleeco.auction.gui.AuctionListener;
import de.simpleeco.auction.util.NumberUtil;
import de.simpleeco.auction.util.Text;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * /ah                  -> opens the auction house GUI
 * /ah sell <price>     -> lists the held item at the given price (1000 or 1K)
 * /ah reload           -> reloads the configuration (permission: auction.reload)
 */
public class AuctionCommand implements TabExecutor {

    private final AuctionPlugin plugin;
    private final AuctionManager manager;
    private final AuctionGui gui;
    private final AuctionListener listener;
    private final EconomyBridge economy;
    private final StatStore stats;

    public AuctionCommand(AuctionPlugin plugin, AuctionManager manager, AuctionGui gui,
                          AuctionListener listener,
                          EconomyBridge economy, StatStore stats) {
        this.plugin = plugin;
        this.manager = manager;
        this.gui = gui;
        this.listener = listener;
        this.economy = economy;
        this.stats = stats;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (args.length >= 1 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("auction.reload")) {
                sender.sendMessage(msg("no-permission"));
                return true;
            }
            plugin.reloadConfig();
            sender.sendMessage(msg("reloaded"));
            return true;
        }

        if (!(sender instanceof Player player)) {
            sender.sendMessage(Text.of("&7Only players can use the auction house."));
            return true;
        }
        if (!player.hasPermission("auction.use")) {
            player.sendMessage(msg(player, "no-permission"));
            return true;
        }

        if (args.length >= 1 && args[0].equalsIgnoreCase("sell")) {
            handleSell(player, args);
            return true;
        }

        // /ah <search terms...> -> open the auction house filtered by that term.
        if (args.length >= 1) {
            String term = String.join(" ", args).trim();
            gui.openBrowse(player, 0, de.simpleeco.auction.gui.AuctionHolder.Sort.NEWEST,
                    term.isEmpty() ? null : term);
            return true;
        }

        gui.openBrowse(player, 0);
        return true;
    }

    private void handleSell(Player player, String[] args) {
        if (args.length < 2) {
            return;
        }
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand == null || hand.getType() == Material.AIR) {
            player.sendMessage(msg(player, "sell-no-item"));
            return;
        }
        double price = NumberUtil.parse(args[1]);
        if (Double.isNaN(price) || price <= 0) {
            player.sendMessage(msg(player, "invalid-price"));
            return;
        }
        double min = plugin.getConfig().getDouble("listing.min-price", 1);
        double max = plugin.getConfig().getDouble("listing.max-price", 0);
        if (price < min) {
            player.sendMessage(msg(player, "price-too-low", "min", economy.format(min)));
            return;
        }
        if (max > 0 && price > max) {
            player.sendMessage(msg(player, "price-too-high", "max", economy.format(max)));
            return;
        }
        if (manager.atLimit(player.getUniqueId())) {
            player.sendMessage(msg(player, "limit-reached",
                    "limit", String.valueOf(manager.getMaxListingsPerPlayer())));
            return;
        }

        // Route through the confirmation dialog; the item is only consumed on confirm.
        ItemStack toList = hand.clone();
        de.simpleeco.economy.api.SimplePrefsAPI prefs=org.bukkit.Bukkit.getServicesManager().load(de.simpleeco.economy.api.SimplePrefsAPI.class);
        if(prefs!=null&&prefs.get(player.getUniqueId(),de.simpleeco.economy.api.SimplePrefsAPI.KEY_AH_QUICK_SELL,false)){
            listener.confirmSell(player,de.simpleeco.auction.gui.ConfirmHolder.sell(price,toList.clone()));
            return;
        }
        gui.openSellConfirm(player, toList, price,
                () -> listener.confirmSell(player,
                        de.simpleeco.auction.gui.ConfirmHolder.sell(price, toList.clone())));
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                      @NotNull String alias, @NotNull String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            // Note: "sell" is intentionally NOT suggested (it still works when typed).
            if (sender.hasPermission("auction.reload") && "reload".startsWith(prefix)) out.add("reload");
        } else if (args.length == 2 && args[0].equalsIgnoreCase("sell")) {
            out.add("<price>");
            out.add("1000");
            out.add("1K");
        }
        return out;
    }

    private String itemName(ItemStack item) {
        int amount = item.getAmount();
        String base;
        if (item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
            base = net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                    .legacyAmpersand().serialize(item.getItemMeta().displayName());
        } else {
            String[] parts = item.getType().name().toLowerCase().split("_");
            StringBuilder sb = new StringBuilder();
            for (String p : parts) {
                if (p.isEmpty()) continue;
                sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1)).append(' ');
            }
            base = sb.toString().trim();
        }
        return amount > 1 ? amount + "x " + base : base;
    }

    private net.kyori.adventure.text.Component msg(org.bukkit.entity.Player player, String key, String... repl) {
        String translated = de.simpleeco.auction.util.CoreI18n.translate(player, "auction." + key, repl);
        if (translated != null) {
            var config = plugin.getConfig();
            if (!config.getBoolean("message-toggles." + key, true)) {
                return net.kyori.adventure.text.Component.empty();
            }
            return Text.of(config.getString("messages.prefix", "") + translated);
        }
        return msg(key, repl);
    }

    private net.kyori.adventure.text.Component msg(String key, String... repl) {
        var config = plugin.getConfig();
        if (!config.getBoolean("message-toggles." + key, true)) {
            return net.kyori.adventure.text.Component.empty();
        }
        String text = config.getString("messages.prefix", "") + config.getString("messages." + key, "");
        for (int i = 0; i + 1 < repl.length; i += 2) {
            text = text.replace("{" + repl[i] + "}", repl[i + 1]);
        }
        return Text.of(text);
    }
}
