package de.simpleeco.auction.util;

import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

/**
 * Anti-dupe safety net for GUI (decorative / display) items.
 *
 * <p>Every item placed into one of our menus purely for display — nav buttons,
 * icons, previews, confirmation buttons — is stamped with a hidden persistent
 * marker via {@link #mark(ItemStack)} / {@link #markAll(Inventory)}. These items
 * should never leave the menu: the plugins hand players FRESH, unmarked items on
 * a real purchase/collect.
 *
 * <p>If a bug, lag exploit or dupe glitch ever causes a marked display item to
 * land in a player's real inventory, this guard deletes it on sight. The check
 * runs immediately after any inventory interaction (next tick), whenever a
 * player picks an item off the ground, on inventory close, on join, and on a
 * light periodic backstop sweep. Real, takeable items are never marked, so
 * legitimate transfers are completely unaffected.
 *
 * <p>The marker uses a shared namespace ("simpleeco"), so ALL of the suite's
 * plugins recognise and purge each other's stray GUI items — installing any one
 * of them protects against all of them.
 */
public class GuiGuard implements Listener {

    /** Shared across the whole plugin suite so every guard recognises every marker. */
    private static final NamespacedKey KEY = new NamespacedKey("simpleeco", "gui_guard");
    private static final byte VALUE = (byte) 1;

    private final Plugin plugin;

    public GuiGuard(Plugin plugin) {
        this.plugin = plugin;
    }

    // ----------------------------------------------------------- marking

    /** Stamps the hidden guard marker onto an item (returns the same instance). */
    public static ItemStack mark(ItemStack item) {
        if (item == null || item.getType().isAir()) {
            return item;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }
        meta.getPersistentDataContainer().set(KEY, PersistentDataType.BYTE, VALUE);
        item.setItemMeta(meta);
        return item;
    }

    /** Marks every non-empty item currently in the inventory. */
    public static void markAll(Inventory inv) {
        markRange(inv, 0, inv.getSize());
    }

    /** Marks every non-empty item in [from, to) of the inventory. */
    public static void markRange(Inventory inv, int from, int to) {
        int end = Math.min(to, inv.getSize());
        for (int i = Math.max(0, from); i < end; i++) {
            ItemStack st = inv.getItem(i);
            if (st != null && !st.getType().isAir()) {
                inv.setItem(i, mark(st));
            }
        }
    }

    /** @return true if the item carries the guard marker. */
    public static boolean isMarked(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) {
            return false;
        }
        PersistentDataContainer pdc = item.getItemMeta().getPersistentDataContainer();
        return pdc.has(KEY, PersistentDataType.BYTE);
    }

    // ----------------------------------------------------------- sweeping

    /**
     * Removes any marked GUI items from a player's real inventory: storage,
     * hotbar, armor, offhand and the item on the cursor. Returns the count
     * removed (for optional logging).
     */
    public static int sweep(Player player) {
        int removed = 0;
        PlayerInventory inv = player.getInventory();

        ItemStack[] contents = inv.getContents(); // storage + armor + offhand
        for (int i = 0; i < contents.length; i++) {
            if (isMarked(contents[i])) {
                inv.setItem(i, null);
                removed++;
            }
        }
        // The item on the cursor is not part of getContents().
        ItemStack cursor = player.getItemOnCursor();
        if (isMarked(cursor)) {
            player.setItemOnCursor(null);
            removed++;
        }
        if (removed > 0) {
            player.updateInventory();
        }
        return removed;
    }

    /** Schedules a sweep of the player on the next tick. */
    private void sweepNextTick(Player player) {
        Bukkit.getScheduler().runTask(plugin, () -> sweep(player));
    }

    /** Registers a light periodic backstop sweep of all online players (every 5s). */
    public void startPeriodicSweep() {
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                sweep(p);
            }
        }, 200L, 200L); // backstop sweep: 10s is plenty and halves the cost
    }

    // ----------------------------------------------------------- events

    @EventHandler(priority = EventPriority.MONITOR)
    public void onClick(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player player) {
            sweepNextTick(player);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDrag(InventoryDragEvent event) {
        if (event.getWhoClicked() instanceof Player player) {
            sweepNextTick(player);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onClose(InventoryCloseEvent event) {
        if (event.getPlayer() instanceof Player player) {
            sweepNextTick(player);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent event) {
        if (event.getEntity() instanceof Player) {
            // A marked item should never exist as a ground entity; if one does,
            // destroy it rather than let it be picked up.
            if (isMarked(event.getItem().getItemStack())) {
                event.setCancelled(true);
                event.getItem().remove();
            }
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        // Catch anything a player logged out holding.
        Bukkit.getScheduler().runTaskLater(plugin, () -> sweep(event.getPlayer()), 20L);
    }
}
