package de.simpleeco.auction;

import de.simpleeco.auction.economy.EconomyBridge;
import de.simpleeco.auction.gui.AuctionGui;
import de.simpleeco.auction.gui.AuctionListener;
import de.simpleeco.auction.storage.AuctionStorage;
import de.simpleeco.auction.util.GuiGuard;
import de.simpleeco.auction.util.SignInput;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.sql.SQLException;
import de.simpleeco.auction.util.CoreI18n;

/**
 * Auction House: a buy-it-now marketplace on top of SimpleEconomy. Players list
 * held items for a fixed price; others buy them instantly. Listings expire after
 * a configurable time and can then be collected back by the seller.
 */
public class AuctionPlugin extends JavaPlugin {

    private AuctionStorage storage;
    private AuctionManager manager;
    private EconomyBridge economy;
    private StatStore stats;
    private SignInput signInput;
    private int sweepTaskId = -1;

    @Override
    public void onEnable() {
        CoreI18n.registerReloadable("auction", () -> { saveDefaultConfig(); reloadConfig(); });
        saveDefaultConfig();

        economy = new EconomyBridge(this);
        economy.resolve();

        storage = new AuctionStorage(this, getConfig().getString("database.file", "../../../network-data/auctions.db"));
        try {
            storage.init();
        } catch (SQLException e) {
            getLogger().severe("Failed to initialise auction storage: " + e.getMessage());
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        long durationMillis = Math.max(1, getConfig().getLong("listing.duration-hours", 48)) * 3600_000L;
        int maxListings = getConfig().getInt("listing.max-per-player", 10);
        manager = new AuctionManager(storage, durationMillis, maxListings);
        manager.loadAll();
        manager.sweepExpired(); // catch anything that expired while offline

        stats = new StatStore(this);
        signInput = new SignInput(this);
        getServer().getPluginManager().registerEvents(signInput, this);

        de.simpleeco.auction.economy.PrefsBridge prefs = new de.simpleeco.auction.economy.PrefsBridge();
        prefs.resolve();

        AuctionGui gui = new AuctionGui(manager, economy, getConfig());
        AuctionListener listener = new AuctionListener(this, manager, gui, economy, stats, signInput, prefs,
                new de.simpleeco.auction.util.Sounds(prefs));
        getServer().getPluginManager().registerEvents(listener, this);

        // Anti-dupe safety net: purge any stray GUI/display item that ends up in
        // a real player inventory (should only ever happen via a bug/exploit).
        GuiGuard guard = new GuiGuard(this);
        getServer().getPluginManager().registerEvents(guard, this);
        guard.startPeriodicSweep();

        PluginCommand cmd = getCommand("auction");
        if (cmd != null) {
            AuctionCommand executor = new AuctionCommand(this, manager, gui, listener, economy, stats);
            cmd.setExecutor(executor);
            cmd.setTabCompleter(executor);
        }

        // Periodic expiry sweep (every minute).
        sweepTaskId = getServer().getScheduler().runTaskTimer(this,
                manager::sweepExpired, 1200L, 1200L).getTaskId();

        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new PlaceholderHook(stats, manager).register();
            getLogger().info("Hooked into PlaceholderAPI (%auction_...%).");
        }

        if (!economy.isAvailable()) {
            getLogger().warning("SimpleEconomy service not found - buying/selling is disabled "
                    + "until SimpleEconomy is available.");
        }

        getLogger().info("Auction has been enabled with " + manager.activeListings().size()
                + " active listing(s).");
    }

    @Override
    public void onDisable() {
        if (sweepTaskId != -1) {
            getServer().getScheduler().cancelTask(sweepTaskId);
        }
        if (stats != null) {
            stats.saveNow();
        }
        if (storage != null) {
            storage.close();
        }
        getLogger().info("Auction has been disabled.");
    }
}
