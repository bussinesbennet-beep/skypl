package de.simpleeco.auction;

import org.bukkit.inventory.ItemStack;

import java.util.UUID;

/**
 * A single buy-it-now auction listing: an item offered by a seller at a fixed
 * price, with an expiry timestamp.
 *
 * <p>After a listing sells or expires it becomes "collectable" by its seller —
 * either the earned money (sold) or the item back (expired). That collection
 * state is tracked with {@link #status}.
 */
public class Listing {

    public enum Status {
        /** Active and buyable. */
        ACTIVE,
        /** Sold; seller can collect the money (handled at sale time, so mostly transient). */
        SOLD,
        /** Expired; the item is waiting for the seller to collect it back. */
        EXPIRED
    }

    private final long id;
    private final UUID seller;
    private final String sellerName;
    private final ItemStack item;
    private final double price;
    private final long createdAt;
    private final long expiresAt;
    private Status status;

    public Listing(long id, UUID seller, String sellerName, ItemStack item,
                   double price, long createdAt, long expiresAt, Status status) {
        this.id = id;
        this.seller = seller;
        this.sellerName = sellerName;
        this.item = item;
        this.price = price;
        this.createdAt = createdAt;
        this.expiresAt = expiresAt;
        this.status = status;
    }

    public long getId() { return id; }
    public UUID getSeller() { return seller; }
    public String getSellerName() { return sellerName; }
    public ItemStack getItem() { return item; }
    public double getPrice() { return price; }
    public long getCreatedAt() { return createdAt; }
    public long getExpiresAt() { return expiresAt; }
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }

    public boolean isActive() { return status == Status.ACTIVE; }

    /** @return true if this active listing's expiry time has passed. */
    public boolean isExpired(long now) {
        return status == Status.ACTIVE && now >= expiresAt;
    }

    /** Milliseconds until expiry (never negative). */
    public long millisLeft(long now) {
        return Math.max(0, expiresAt - now);
    }
}
