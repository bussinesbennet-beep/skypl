package de.simpleeco.auction.util;

import org.bukkit.inventory.ItemStack;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Base64;

/**
 * Serializes ItemStacks to/from Base64 strings so full items (enchantments,
 * custom names, lore, NBT) can be stored in the database and restored exactly.
 */
public final class ItemCodec {

    private ItemCodec() {
    }

    /** Encodes an ItemStack to a Base64 string, or null on failure. */
    public static String encode(ItemStack item) {
        if (item == null) {
            return null;
        }
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
             BukkitObjectOutputStream out = new BukkitObjectOutputStream(baos)) {
            out.writeObject(item);
            out.flush();
            return Base64.getEncoder().encodeToString(baos.toByteArray());
        } catch (Exception e) {
            return null;
        }
    }

    /** Decodes a Base64 string back into an ItemStack, or null on failure. */
    public static ItemStack decode(String data) {
        if (data == null || data.isEmpty()) {
            return null;
        }
        try (ByteArrayInputStream bais = new ByteArrayInputStream(Base64.getDecoder().decode(data));
             BukkitObjectInputStream in = new BukkitObjectInputStream(bais)) {
            Object obj = in.readObject();
            return obj instanceof ItemStack stack ? stack : null;
        } catch (Exception e) {
            return null;
        }
    }
}
