package de.simpleeco.auction.economy;

import de.simpleeco.economy.api.SimpleEconomyAPI;
import de.simpleeco.economy.api.SimpleStatsAPI;
import org.bukkit.Bukkit;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.UUID;

/**
 * Bridges to SimpleEconomy for Dollar handling. Also records the "auction spent"
 * and "auction made" suite statistics via the optional SimpleStatsAPI.
 */
public class EconomyBridge {

    private final JavaPlugin plugin;
    private SimpleEconomyAPI dollars;
    private SimpleStatsAPI stats;

    public EconomyBridge(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void resolve() {
        RegisteredServiceProvider<SimpleEconomyAPI> d =
                Bukkit.getServicesManager().getRegistration(SimpleEconomyAPI.class);
        dollars = d != null ? d.getProvider() : null;
        if (dollars == null) {
            plugin.getLogger().warning("SimpleEconomy not found - orders are disabled.");
        }
        try {
            RegisteredServiceProvider<SimpleStatsAPI> s =
                    Bukkit.getServicesManager().getRegistration(SimpleStatsAPI.class);
            stats = s != null ? s.getProvider() : null;
        } catch (Throwable t) {
            stats = null;
        }
    }

    /** Records Dollars a buyer spent on a listing. */
    public void recordAuctionSpent(UUID buyer, double amount) {
        if (stats != null) {
            stats.add(buyer, SimpleStatsAPI.KEY_AUCTION_SPENT, amount);
        }
    }

    /** Records Dollars a seller made from a sold listing. */
    public void recordAuctionMade(UUID seller, double amount) {
        if (stats != null) {
            stats.add(seller, SimpleStatsAPI.KEY_AUCTION_MADE, amount);
        }
    }

    public boolean isAvailable() {
        return dollars != null;
    }

    public double getBalance(UUID uuid) {
        return dollars != null ? dollars.getBalance(uuid) : 0;
    }

    public boolean has(UUID uuid, double amount) {
        return dollars != null && dollars.has(uuid, amount);
    }

    public boolean withdraw(UUID uuid, double amount) {
        return dollars != null && dollars.withdraw(uuid, amount);
    }

    public void deposit(UUID uuid, double amount) {
        if (dollars != null) {
            dollars.deposit(uuid, amount);
        }
    }

    public String format(double amount) {
        return dollars != null ? dollars.format(amount) : ("$" + amount);
    }

    public String symbol() {
        return dollars != null ? dollars.getCurrencySymbol() : "$";
    }
}
