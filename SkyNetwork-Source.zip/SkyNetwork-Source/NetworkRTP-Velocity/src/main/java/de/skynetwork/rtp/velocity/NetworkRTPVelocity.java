package de.skynetwork.rtp.velocity;

import com.google.inject.Inject;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.connection.DisconnectEvent;
import com.velocitypowered.api.event.player.ServerConnectedEvent;
import com.velocitypowered.api.event.connection.PluginMessageEvent;
import com.velocitypowered.api.plugin.Plugin;
import com.velocitypowered.api.plugin.annotation.DataDirectory;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.proxy.ServerConnection;
import com.velocitypowered.api.proxy.server.RegisteredServer;
import com.velocitypowered.api.proxy.messages.MinecraftChannelIdentifier;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.slf4j.Logger;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

@Plugin(id="networkrtpvelocity",name="NetworkRTPVelocity",version="1.0.0")
public final class NetworkRTPVelocity {
    private static final MinecraftChannelIdentifier CHANNEL=MinecraftChannelIdentifier.from("networkrtp:rtp");
    private static final LegacyComponentSerializer AMP=LegacyComponentSerializer.legacyAmpersand();
    private record Pending(UUID request,String destination){}
    private final ProxyServer proxy;
    private final Logger logger;
    private final Path dataDirectory;
    private final Properties config=new Properties();
    private final Map<UUID,Pending> pending=new ConcurrentHashMap<>();
    private final Map<UUID,UUID> active=new ConcurrentHashMap<>();
    private final Map<UUID,Long> cooldowns=new ConcurrentHashMap<>();

    @Inject public NetworkRTPVelocity(ProxyServer proxy,Logger logger,@DataDirectory Path dataDirectory){this.proxy=proxy;this.logger=logger;this.dataDirectory=dataDirectory;load();proxy.getChannelRegistrar().register(CHANNEL);}
    private void load(){try{Files.createDirectories(dataDirectory);Path file=dataDirectory.resolve("config.properties");if(!Files.exists(file))try(var in=getClass().getResourceAsStream("/config.properties")){if(in!=null)Files.copy(in,file);}try(var reader=Files.newBufferedReader(file)){config.load(reader);}Path store=dataDirectory.resolve("cooldowns.properties");if(Files.exists(store)){Properties saved=new Properties();try(var reader=Files.newBufferedReader(store)){saved.load(reader);}for(String key:saved.stringPropertyNames())try{long end=Long.parseLong(saved.getProperty(key));if(end>System.currentTimeMillis())cooldowns.put(UUID.fromString(key),end);}catch(Exception ignored){}}}catch(Exception exception){logger.error("Could not load NetworkRTP settings",exception);}}
    private void saveCooldowns(){try{Properties saved=new Properties();long now=System.currentTimeMillis();cooldowns.forEach((uuid,end)->{if(end>now)saved.setProperty(uuid.toString(),Long.toString(end));});try(var out=Files.newBufferedWriter(dataDirectory.resolve("cooldowns.properties"))){saved.store(out,"Network RTP cooldown timestamps");}}catch(IOException exception){logger.error("Could not save RTP cooldowns",exception);}}

    @Subscribe public void onPluginMessage(PluginMessageEvent event){if(!CHANNEL.equals(event.getIdentifier()))return;event.setResult(PluginMessageEvent.ForwardResult.handled());if(!(event.getSource() instanceof ServerConnection origin))return;try(DataInputStream input=new DataInputStream(new ByteArrayInputStream(event.getData()))){String action=input.readUTF();if(action.equals("REQUEST")){UUID request=UUID.fromString(input.readUTF()),uuid=UUID.fromString(input.readUTF());String key=input.readUTF();boolean bypass=Boolean.parseBoolean(input.readUTF());handleRequest(origin,request,uuid,key,bypass);}else if(action.equals("RESULT")){UUID request=UUID.fromString(input.readUTF()),uuid=UUID.fromString(input.readUTF());String status=input.readUTF();handleResult(request,uuid,status);}else if(action.equals("CANCEL")){UUID request=UUID.fromString(input.readUTF()),uuid=UUID.fromString(input.readUTF());active.remove(uuid,request);pending.remove(uuid);}}catch(Exception exception){logger.warn("Rejected malformed RTP message from {}: {}",origin.getServer().getServerInfo().getName(),exception.getMessage());}}
    private void handleRequest(ServerConnection origin,UUID request,UUID uuid,String key,boolean bypass){Player player=proxy.getPlayer(uuid).orElse(null);if(player==null||!player.getCurrentServer().map(c->c.getServer().equals(origin.getServer())).orElse(false))return;if(!key.equals("overworld")&&!key.equals("nether")&&!key.equals("end"))return;if(active.putIfAbsent(uuid,request)!=null){player.sendMessage(Component.text("An RTP request is already active."));return;}if(!bypass&&Boolean.parseBoolean(config.getProperty("cooldown.enabled","true"))){long remaining=cooldowns.getOrDefault(uuid,0L)-System.currentTimeMillis();if(remaining>0){active.remove(uuid,request);sendMessage(player,request,"raw","&cPlease wait "+Math.max(1,(remaining+999)/1000)+" seconds before using RTP again!");return;}}
        String serverName=config.getProperty("server."+key,key);RegisteredServer destination=proxy.getServer(serverName).orElse(null);if(destination==null){active.remove(uuid,request);sendMessage(player,request,"server-unavailable","&cThe target server is currently unavailable!");return;}destination.ping().orTimeout(5,TimeUnit.SECONDS).whenComplete((ping,error)->{if(error!=null){proxy.getScheduler().buildTask(this,()->{active.remove(uuid,request);proxy.getPlayer(uuid).ifPresent(p->sendMessage(p,request,"server-unavailable","&cThe target server is currently unavailable!"));}).schedule();return;}if(player.getCurrentServer().map(c->c.getServer().equals(destination)).orElse(false)){deliver(player,request,key);return;}pending.put(uuid,new Pending(request,key));player.createConnectionRequest(destination).connect().whenComplete((result,connectError)->{if(connectError!=null||result==null||!result.isSuccessful()){pending.remove(uuid);proxy.getScheduler().buildTask(this,()->{active.remove(uuid,request);proxy.getPlayer(uuid).ifPresent(p->sendMessage(p,request,"server-unavailable","&cThe target server is currently unavailable!"));}).schedule();}});});
    }
    @Subscribe public void onServerConnected(ServerConnectedEvent event){Player player=event.getPlayer();Pending transit=pending.get(player.getUniqueId());if(transit==null)return;String expected=config.getProperty("server."+transit.destination(),transit.destination());if(!event.getServer().getServerInfo().getName().equalsIgnoreCase(expected))return;if(pending.remove(player.getUniqueId(),transit))deliver(player,transit.request(),transit.destination());}
    private void deliver(Player player,UUID request,String key){if(!active.getOrDefault(player.getUniqueId(),new UUID(0,0)).equals(request))return;send(player,"DELIVER",request.toString(),player.getUniqueId().toString(),key);}
    private void handleResult(UUID request,UUID uuid,String status){if(!active.remove(uuid,request))return;if(status.equals("SUCCESS")&&Boolean.parseBoolean(config.getProperty("cooldown.enabled","true"))){long seconds=Math.max(0,Long.parseLong(config.getProperty("cooldown.seconds","300")));if(seconds>0){cooldowns.put(uuid,System.currentTimeMillis()+seconds*1000);saveCooldowns();}}}
    @Subscribe public void onDisconnect(DisconnectEvent event){UUID id=event.getPlayer().getUniqueId();active.remove(id);pending.remove(id);}
    private void sendMessage(Player player,UUID request,String key,String text){send(player,"MESSAGE",request.toString(),player.getUniqueId().toString(),key,text);}
    private void send(Player player,String action,String... values){try{ByteArrayOutputStream bytes=new ByteArrayOutputStream();DataOutputStream output=new DataOutputStream(bytes);output.writeUTF(action);for(String value:values)output.writeUTF(value);player.sendPluginMessage(CHANNEL,bytes.toByteArray());}catch(Exception exception){player.sendMessage(AMP.deserialize("&cRTP network request failed."));logger.warn("Could not send RTP response to {}",player.getUsername(),exception);}}
}
