package de.skynetwork.moderation;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.command.Command;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerEditBookEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.inventory.AnvilInventory;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.permissions.PermissionAttachment;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.text.Normalizer;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.nio.file.Path;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;

public final class SkyModeration extends JavaPlugin implements Listener {
    private static final String NETWORK_CHANNEL="skynetwork:network";
    private final List<String> terms = new ArrayList<>();
    private final Object logLock = new Object();
    private static final PlainTextComponentSerializer PLAIN = PlainTextComponentSerializer.plainText();
    private final List<String> categories=List.of("Hacking","Exploiting","Account Scamming","Real Money Trading","Harassment","Hate Speech","Threats","Doxxing","Impersonation","Advertising","Spam","Ban Evasion","Voice Chat Abuse","Other");
    private final Map<UUID,PermissionAttachment> voiceAttachments=new ConcurrentHashMap<>();
    private Connection db;

    @Override public void onEnable() {
        saveDefaultConfig(); reloadTerms(); openDatabase(); if(db==null){getServer().getPluginManager().disablePlugin(this);return;}getServer().getMessenger().registerOutgoingPluginChannel(this,NETWORK_CHANNEL); getServer().getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTaskTimer(this,this::refreshOnlineStates,20L,20L);
        getLogger().info("SkyModeration enabled with " + terms.size() + " configured blocked term(s).");
    }

    @Override public void onDisable(){try{if(db!=null)db.close();}catch(SQLException ignored){}voiceAttachments.values().forEach(PermissionAttachment::remove);}
    private void openDatabase(){try{Path path=getDataFolder().toPath().resolve(getConfig().getString("database.file","../../../network-data/economy.db")).normalize();Files.createDirectories(path.getParent());db=DriverManager.getConnection("jdbc:sqlite:"+path.toAbsolutePath());try(var s=db.createStatement()){s.execute("PRAGMA busy_timeout=10000");s.execute("CREATE TABLE IF NOT EXISTS moderation_status(uuid TEXT PRIMARY KEY,name TEXT NOT NULL,muted_until INTEGER NOT NULL DEFAULT 0,mute_reason TEXT NOT NULL DEFAULT '',banned_until INTEGER NOT NULL DEFAULT 0,ban_reason TEXT NOT NULL DEFAULT '')");s.execute("CREATE TABLE IF NOT EXISTS moderation_cases(id INTEGER PRIMARY KEY AUTOINCREMENT,uuid TEXT NOT NULL,name TEXT NOT NULL,category TEXT NOT NULL,action TEXT NOT NULL,details TEXT NOT NULL,actor TEXT NOT NULL,created INTEGER NOT NULL)");s.execute("CREATE TABLE IF NOT EXISTS player_names(name TEXT PRIMARY KEY,uuid TEXT NOT NULL)");s.execute("CREATE TABLE IF NOT EXISTS player_wipes(owner TEXT PRIMARY KEY,created INTEGER NOT NULL)");s.execute("CREATE TABLE IF NOT EXISTS player_state(owner TEXT PRIMARY KEY,data BLOB NOT NULL,updated INTEGER NOT NULL)");}}catch(Exception e){getLogger().severe("Cannot open shared moderation database: "+e.getMessage());db=null;}}
    private UUID lookup(String name){Player online=Bukkit.getPlayerExact(name);if(online!=null)return online.getUniqueId();try{return UUID.fromString(name);}catch(IllegalArgumentException ignored){}try(PreparedStatement q=db.prepareStatement("SELECT uuid FROM player_names WHERE name=?")){q.setString(1,name.toLowerCase(Locale.ROOT));try(ResultSet r=q.executeQuery()){if(r.next())return UUID.fromString(r.getString(1));}}catch(SQLException e){getLogger().warning(e.getMessage());}return null;}
    private boolean active(UUID id,String field){try(PreparedStatement q=db.prepareStatement("SELECT "+field+" FROM moderation_status WHERE uuid=?")){q.setString(1,id.toString());try(ResultSet r=q.executeQuery()){if(!r.next())return false;long expiry=r.getLong(1);return expiry==Long.MAX_VALUE||expiry>System.currentTimeMillis();}}catch(SQLException e){return false;}}
    private String reason(UUID id,String field){try(PreparedStatement q=db.prepareStatement("SELECT "+field+" FROM moderation_status WHERE uuid=?")){q.setString(1,id.toString());try(ResultSet r=q.executeQuery()){return r.next()?r.getString(1):"Network rules";}}catch(SQLException e){return "Network rules";}}
    private long duration(String value){if(value.equalsIgnoreCase("perm")||value.equalsIgnoreCase("permanent"))return Long.MAX_VALUE;var m=Pattern.compile("(?i)(\\d+)([smhdw])").matcher(value);if(!m.matches())return -1;long amount=Long.parseLong(m.group(1));long factor=switch(m.group(2).toLowerCase(Locale.ROOT)){case "s"->1000L;case "m"->60_000L;case "h"->3_600_000L;case "d"->86_400_000L;default->604_800_000L;};try{return Math.addExact(System.currentTimeMillis(),Math.multiplyExact(amount,factor));}catch(ArithmeticException ex){return -1;}}
    private boolean updateStatus(UUID id,String name,String column,long expires,String reason){if(!column.equals("muted")&&!column.equals("banned"))return false;String until=column+"_until",why=column.equals("muted")?"mute_reason":"ban_reason";try(PreparedStatement q=db.prepareStatement("INSERT INTO moderation_status(uuid,name,"+until+","+why+") VALUES(?,?,?,?) ON CONFLICT(uuid) DO UPDATE SET name=excluded.name,"+until+"=excluded."+until+","+why+"=excluded."+why)){q.setString(1,id.toString());q.setString(2,name);q.setLong(3,expires);q.setString(4,reason);q.executeUpdate();return true;}catch(SQLException e){getLogger().warning(e.getMessage());return false;}}
    private void record(UUID id,String name,String category,String action,String details,CommandSender actor){try(PreparedStatement q=db.prepareStatement("INSERT INTO moderation_cases(uuid,name,category,action,details,actor,created) VALUES(?,?,?,?,?,?,?)")){q.setString(1,id.toString());q.setString(2,name);q.setString(3,category);q.setString(4,action);q.setString(5,details);q.setString(6,actor.getName());q.setLong(7,System.currentTimeMillis());q.executeUpdate();}catch(SQLException e){getLogger().warning(e.getMessage());}}
    private void refreshOnlineStates(){for(Player p:Bukkit.getOnlinePlayers()){boolean muted=active(p.getUniqueId(),"muted_until");PermissionAttachment attachment=voiceAttachments.get(p.getUniqueId());if(muted&&attachment==null){attachment=p.addAttachment(this);attachment.setPermission("voicechat.speak",false);voiceAttachments.put(p.getUniqueId(),attachment);}else if(!muted&&attachment!=null){attachment.remove();voiceAttachments.remove(p.getUniqueId());}if(active(p.getUniqueId(),"banned_until"))sendBanDisconnect(p);}}

    private String banScreenText(UUID id){long expiry=Long.MAX_VALUE;try(PreparedStatement q=db.prepareStatement("SELECT banned_until FROM moderation_status WHERE uuid=?")){q.setString(1,id.toString());try(ResultSet r=q.executeQuery()){if(r.next())expiry=r.getLong(1);}}catch(SQLException ignored){}String remaining=expiry==Long.MAX_VALUE?"Permanent":formatRemaining(Math.max(0,expiry-System.currentTimeMillis()));String link=getConfig().getString("discord-link","https://discord.gg/CHANGE-ME");return "&cYou Have Been Banned\n&7Reason: &e"+reason(id,"ban_reason")+"\n&7Time Left: &e"+remaining+"\n&7You are able to to make a Unban Application \n&e"+link;}
    private Component banScreen(UUID id){String link=getConfig().getString("discord-link","https://discord.gg/CHANGE-ME");return net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacyAmpersand().deserialize(banScreenText(id)).clickEvent(net.kyori.adventure.text.event.ClickEvent.openUrl(link));}
    private void sendBanDisconnect(Player target){try{ByteArrayOutputStream bytes=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(bytes);out.writeUTF("BAN_DISCONNECT");out.writeUTF(target.getUniqueId().toString());out.writeUTF(banScreenText(target.getUniqueId()));target.sendPluginMessage(this,NETWORK_CHANNEL,bytes.toByteArray());}catch(Exception ex){getLogger().warning("Could not send ban screen through proxy: "+ex.getMessage());}Bukkit.getScheduler().runTaskLater(this,()->{if(target.isOnline())target.kick(banScreen(target.getUniqueId()));},2L);}
    private String formatRemaining(long ms){long sec=Math.max(0,ms/1000);long d=sec/86400;sec%=86400;long h=sec/3600;sec%=3600;long m=sec/60;sec%=60;return (d>0?d+"d ":"")+(h>0?h+"h ":"")+(m>0?m+"m ":"")+sec+"s";}
    private boolean wipe(UUID id){try(PreparedStatement q=db.prepareStatement("INSERT INTO player_wipes(owner,created) VALUES(?,?) ON CONFLICT(owner) DO UPDATE SET created=excluded.created")){q.setString(1,id.toString());q.setLong(2,System.currentTimeMillis());q.executeUpdate();try(PreparedStatement d=db.prepareStatement("DELETE FROM player_state WHERE owner=?")){d.setString(1,id.toString());d.executeUpdate();}return true;}catch(SQLException e){getLogger().warning(e.getMessage());return false;}}    private void reloadTerms() {
        terms.clear();
        for (String term : getConfig().getStringList("blocked-terms")) {
            String normalized = normalize(term);
            if (!normalized.isBlank()) terms.add(normalized);
        }
    }

    private String normalize(String input) {
        String s = Normalizer.normalize(input, Normalizer.Form.NFKD).toLowerCase(Locale.ROOT)
                .replaceAll("§[0-9a-fk-orx]", "").replaceAll("&[0-9a-fk-orx]", "")
                .replace('0','o').replace('1','i').replace('3','e').replace('4','a').replace('5','s').replace('7','t');
        return s.replaceAll("\\p{M}+", "").replaceAll("[^\\p{L}\\p{N}]+", " ").trim().replaceAll("\\s+", " ");
    }

    private boolean containsBlocked(String input) {
        String normalized = normalize(input);
        if (normalized.isBlank()) return false;
        String[] words = normalized.split(" ");
        for (String term : terms) {
            if (Pattern.compile("(?<![\\p{L}\\p{N}])" + Pattern.quote(term) + "(?![\\p{L}\\p{N}])").matcher(normalized).find()) return true;
            String compactTerm = term.replace(" ", "");
            for (String word : words) if (word.replaceAll("[^\\p{L}\\p{N}]", "").equals(compactTerm)) return true;
        }
        return false;
    }

    private boolean block(Player player, String channel, String text) {
        if(active(player.getUniqueId(),"muted_until")){player.sendMessage(Component.text("You are muted and cannot use "+channel+"."));return true;}
        if (player.hasPermission("skynetwork.moderation.bypass") || !containsBlocked(text)) return false;
        log(player, channel, text);
        player.sendMessage(Component.text("That message was blocked by the network filter."));
        return true;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void chat(AsyncChatEvent event) {
        String text = PLAIN.serialize(event.message());
        if (block(event.getPlayer(), "chat", text)) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void sign(SignChangeEvent event) {
        String text = event.lines().stream().map(PLAIN::serialize).reduce((a,b)->a+" | "+b).orElse("");
        if (block(event.getPlayer(), "sign", text)) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void book(PlayerEditBookEvent event) {
        BookMeta book = event.getNewBookMeta();
        String text = (book.hasTitle() ? book.getTitle() + " " : "") + String.join(" ", book.getPages());
        if (block(event.getPlayer(), "book", text)) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void anvilPrepare(PrepareAnvilEvent event) {
        if (!(event.getView().getPlayer() instanceof Player player)) return;
        AnvilInventory anvil = event.getInventory(); String name = anvil.getRenameText();
        if (name != null && block(player, "anvil", name)) event.setResult(null);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void anvilClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player) || !(event.getInventory() instanceof AnvilInventory anvil)) return;
        String name = anvil.getRenameText();
        if (name != null && event.getRawSlot() == 2 && block(player, "anvil", name)) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void writtenCommands(PlayerCommandPreprocessEvent event) {
        String raw = event.getMessage();
        if(active(event.getPlayer().getUniqueId(),"muted_until")){String root=raw.substring(1).split(" ",2)[0].toLowerCase(Locale.ROOT);if(!List.of("help","home","rtp","whereami","balance","bal","unmute").contains(root)){event.setCancelled(true);event.getPlayer().sendMessage(Component.text("You are muted and cannot use communication commands."));return;}}
        if (block(event.getPlayer(), "command", raw)) event.setCancelled(true);
    }

    @EventHandler public void join(PlayerJoinEvent e){if(active(e.getPlayer().getUniqueId(),"banned_until")){sendBanDisconnect(e.getPlayer());return;}try(PreparedStatement q=db.prepareStatement("INSERT INTO player_names(name,uuid) VALUES(?,?) ON CONFLICT(name) DO UPDATE SET uuid=excluded.uuid")){q.setString(1,e.getPlayer().getName().toLowerCase(Locale.ROOT));q.setString(2,e.getPlayer().getUniqueId().toString());q.executeUpdate();}catch(SQLException ex){getLogger().warning(ex.getMessage());}}
    @EventHandler public void quit(PlayerQuitEvent e){PermissionAttachment a=voiceAttachments.remove(e.getPlayer().getUniqueId());if(a!=null)a.remove();}

    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] args){String cmd=command.getName().toLowerCase(Locale.ROOT);if(!List.of("mute","unmute","ban","unban","offend","punish","wipe").contains(cmd))return false;String permission=cmd.equals("mute")||cmd.equals("unmute")?"skynetwork.moderation.mute":cmd.equals("ban")||cmd.equals("unban")?"skynetwork.moderation.ban":cmd.equals("wipe")?"skynetwork.moderation.wipe":"skynetwork.moderation.punish";if(!sender.hasPermission(permission)){sender.sendMessage("§cYou don't have permission.");return true;}if((cmd.equals("unmute")||cmd.equals("unban"))&&args.length>=1){UUID id=lookup(args[0]);if(id==null){sender.sendMessage("§cPlayer not found in network history.");return true;}updateStatus(id,args[0],cmd.equals("unmute")?"muted":"banned",0,"" );record(id,args[0],"Other",cmd,"",sender);sender.sendMessage("§aUpdated network status for "+args[0]+".");return true;}
        if(cmd.equals("mute")||cmd.equals("ban")){if(args.length<3){sender.sendMessage("§7Usage: /"+cmd+" <player> <duration|perm> <reason>");return true;}UUID id=lookup(args[0]);long expires=duration(args[1]);if(id==null||expires<0){sender.sendMessage("§cUnknown player or duration. Use 30m, 2h, 7d, 1w or perm.");return true;}String reason=String.join(" ",java.util.Arrays.copyOfRange(args,2,args.length));String type=cmd.equals("mute")?"muted":"banned";updateStatus(id,args[0],type,expires,reason);record(id,args[0],"Other",cmd,reason,sender);Player target=Bukkit.getPlayer(id);if(target!=null&&cmd.equals("ban"))sendBanDisconnect(target);sender.sendMessage("§a"+cmd+" applied to "+args[0]+".");return true;}
        if(cmd.equals("offend")){if(args.length<3){sender.sendMessage("§7Usage: /offend <player> <category> <details>");return true;}UUID id=lookup(args[0]);if(id==null||!categories.stream().anyMatch(c->c.equalsIgnoreCase(args[1]))){sender.sendMessage("§cPlayer or category not found.");return true;}String details=String.join(" ",java.util.Arrays.copyOfRange(args,2,args.length));record(id,args[0],args[1],"report",details,sender);sender.sendMessage("§aCase recorded for "+args[0]+".");return true;}
        if(cmd.equals("wipe")){if(args.length<1){sender.sendMessage("§7Usage: /wipe <player> [reason]");return true;}UUID id=lookup(args[0]);if(id==null){sender.sendMessage("§cPlayer not found.");return true;}String reason=args.length>1?String.join(" ",java.util.Arrays.copyOfRange(args,1,args.length)):"Wipe";wipe(id);record(id,args[0],"Other","wipe",reason,sender);Player target=Bukkit.getPlayer(id);if(target!=null){target.getInventory().clear();target.getInventory().setArmorContents(null);target.getEnderChest().clear();target.setLevel(0);target.setExp(0);target.setTotalExperience(0);}sender.sendMessage("§aWiped network data for "+args[0]+".");return true;}
        if(cmd.equals("punish")){if(args.length<4){sender.sendMessage("§7Usage: /punish <player> <category> <mute|ban|wipe> [duration] <reason>");return true;}UUID id=lookup(args[0]);if(id==null||!categories.stream().anyMatch(c->c.equalsIgnoreCase(args[1]))){sender.sendMessage("§cPlayer or category not found.");return true;}String action=args[2].toLowerCase(Locale.ROOT);if(!List.of("mute","ban","wipe").contains(action)){sender.sendMessage("§cChoose mute, ban or wipe.");return true;}int reasonStart=action.equals("wipe")?3:4;if(args.length<=reasonStart){sender.sendMessage("§7Usage: /punish <player> <category> <mute|ban> <duration|perm> <reason>; for wipe omit duration.");return true;}long expires=action.equals("wipe")?Long.MAX_VALUE:duration(args[3]);if(expires<0){sender.sendMessage("§cUse a valid duration such as 30m, 2h, 7d or perm.");return true;}String reason=String.join(" ",java.util.Arrays.copyOfRange(args,reasonStart,args.length));if(action.equals("wipe")){wipe(id);Player target=Bukkit.getPlayer(id);if(target!=null){target.getInventory().clear();target.getInventory().setArmorContents(null);target.getEnderChest().clear();target.setLevel(0);target.setExp(0);target.setTotalExperience(0);}}else{String type=action.equals("mute")?"muted":"banned";updateStatus(id,args[0],type,expires,reason);Player target=Bukkit.getPlayer(id);if(target!=null&&action.equals("ban"))sendBanDisconnect(target);}record(id,args[0],args[1],action,reason,sender);sender.sendMessage("§aPunishment applied to "+args[0]+" for "+args[1]+".");return true;}return true;}

    private List<String> knownNames(String prefix){List<String> names=new ArrayList<>();String like=prefix.toLowerCase(Locale.ROOT)+"%";try(PreparedStatement q=db.prepareStatement("SELECT name FROM player_names WHERE name LIKE ? ORDER BY name LIMIT 100")){q.setString(1,like);try(ResultSet r=q.executeQuery()){while(r.next())names.add(r.getString(1));}}catch(SQLException e){getLogger().warning(e.getMessage());}for(Player p:Bukkit.getOnlinePlayers())if(p.getName().toLowerCase(Locale.ROOT).startsWith(prefix.toLowerCase(Locale.ROOT))&&!names.contains(p.getName()))names.add(p.getName());return names;}
    @Override public List<String> onTabComplete(CommandSender sender,Command command,String alias,String[] args){String cmd=command.getName().toLowerCase(Locale.ROOT);if(List.of("offend","punish").contains(cmd)&&args.length==2)return categories.stream().filter(x->x.toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))).toList();if(cmd.equals("punish")&&args.length==3)return List.of("mute","ban","wipe");if((cmd.equals("mute")||cmd.equals("ban"))&&args.length==2)return List.of("30m","2h","1d","7d","perm");if(args.length==1)return knownNames(args[0]);return List.of();}

    private void log(CommandSender sender, String channel, String text) {
        String safe = text.replace('\n',' ').replace('\r',' ');
        String line = Instant.now() + "\t" + sender.getName() + "\t" + channel + "\t" + safe + System.lineSeparator();
        synchronized (logLock) {
            try { Files.writeString(getDataFolder().toPath().resolve("blocked-input.log"), line, StandardOpenOption.CREATE, StandardOpenOption.APPEND); }
            catch (IOException ex) { getLogger().severe("Cannot write blocked-input.log: " + ex.getMessage()); }
        }
        String notice = "[SkyModeration] " + sender.getName() + " was blocked in " + channel + ".";
        Bukkit.getScheduler().runTask(this, () -> Bukkit.getOnlinePlayers().stream()
                .filter(p -> p.hasPermission(getConfig().getString("staff-permission", "skynetwork.moderation.notify")))
                .forEach(p -> p.sendMessage(Component.text(notice))));
        getLogger().info("Blocked " + channel + " input from " + sender.getName() + ".");
    }
}
