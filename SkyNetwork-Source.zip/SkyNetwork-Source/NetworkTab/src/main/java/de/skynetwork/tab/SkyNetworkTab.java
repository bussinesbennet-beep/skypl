package de.skynetwork.tab;

import com.google.inject.Inject;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.connection.DisconnectEvent;
import com.velocitypowered.api.event.connection.LoginEvent;
import com.velocitypowered.api.event.connection.PluginMessageEvent;
import com.velocitypowered.api.event.player.ServerConnectedEvent;
import com.velocitypowered.api.event.player.TabCompleteEvent;
import com.velocitypowered.api.plugin.Plugin;
import com.velocitypowered.api.plugin.annotation.DataDirectory;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.proxy.ServerConnection;
import com.velocitypowered.api.proxy.messages.MinecraftChannelIdentifier;
import com.velocitypowered.api.proxy.player.TabListEntry;
import com.velocitypowered.api.proxy.server.RegisteredServer;
import org.slf4j.Logger;

import java.util.UUID;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.Map;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.ConcurrentHashMap;
import net.kyori.adventure.text.event.ClickEvent;

record Request(UUID sender, String senderName, UUID target, String mode, long expiresAt) {}
record Pending(UUID player, String server, String action, String[] args) {}

@Plugin(id = "skynetworktab", name = "SkyNetworkTab", version = "1.0.0")
public final class SkyNetworkTab {
    private final ProxyServer proxy;
    private final Logger logger;
    private static final MinecraftChannelIdentifier CHANNEL = MinecraftChannelIdentifier.from("skynetwork:network");
    private final Map<UUID, Request> requests = new ConcurrentHashMap<>();
    private final Map<UUID, Pending> pending = new ConcurrentHashMap<>();
    private final Map<UUID, UUID> lastMessage = new ConcurrentHashMap<>();
    private final Map<UUID,net.kyori.adventure.text.Component> displayNames=new ConcurrentHashMap<>();
    private volatile List<String> tabOrder=List.of("owner","admin","moderator","helper","builder","vip","default");
    private record PlayerSettings(boolean chat,boolean privateMessages,boolean teleportAlerts,boolean tpaRequests,boolean tpaHereRequests,boolean payAlerts,boolean serverChat,boolean hotbar,boolean sounds,boolean confirmMenus){}
    private final Map<UUID,PlayerSettings> playerSettings=new ConcurrentHashMap<>();

    @Inject
    public SkyNetworkTab(ProxyServer proxy, Logger logger, @DataDirectory Path dataDirectory) {
        this.proxy = proxy;
        this.logger = logger;
        loadTabOrder(dataDirectory);
        proxy.getChannelRegistrar().register(CHANNEL);
    }

    @Subscribe
    public void onLogin(LoginEvent event) {
        // Wait until Velocity has added the joining player to its proxy player set.
        proxy.getScheduler().buildTask(this, this::synchronizeAll).schedule();
    }

    @Subscribe
    public void onServerConnected(ServerConnectedEvent event) {
        Pending p = pending.remove(event.getPlayer().getUniqueId());
        if (p != null && event.getServer().getServerInfo().getName().equalsIgnoreCase(p.server())) sendBackend(event.getPlayer(), p.action(), p.player().toString(), p.args());
        proxy.getScheduler().buildTask(this, this::synchronizeAll).schedule();
    }

    @Subscribe
    public void onTabComplete(TabCompleteEvent event){String partial=event.getPartialMessage();String lower=partial.toLowerCase(java.util.Locale.ROOT);if(!(lower.startsWith("/tpa ")||lower.startsWith("/tp ")||lower.startsWith("/tpahere ")||lower.startsWith("/tphere ")))return;String[] pieces=partial.split(" ",2);String prefix=pieces.length>1?pieces[1].toLowerCase(java.util.Locale.ROOT):"";for(Player online:proxy.getAllPlayers())if(online.getUsername().toLowerCase(java.util.Locale.ROOT).startsWith(prefix)&&!event.getSuggestions().contains(online.getUsername()))event.getSuggestions().add(online.getUsername());}

    @Subscribe
    public void onDisconnect(DisconnectEvent event) {
        UUID gone = event.getPlayer().getUniqueId();
        requests.remove(gone);
        requests.values().removeIf(r -> r.sender().equals(gone));
        pending.remove(gone);
        displayNames.remove(gone);playerSettings.remove(gone);lastMessage.remove(gone);
        for (Player viewer : proxy.getAllPlayers()) {
            viewer.getTabList().removeEntry(gone);
        }
    }

    @Subscribe
    public void onPluginMessage(PluginMessageEvent event) {
        if (!CHANNEL.equals(event.getIdentifier())) return;
        event.setResult(PluginMessageEvent.ForwardResult.handled());
        if (!(event.getSource() instanceof ServerConnection origin)) return;
        try (DataInputStream in = new DataInputStream(new ByteArrayInputStream(event.getData()))) {
            String action = in.readUTF();
            if(action.equals("PROFILE")){
                UUID id=UUID.fromString(in.readUTF());String prefix=in.readUTF(),name=in.readUTF(),suffix=in.readUTF();
                var serializer=net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacyAmpersand();var display=serializer.deserialize(prefix).append(coloredName(id,name)).append(serializer.deserialize(suffix));displayNames.put(id,display);int order=rankOrder(prefix);for(Player viewer:proxy.getAllPlayers())viewer.getTabList().getEntry(id).ifPresent(entry->entry.setDisplayName(display).setListOrder(order));
            } else if(action.equals("PAY_NOTICE")){
                UUID targetId=UUID.fromString(in.readUTF()),senderId=UUID.fromString(in.readUTF());String sender=in.readUTF(),amount=in.readUTF();proxy.getPlayer(targetId).ifPresent(target->{PlayerSettings settings=playerSettings.getOrDefault(targetId,defaults());if(!settings.payAlerts())return;var serializer=net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacyAmpersand();var notice=serializer.deserialize("&7You received &a"+amount+" &7from ").append(coloredName(senderId,sender)).append(serializer.deserialize("&7."));if(settings.serverChat())target.sendMessage(notice);if(settings.hotbar())target.sendActionBar(notice);if(settings.sounds())playNotification(target);});
            } else if(action.equals("BAN_DISCONNECT")){
                UUID targetId=UUID.fromString(in.readUTF());String screen=in.readUTF();proxy.getPlayer(targetId).ifPresent(target->target.disconnect(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacyAmpersand().deserialize(screen)));
            } else if(action.equals("PLAYER_SETTINGS")){
                UUID id=UUID.fromString(in.readUTF());playerSettings.put(id,new PlayerSettings(Boolean.parseBoolean(in.readUTF()),Boolean.parseBoolean(in.readUTF()),Boolean.parseBoolean(in.readUTF()),Boolean.parseBoolean(in.readUTF()),Boolean.parseBoolean(in.readUTF()),Boolean.parseBoolean(in.readUTF()),Boolean.parseBoolean(in.readUTF()),Boolean.parseBoolean(in.readUTF()),Boolean.parseBoolean(in.readUTF()),Boolean.parseBoolean(in.readUTF())));
            } else if (action.equals("REQUEST")) {
                UUID senderId = UUID.fromString(in.readUTF()); String senderName = in.readUTF();
                String targetName = in.readUTF(); String mode = in.readUTF();
                Player sender = proxy.getPlayer(senderId).orElse(null);
                Player target = proxy.getPlayer(targetName).orElse(null);
                if (sender == null || target == null) { if(sender!=null)sender.sendMessage(net.kyori.adventure.text.Component.text("That player is not online.")); return; }
                if(sender.getUniqueId().equals(target.getUniqueId())){sender.sendMessage(net.kyori.adventure.text.Component.text("You cannot send a teleport request to yourself."));return;}
                PlayerSettings targetSettings=playerSettings.getOrDefault(target.getUniqueId(),defaults());if(mode.equals("HERE")?!targetSettings.tpaHereRequests():!targetSettings.tpaRequests()){sender.sendMessage(net.kyori.adventure.text.Component.text("That player is not accepting this type of teleport request."));return;}
                requests.put(target.getUniqueId(), new Request(senderId,senderName,target.getUniqueId(),mode,System.currentTimeMillis()+60_000));
                var serializer=net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacyAmpersand();
                var message=coloredName(senderId,senderName).append(serializer.deserialize(mode.equals("HERE")?" &7sent you a teleport here request. &fType &7/tpaccept &for Click on This Message to Accept.":" &7sent you a teleport Request. &fType &7/tpaccept &for Click on This Message to Accept."))
                        .clickEvent(ClickEvent.runCommand("/tpaccept "+senderName));
                if(targetSettings.teleportAlerts()&&targetSettings.serverChat())target.sendMessage(message);
                if(targetSettings.teleportAlerts()&&targetSettings.hotbar())target.sendActionBar(message);
                if(targetSettings.teleportAlerts()&&targetSettings.sounds())playNotification(target);
                if(targetSettings.confirmMenus())sendBackend(target,"TPA_GUI",target.getUniqueId().toString(),senderName,mode);
                var sent=serializer.deserialize("&7You sent a Teleport request to ").append(coloredName(target.getUniqueId(),target.getUsername()));sender.sendMessage(sent);PlayerSettings senderSettings=playerSettings.getOrDefault(sender.getUniqueId(),defaults());if(senderSettings.hotbar())sender.sendActionBar(sent);if(senderSettings.sounds())playNotification(sender);
            } else if (action.equals("GLOBAL_CHAT")) {
                UUID senderId=UUID.fromString(in.readUTF());String prefix=in.readUTF(),senderName=in.readUTF(),suffix=in.readUTF(),message=in.readUTF();
                var serializer=net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacyAmpersand();var component=serializer.deserialize(prefix).append(coloredName(senderId,senderName)).append(serializer.deserialize(suffix+"&7: &f"+message));
                for(Player online:proxy.getAllPlayers())if(playerSettings.getOrDefault(online.getUniqueId(),defaults()).chat())online.sendMessage(component);
            } else if (action.equals("MSG")) {
                UUID senderId=UUID.fromString(in.readUTF());String targetName=in.readUTF();String message=in.readUTF();
                Player sender=proxy.getPlayer(senderId).orElse(null);Player target=proxy.getPlayer(targetName).orElse(null);
                if(sender==null)return;if(target==null){sender.sendMessage(net.kyori.adventure.text.Component.text("That player is not online."));return;}if(!playerSettings.getOrDefault(target.getUniqueId(),defaults()).privateMessages()){sender.sendMessage(net.kyori.adventure.text.Component.text("That player is not accepting private messages."));return;}
                lastMessage.put(sender.getUniqueId(),target.getUniqueId());lastMessage.put(target.getUniqueId(),sender.getUniqueId());
                var sent=net.kyori.adventure.text.Component.text("[You -> ").append(coloredName(target.getUniqueId(),target.getUsername())).append(net.kyori.adventure.text.Component.text("] "+message));var received=net.kyori.adventure.text.Component.text("[").append(coloredName(sender.getUniqueId(),sender.getUsername())).append(net.kyori.adventure.text.Component.text(" -> You] "+message));sender.sendMessage(sent);target.sendMessage(received);PlayerSettings targetSettings=playerSettings.getOrDefault(target.getUniqueId(),defaults());if(targetSettings.hotbar())target.sendActionBar(received);if(targetSettings.sounds())playNotification(target);
            } else if (action.equals("REPLY")) {
                UUID senderId=UUID.fromString(in.readUTF());String message=in.readUTF();Player sender=proxy.getPlayer(senderId).orElse(null);if(sender==null)return;
                UUID targetId=lastMessage.get(senderId);Player target=targetId==null?null:proxy.getPlayer(targetId).orElse(null);
                if(target==null){sender.sendMessage(net.kyori.adventure.text.Component.text("You have no player to reply to."));return;}
                lastMessage.put(target.getUniqueId(),sender.getUniqueId());var sent=net.kyori.adventure.text.Component.text("[You -> ").append(coloredName(target.getUniqueId(),target.getUsername())).append(net.kyori.adventure.text.Component.text("] "+message));var received=net.kyori.adventure.text.Component.text("[").append(coloredName(sender.getUniqueId(),sender.getUsername())).append(net.kyori.adventure.text.Component.text(" -> You] "+message));sender.sendMessage(sent);target.sendMessage(received);PlayerSettings targetSettings=playerSettings.getOrDefault(target.getUniqueId(),defaults());if(targetSettings.hotbar())target.sendActionBar(received);if(targetSettings.sounds())playNotification(target);
            } else if (action.equals("HOME_STATUS_REQUEST")) {
                UUID playerId=UUID.fromString(in.readUTF());List<String> names=java.util.List.of("lobby","overworld","nether","end");Map<String,Boolean> states=new ConcurrentHashMap<>();java.util.List<java.util.concurrent.CompletableFuture<?>> checks=new java.util.ArrayList<>();
                for(String name:names){var server=proxy.getServer(name);if(server.isEmpty()){states.put(name,false);continue;}checks.add(server.get().ping().handle((ping,error)->{states.put(name,error==null);return null;}));}
                java.util.concurrent.CompletableFuture.allOf(checks.toArray(java.util.concurrent.CompletableFuture[]::new)).whenComplete((v,error)->proxy.getScheduler().buildTask(this,()->{Player player=proxy.getPlayer(playerId).orElse(null);if(player==null)return;String payload=names.stream().map(n->n+"="+states.getOrDefault(n,false)).collect(java.util.stream.Collectors.joining(","));sendBackend(player,"HOME_STATUS",playerId.toString(),payload);}).schedule());
            } else if (action.equals("DECLINE")) {
                UUID targetId=UUID.fromString(in.readUTF());String senderName=in.readUTF();Request r=requests.get(targetId);Player target=proxy.getPlayer(targetId).orElse(null);
                if(r!=null&&r.senderName().equalsIgnoreCase(senderName)){requests.remove(targetId);Player requester=proxy.getPlayer(r.sender()).orElse(null);if(requester!=null)requester.sendMessage(net.kyori.adventure.text.Component.text("Your teleport request was declined."));if(target!=null)target.sendMessage(net.kyori.adventure.text.Component.text("Teleport request declined."));}
            } else if (action.equals("ACCEPT")) {
                UUID targetId=UUID.fromString(in.readUTF());String senderName=in.readUTF();
                Request r=requests.get(targetId);Player target=proxy.getPlayer(targetId).orElse(null);
                if(r==null||target==null||r.expiresAt()<System.currentTimeMillis()){if(target!=null)target.sendMessage(net.kyori.adventure.text.Component.text("No active teleport request."));return;}
                if(!senderName.isBlank()&&!r.senderName().equalsIgnoreCase(senderName)){target.sendMessage(net.kyori.adventure.text.Component.text("That request is no longer available."));return;}
                Player requester=proxy.getPlayer(r.sender()).orElse(null);if(requester==null){target.sendMessage(net.kyori.adventure.text.Component.text("The requester is no longer online."));requests.remove(targetId);return;}
                requests.remove(targetId);
                Player mover=r.mode().equals("HERE")?target:requester;Player anchor=r.mode().equals("HERE")?requester:target;
                String moveAction=r.mode().equals("HERE")?"MOVE_HERE":"MOVE_TO";
                beginTeleportCountdown(mover.getUniqueId(),anchor.getUniqueId(),moveAction);
                target.sendMessage(net.kyori.adventure.text.Component.text("Teleport request accepted."));
            } else if (action.equals("CONNECT_RTP")) {
                UUID id=UUID.fromString(in.readUTF());String server=in.readUTF();connectAndSend(id,server,"RTP");
            } else if (action.equals("CONNECT_HOME")) {
                UUID id=UUID.fromString(in.readUTF());String server=in.readUTF();String world=in.readUTF();
                String[] args={world,in.readUTF(),in.readUTF(),in.readUTF(),in.readUTF(),in.readUTF()};
                connectAndSend(id,server,"HOME",args);
            } else if(action.equals("CONNECT_PORTAL")){
                UUID id=UUID.fromString(in.readUTF());String server=in.readUTF();String world=in.readUTF();String[] args={world,in.readUTF(),in.readUTF(),in.readUTF(),in.readUTF(),in.readUTF()};connectAndSend(id,server,"PORTAL",args);
            } else if(action.equals("RESPAWN_LOBBY")){
                UUID id=UUID.fromString(in.readUTF());connectAndSend(id,"lobby","LOBBY_RESPAWN");
            }
        } catch (Exception ex) { logger.warn("Rejected malformed network message from {}: {}", origin.getServer().getServerInfo().getName(), ex.getMessage()); }
    }

    private void connectAndSend(UUID id,String server,String action,String...args){
        Player player=proxy.getPlayer(id).orElse(null);RegisteredServer destination=proxy.getServer(server).orElse(null);
        if(player==null)return;if(destination==null){sendOffline(player,server);return;}
        if(player.getCurrentServer().map(c->c.getServer().equals(destination)).orElse(false)){sendBackend(player,action,id.toString(),args);return;}
        pending.put(id,new Pending(id,server,action,args));player.createConnectionRequest(destination).connect().whenComplete((result,error)->{if(error!=null||result==null||!result.isSuccessful()){pending.remove(id);proxy.getScheduler().buildTask(this,()->proxy.getPlayer(id).ifPresent(p->sendOffline(p,server))).schedule();}});
    }
    private void sendOffline(Player player,String server){String world=switch(server.toLowerCase(java.util.Locale.ROOT)){case "lobby","spawn"->"spawn";case "overworld"->"world";case "nether"->"nether";case "end"->"end";default->server;};player.sendMessage(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacyAmpersand().deserialize("&cThe "+world+" is currently offline"));}

    private void beginTeleportCountdown(UUID moverId,UUID anchorId,String moveAction){
        final int[] left={5};final Runnable[] step=new Runnable[1];
        step[0]=()->{Player mover=proxy.getPlayer(moverId).orElse(null);Player anchor=proxy.getPlayer(anchorId).orElse(null);if(mover==null||anchor==null)return;
            if(left[0]>0){mover.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacyAmpersand().deserialize("&7Teleporting in &a"+left[0]+"&7..."));left[0]--;proxy.getScheduler().buildTask(this,step[0]).delay(1,java.util.concurrent.TimeUnit.SECONDS).schedule();return;}
            RegisteredServer destination=anchor.getCurrentServer().map(ServerConnection::getServer).orElse(null);if(destination==null){mover.sendMessage(net.kyori.adventure.text.Component.text("The destination is unavailable."));return;}
            String[] args={anchorId.toString()};if(mover.getCurrentServer().map(c->c.getServer().equals(destination)).orElse(false))sendBackend(mover,moveAction,moverId.toString(),args);
            else{pending.put(moverId,new Pending(moverId,destination.getServerInfo().getName(),moveAction,args));mover.createConnectionRequest(destination).connect();}
        };step[0].run();
    }

    private void sendBackend(Player player,String action,String id,String...args){
        try{ByteArrayOutputStream b=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(b);out.writeUTF(action);out.writeUTF(id);for(String arg:args)out.writeUTF(arg);player.sendPluginMessage(CHANNEL,b.toByteArray());}
        catch(Exception e){logger.warn("Unable to send {} to player {}'s backend",action,player.getUsername(),e);}
    }

    private void synchronizeAll(){for(Player viewer:proxy.getAllPlayers())synchronize(viewer);}

    private PlayerSettings defaults(){return new PlayerSettings(true,true,true,true,true,true,true,true,true,true);}
    private void playNotification(Player player){player.playSound(net.kyori.adventure.sound.Sound.sound(net.kyori.adventure.key.Key.key("minecraft:block.note_block.pling"),net.kyori.adventure.sound.Sound.Source.PLAYER,0.45f,1.7f));}
    private net.kyori.adventure.text.Component coloredName(UUID id,String name){int rgb=java.awt.Color.HSBtoRGB((id.hashCode()&0xffff)/65536.0f,0.68f,1.0f)&0xffffff;return net.kyori.adventure.text.Component.text(name,net.kyori.adventure.text.format.TextColor.color(rgb));}

    private void synchronize(Player viewer) {
        if (!viewer.isActive()) return;
        int listed = 0;
        for (Player subject : proxy.getAllPlayers()) {
            if (subject.getUniqueId().equals(viewer.getUniqueId())) continue;
            if (viewer.getTabList().getEntry(subject.getUniqueId()).isPresent()) continue;
            TabListEntry entry = TabListEntry.builder()
                    .tabList(viewer.getTabList())
                    .profile(subject.getGameProfile())
                    .displayName(displayNames.getOrDefault(subject.getUniqueId(),net.kyori.adventure.text.Component.text(subject.getUsername())))
                    .listOrder(rankOrderFromDisplay(subject.getUniqueId()))
                    .latency(subject.getPing() > Integer.MAX_VALUE ? Integer.MAX_VALUE : (int) subject.getPing())
                    .gameMode(0)
                    .listed(true)
                    .build();
            viewer.getTabList().addEntry(entry);
            listed++;
        }
        if (listed > 0) logger.debug("Added {} network player(s) to {}'s tab list", listed, viewer.getUsername());
    }

    private int rankOrderFromDisplay(UUID id){return rankOrder(net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText().serialize(displayNames.getOrDefault(id,net.kyori.adventure.text.Component.empty())));}
    private void loadTabOrder(Path directory){try{Files.createDirectories(directory);Path file=directory.resolve("config.yml");if(!Files.exists(file))Files.writeString(file,"# LuckPerms rank prefix/name fragments, highest priority first.\ntab-order:\n  - Owner\n  - Admin\n  - Moderator\n  - Helper\n  - Builder\n  - VIP\n  - Default\n");List<String> order=new java.util.ArrayList<>();boolean section=false;for(String line:Files.readAllLines(file)){String trimmed=line.trim();if(trimmed.startsWith("tab-order:")){section=true;continue;}if(section){if(!trimmed.startsWith("-")){if(!trimmed.isEmpty()&&!trimmed.startsWith("#"))break;continue;}String value=trimmed.substring(1).trim().replace("\"","").replace("'","");if(!value.isEmpty())order.add(value.toLowerCase(java.util.Locale.ROOT));}}if(!order.isEmpty())tabOrder=List.copyOf(order);}catch(Exception e){logger.warn("Could not load tab rank order; using defaults",e);}}
    private int rankOrder(String rank){String text=rank.toLowerCase(java.util.Locale.ROOT);for(int i=0;i<tabOrder.size();i++)if(text.contains(tabOrder.get(i)))return i*100;return tabOrder.size()*100;}
}
