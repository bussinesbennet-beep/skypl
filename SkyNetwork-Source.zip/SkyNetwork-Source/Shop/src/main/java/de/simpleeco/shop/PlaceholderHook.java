package de.simpleeco.shop;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;

import java.text.DecimalFormat;

/**
 * PlaceholderAPI expansion for the Shop plugin.
 *
 * Placeholders (identifier "shop"):
 *   %shop_spent%      -> total Dollars spent in the shop, grouped number only (e.g. 1,234)
 *   %shop_spent_raw%  -> total Dollars spent, raw number
 */
public class PlaceholderHook extends PlaceholderExpansion {

    public static final String KEY_SPENT = "dollars_spent";

    private final StatStore stats;
    private final String symbol;
    private final DecimalFormat fmt = new DecimalFormat("#,##0.##");

    public PlaceholderHook(StatStore stats, String currencySymbol) {
        this.stats = stats;
        this.symbol = currencySymbol == null ? "$" : currencySymbol;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "shop";
    }

    @Override
    public @NotNull String getAuthor() {
        return "SimpleEconomy";
    }

    @Override
    public @NotNull String getVersion() {
        return "1.0.0";
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        if (player == null) {
            return "";
        }
        double spent = stats.get(player.getUniqueId(), KEY_SPENT);
        return switch (params.toLowerCase()) {
            case "spent" -> fmt.format(spent);
            case "spent_raw" -> String.valueOf(spent);
            default -> null;
        };
    }
}
