package de.simpleeco.shop.gui;

import de.simpleeco.shop.stock.ShopEntry;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

/**
 * Inventory holder carrying which screen is open and, for the picker/
 * shulker, which glass slot is being filled.
 */
public final class ShopHolder implements InventoryHolder {

    public enum View { MAIN, PICKER, SHULKER }

    private final View view;
    private final boolean allowShulker;
    /** Exact slot in the parent GUI that will be replaced. -1 = append. */
    private final int targetSlot;
    private final ShopEntry draft;
    private Inventory inventory;

    private ShopHolder(View view, boolean allowShulker, int targetSlot, ShopEntry draft) {
        this.view = view;
        this.allowShulker = allowShulker;
        this.targetSlot = targetSlot;
        this.draft = draft;
    }

    public static ShopHolder main() {
        return new ShopHolder(View.MAIN, true, -1, null);
    }

    public static ShopHolder picker(boolean allowShulker, int targetSlot, ShopEntry draft) {
        return new ShopHolder(View.PICKER, allowShulker, targetSlot, draft);
    }

    public static ShopHolder shulker(ShopEntry draft) {
        return shulker(draft, -1);
    }

    public static ShopHolder shulker(ShopEntry draft, int targetSlot) {
        return new ShopHolder(View.SHULKER, true, targetSlot, draft);
    }

    /** Backwards compat — no slot target. */
    public static ShopHolder main(int page) {
        return main();
    }

    public static ShopHolder picker(boolean allowShulker, ShopEntry draft) {
        return picker(allowShulker, -1, draft);
    }

    public View view() { return view; }
    public boolean allowShulker() { return allowShulker; }
    /** The glass slot that will be replaced (-1 if unknown/append). */
    public int targetSlot() { return targetSlot; }
    public ShopEntry draft() { return draft; }
    /** Legacy page value — always 0 now that there is only one page. */
    public int page() { return 0; }

    public void inventory(Inventory inventory) { this.inventory = inventory; }

    @NotNull
    @Override
    public Inventory getInventory() { return inventory; }
}
