package de.simpleeco.shop.mystery;

import de.simpleeco.shop.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

/**
 * The mystery box screen — three rows.
 *
 * <p>Row 2 holds the three tiers, represented by vanilla chest variants.
 */
public final class MysteryBoxGui {

    public static final int SIZE = 27;
    public static final int[] SLOTS = {11, 13, 15};

    /** Inventory holder so clicks are routed to this screen. */
    public static final class Holder implements InventoryHolder {
        private Inventory inventory;

        void inventory(Inventory inventory) {
            this.inventory = inventory;
        }

        @NotNull
        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private final MysteryBoxes boxes;
    private final de.simpleeco.shop.economy.EconomyBridge economy;

    public MysteryBoxGui(MysteryBoxes boxes, de.simpleeco.shop.economy.EconomyBridge economy) {
        this.boxes = boxes;
        this.economy = economy;
    }

    public void open(Player player) {
        Holder holder = new Holder();
        Inventory inv = Bukkit.createInventory(holder, SIZE, Text.of("&8Mystery Boxes"));
        holder.inventory(inv);

        List<MysteryBoxes.Tier> tiers = boxes.all();
        for (int i = 0; i < tiers.size() && i < SLOTS.length; i++) {
            inv.setItem(SLOTS[i], icon(tiers.get(i), player));
        }
        player.openInventory(inv);
    }

    /** The clickable box icon. */
    private ItemStack icon(MysteryBoxes.Tier tier, Player viewer) {
        ItemStack stack = new ItemStack(tier.material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.displayName(Text.of(tier.display));
            List<String> lore = new ArrayList<>();
            lore.add("&fPrice: &a" + economy.format(tier.cost));
            lore.add("&7Click to open");
            meta.lore(Text.lore(lore));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    /** Tier shown in a given slot, or null. */
    public MysteryBoxes.Tier tierAt(int slot) {
        List<MysteryBoxes.Tier> tiers = boxes.all();
        for (int i = 0; i < SLOTS.length && i < tiers.size(); i++) {
            if (SLOTS[i] == slot) {
                return tiers.get(i);
            }
        }
        return null;
    }

}
