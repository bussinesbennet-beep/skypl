package de.simpleeco.shop;

import de.simpleeco.shop.gui.ShopListener;
import de.simpleeco.shop.util.Text;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/** /shop — opens the shop, /shop add — opens the item picker (admins). */
public class ShopCommand implements CommandExecutor, TabCompleter {

    private final ShopPlugin plugin;
    private final ShopListener listener;
    private final StatStore stats;

    public ShopCommand(ShopPlugin plugin, ShopListener listener, StatStore stats) {
        this.plugin = plugin;
        this.listener = listener;
        this.stats = stats;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command can only be used by players.");
            return true;
        }

        if (args.length > 0 && args[0].equalsIgnoreCase("boxes")) {
            if (!player.hasPermission("shop.use")) {
                player.sendMessage(Text.of("&cYou are not allowed to use the shop."));
                return true;
            }
            plugin.boxGui().open(player);
            return true;
        }

        if (args.length > 0 && args[0].equalsIgnoreCase("add")) {
            listener.openPicker(player);
            return true;
        }

        if (!player.hasPermission("shop.use")) {
            player.sendMessage(Text.of("&cYou are not allowed to use the shop."));
            return true;
        }
        listener.openMain(player);
        return true;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                      @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1) {
            return List.of("add", "boxes");
        }
        return List.of();
    }
}
