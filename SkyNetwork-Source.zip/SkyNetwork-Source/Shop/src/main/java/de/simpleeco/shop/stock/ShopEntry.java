package de.simpleeco.shop.stock;

import de.simpleeco.shop.prices.PriceBook;
import org.bukkit.Material;
import org.bukkit.block.ShulkerBox;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * One shop entry — material, amount, enchants, and optional shulker contents.
 * Shulker contents are slot-indexed (27 slots), null = empty pane.
 */
public final class ShopEntry {

    private final Material material;
    private int amount;
    private final Map<Enchantment,Integer> enchants = new LinkedHashMap<>();
    private final List<ShopEntry> contents = new ArrayList<>();
    // Slot-indexed view for shulker builder (size 27). When used, 'contents' is derived.
    private final List<ShopEntry> slotContents = new ArrayList<>();

    public ShopEntry(Material material, int amount) {
        this.material = material;
        this.amount = Math.max(1, amount);
        for (int i = 0; i < 27; i++) slotContents.add(null);
    }

    public static ShopEntry of(Material m) { return new ShopEntry(m, 1); }

    public Material material() { return material; }
    public int amount() { return amount; }
    public void amount(int a) { amount = Math.max(1,a); }
    public Map<Enchantment,Integer> enchants() { return enchants; }
    /** Legacy list — non-null items only, for pricing/building. */
    public List<ShopEntry> contents() { return contents; }
    /** Slot-indexed (27) — null = empty pane. */
    public List<ShopEntry> slotContents() { return slotContents; }

    public void setSlotContent(int slot, ShopEntry entry) {
        if (slot < 0 || slot >= 27) return;
        slotContents.set(slot, entry);
        rebuildContents();
    }

    private void rebuildContents() {
        contents.clear();
        for (ShopEntry e : slotContents) if (e != null) contents.add(e);
    }

    public boolean isShulker() { return material.name().endsWith("SHULKER_BOX"); }

    public ItemStack build() {
        ItemStack stack = new ItemStack(material, Math.min(64, Math.max(1, amount)));
        if (isShulker()) {
            List<ShopEntry> kids = contents.isEmpty() ? nonNullSlots() : contents;
            if (!kids.isEmpty()) {
                ItemMeta meta = stack.getItemMeta();
                if (meta instanceof BlockStateMeta bsm && bsm.getBlockState() instanceof ShulkerBox box) {
                    for (ShopEntry child : kids) box.getInventory().addItem(child.build());
                    bsm.setBlockState(box);
                    stack.setItemMeta(bsm);
                }
            }
        }
        if (!enchants.isEmpty()) {
            ItemMeta meta = stack.getItemMeta();
            if (meta != null) {
                if (meta instanceof EnchantmentStorageMeta esm) enchants.forEach((e,lvl) -> esm.addStoredEnchant(e,lvl,true));
                else enchants.forEach((e,lvl) -> meta.addEnchant(e,lvl,true));
                stack.setItemMeta(meta);
            }
        }
        return stack;
    }

    private List<ShopEntry> nonNullSlots() {
        List<ShopEntry> out = new ArrayList<>();
        for (ShopEntry e : slotContents) if (e != null) out.add(e);
        return out;
    }

    public double price(PriceBook book) {
        double total = book.unit(material) * amount;
        for (int lvl : enchants.values()) total += book.enchantPrice() * lvl;
        for (ShopEntry c : (contents.isEmpty() ? nonNullSlots() : contents)) total += c.price(book);
        return total;
    }

    public int storedCount() {
        int n = 0;
        for (ShopEntry c : contents) n += c.amount();
        for (ShopEntry c : slotContents) if (c != null) n += c.amount();
        return n;
    }
}
