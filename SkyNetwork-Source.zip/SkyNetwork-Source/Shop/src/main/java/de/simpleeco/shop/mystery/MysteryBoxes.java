package de.simpleeco.shop.mystery;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/**
 * The three mystery box tiers and their loot tables, read from
 * {@code mystery.yml}.
 *
 * <p>Box tiers use vanilla chest variants and do not depend on custom item models.
 */
public final class MysteryBoxes {

    /** One possible outcome of opening a box. */
    public static final class Outcome {
        public final int chance;
        public final String name;
        public final String message;
        public final String command;
        public final String give;
        public final double money;

        Outcome(int chance, String name, String message, String command, String give, double money) {
            this.chance = Math.max(1, chance);
            this.name = name == null ? "" : name;
            this.message = message;
            this.command = command;
            this.give = give;
            this.money = money;
        }
    }

    /** One box tier. */
    public static final class Tier {
        public final String id;
        public final String display;
        public final double cost;
        /** Vanilla chest variant used for this tier's icon. */
        public final Material material;
        public final List<Outcome> outcomes = new ArrayList<>();

        Tier(String id, String display, double cost, Material material) {
            this.id = id;
            this.display = display;
            this.cost = cost;
            this.material = material;
        }

        public int totalWeight() {
            int sum = 0;
            for (Outcome o : outcomes) {
                sum += o.chance;
            }
            return Math.max(1, sum);
        }

        /** Rolls one outcome, weighted by chance. */
        public Outcome roll() {
            if (outcomes.isEmpty()) {
                return null;
            }
            int roll = ThreadLocalRandom.current().nextInt(totalWeight());
            for (Outcome o : outcomes) {
                roll -= o.chance;
                if (roll < 0) {
                    return o;
                }
            }
            return outcomes.get(outcomes.size() - 1);
        }
    }

    private final JavaPlugin plugin;
    private final Map<String, Tier> tiers = new LinkedHashMap<>();

    public MysteryBoxes(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        tiers.clear();

        File file = new File(plugin.getDataFolder(), "mystery.yml");
        if (!file.exists()) {
            plugin.saveResource("mystery.yml", false);
        }
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);

        ConfigurationSection root = yml.getConfigurationSection("boxes");
        if (root == null) {
            plugin.getLogger().warning("mystery.yml has no 'boxes' section - mystery boxes disabled.");
            return;
        }

        for (String id : root.getKeys(false)) {
            ConfigurationSection box = root.getConfigurationSection(id);
            if (box == null) {
                continue;
            }
            Material material = switch (id.toLowerCase()) {
                case "common" -> Material.CHEST;
                case "rare" -> Material.ENDER_CHEST;
                case "legendary" -> Material.SHULKER_BOX;
                default -> Material.CHEST;
            };

            Tier tier = new Tier(id.toLowerCase(),
                    box.getString("display", id),
                    box.getDouble("cost", 0), material);

            List<Map<?, ?>> list = box.getMapList("outcomes");
            for (Map<?, ?> raw : list) {
                int chance = raw.get("chance") instanceof Number n ? n.intValue() : 1;
                String name = raw.get("name") == null ? "" : String.valueOf(raw.get("name"));
                String message = raw.get("message") == null ? null : String.valueOf(raw.get("message"));
                String command = raw.get("command") == null ? null : String.valueOf(raw.get("command"));
                String give = raw.get("give") == null ? null : String.valueOf(raw.get("give"));
                double money = raw.get("money") instanceof Number m ? m.doubleValue() : 0;
                tier.outcomes.add(new Outcome(chance, name, message, command, give, money));
            }
            tiers.put(tier.id, tier);
        }
        plugin.getLogger().info("Mystery boxes loaded: " + tiers.size() + " tiers.");
    }

    public Tier get(String id) {
        return id == null ? null : tiers.get(id.toLowerCase());
    }

    /** All tiers in config order. */
    public List<Tier> all() {
        return new ArrayList<>(tiers.values());
    }
}
