package de.simpleeco.shop.util;

import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import io.papermc.paper.registry.data.dialog.input.DialogInput;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import de.simpleeco.economy.api.SimplePrefsAPI;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickCallback;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import io.papermc.paper.event.player.AsyncChatEvent;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.regex.Pattern;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Shared helper for native Minecraft dialogs.
 *
 * <h2>Text</h2>
 * Everything is <b>plain white</b> by default and never italic. Colour codes are
 * still fully supported: if a string contains {@code &a}, {@code &7}, {@code &#rrggbb}
 * or {@code &l} … it is parsed exactly like before, otherwise the text simply
 * renders white. That way configs and language files can add colour, but nothing
 * turns purple/italic on its own any more.
 *
 * <h2>Icons</h2>
 * Paper's {@link ActionButton} has no icon field — a button is label + tooltip +
 * width + action, nothing else. Real item pictures inside a dialog are only
 * possible through {@link #itemBody(ItemStack)}, which renders an actual
 * {@link ItemStack}. The confirmation screens use that so players literally see
 * the item they are about to buy/sell/list.
 */
public final class DialogUi {

    /** Plain white — the suite default for every label. */
    public static final TextColor WHITE = NamedTextColor.WHITE;
    /** Kept for source compatibility; the suite is white now. */
    public static final TextColor ACCENT = NamedTextColor.WHITE;
    /** Secondary/muted text. */
    public static final TextColor MUTED = NamedTextColor.GRAY;
    /** Confirm actions - white, no green colour codes. */
    public static final TextColor POSITIVE = NamedTextColor.WHITE;
    /** Cancel / destructive actions - white as well. */
    public static final TextColor NEGATIVE = NamedTextColor.WHITE;

    /** Detects legacy colour codes (&a, &7, &#rrggbb, &l …). */
    private static final Pattern CODES = Pattern.compile("(?i)&#[0-9a-f]{6}|&[0-9a-fk-orx]");

    /** Used to flatten already-built labels before they are forced white. */
    private static final PlainTextComponentSerializer PLAIN =
            PlainTextComponentSerializer.plainText();
    private static final Map<DialogAction, Click> FALLBACK_ACTIONS = Collections.synchronizedMap(new IdentityHashMap<>());
    private static final Set<JavaPlugin> FALLBACK_REGISTERED = Collections.newSetFromMap(new WeakHashMap<>());
    private static final Map<UUID, PendingInput> PENDING_INPUTS = new ConcurrentHashMap<>();
    private record PendingInput(JavaPlugin plugin, BiConsumer<Player,String> confirm, Click cancel) {}
    private static final class FallbackHolder implements InventoryHolder {
        final List<Click> actions; Inventory inventory;
        FallbackHolder(List<Click> actions){this.actions=actions;}
        @Override public Inventory getInventory(){return inventory;}
    }

    private DialogUi() {
    }

    /** Resolves a plugin by name (used for scheduling work on the main thread). */
    public static JavaPlugin self(String name) {
        try {
            return (JavaPlugin) Bukkit.getPluginManager().getPlugin(name);
        } catch (Throwable t) {
            return null;
        }
    }

    private static boolean dialogsAllowed(Player player,JavaPlugin plugin){if(player.getProtocolVersion()<771)return false;String mode=plugin==null?"auto":plugin.getConfig().getString("dialog-mode","auto").toLowerCase(java.util.Locale.ROOT);if(mode.equals("inventory"))return false;SimplePrefsAPI prefs=Bukkit.getServicesManager().load(SimplePrefsAPI.class);return prefs==null||prefs.get(player.getUniqueId(),SimplePrefsAPI.KEY_DIALOGS,true);}

    private static void registerFallback(JavaPlugin plugin){if(plugin==null)return;synchronized(FALLBACK_REGISTERED){if(!FALLBACK_REGISTERED.add(plugin))return;}plugin.getServer().getPluginManager().registerEvents(new Listener(){
        @EventHandler(priority=EventPriority.HIGHEST) public void click(InventoryClickEvent e){if(!(e.getView().getTopInventory().getHolder() instanceof FallbackHolder h))return;e.setCancelled(true);if(!(e.getWhoClicked() instanceof Player p)||e.getClickedInventory()!=e.getView().getTopInventory())return;int slot=e.getRawSlot();if(slot<0||slot>=h.actions.size())return;Click action=h.actions.get(slot);Bukkit.getScheduler().runTask(plugin,()->{p.closeInventory();if(action!=null)action.run(p);});}
        @EventHandler(priority=EventPriority.HIGHEST) public void drag(InventoryDragEvent e){if(e.getView().getTopInventory().getHolder() instanceof FallbackHolder)e.setCancelled(true);}
        @EventHandler(priority=EventPriority.HIGHEST) public void input(AsyncChatEvent e){PendingInput pending=PENDING_INPUTS.get(e.getPlayer().getUniqueId());if(pending==null||e.isCancelled())return;e.setCancelled(true);PENDING_INPUTS.remove(e.getPlayer().getUniqueId());String typed=PLAIN.serialize(e.message());Player player=e.getPlayer();Bukkit.getScheduler().runTask(pending.plugin(),()->{if(typed.equalsIgnoreCase("/cancel")){if(pending.cancel()!=null)pending.cancel().run(player);}else pending.confirm().accept(player,typed);});}
    },plugin);}

    private static void openFallback(Player player,Component title,List<DialogBody> body,List<ActionButton> buttons,JavaPlugin plugin){registerFallback(plugin);int count=Math.max(1,Math.min(54,((buttons.size()+8)/9)*9));List<Click> actions=new ArrayList<>();FallbackHolder holder=new FallbackHolder(actions);Inventory inventory=Bukkit.createInventory(holder,count,plain(title));holder.inventory=inventory;int index=0;for(ActionButton button:buttons){if(index>=count)break;ItemStack item=new ItemStack(index==buttons.size()-1?Material.REDSTONE:Material.PAPER);ItemMeta meta=item.getItemMeta();meta.displayName(Component.text(PLAIN.serialize(button.label()),WHITE).decoration(TextDecoration.ITALIC,false));if(button.tooltip()!=null)meta.lore(List.of(Component.text(PLAIN.serialize(button.tooltip()),MUTED).decoration(TextDecoration.ITALIC,false)));item.setItemMeta(meta);inventory.setItem(index,item);actions.add(FALLBACK_ACTIONS.get(button.action()));index++;}player.openInventory(inventory);}

    private static void inputFallback(JavaPlugin plugin,Player player,Component title,List<DialogBody> body,String label,BiConsumer<Player,String> confirm,Click cancel){registerFallback(plugin);PENDING_INPUTS.put(player.getUniqueId(),new PendingInput(plugin,confirm,cancel));player.sendMessage(Component.text(PLAIN.serialize(title)+" — "+label+". Type your answer in chat, or /cancel.",WHITE));}

    // ------------------------------------------------------------------- text

    /** True if the string carries its own colour codes. */
    public static boolean hasCodes(String raw) {
        return raw != null && CODES.matcher(raw).find();
    }

    /**
     * Turns any string into a component: colour codes are honoured when present,
     * otherwise the text is white and not italic.
     */
    public static Component component(String raw, TextColor fallback) {
        if (raw == null || raw.isEmpty()) {
            return Component.empty();
        }
        if (hasCodes(raw)) {
            return Text.of(raw);
        }
        return Component.text(raw, fallback == null ? WHITE : fallback)
                .decoration(TextDecoration.ITALIC, false);
    }

    /** White text component, colour codes supported. */
    public static Component component(String raw) {
        return component(raw, WHITE);
    }

    /** White dialog title. */
    public static Component title(String raw) {
        return component(raw, WHITE);
    }

    /** A label component (white unless the string contains colour codes). */
    public static Component label(String raw, TextColor color) {
        return component(raw, color);
    }

    /**
     * Legacy overload: the icon argument is ignored — buttons are plain white
     * text (no emoji, no resource pack required).
     */
    public static Component label(JavaPlugin plugin, String iconName, String raw, TextColor color) {
        return label(raw, color);
    }


    /** Removes every legacy colour code so button labels are always plain white. */
    public static String stripCodes(String raw) {
        if (raw == null) {
            return "";
        }
        return raw.replaceAll("(?i)&#[0-9a-f]{6}", "")
                .replaceAll("(?i)&[0-9a-fk-orx]", "");
    }

    // ----------------------------------------------------------------- buttons

    /** Builds a button from white text plus an optional tooltip. */
    public static ActionButton button(String text, String tooltip, int width,
                                      TextColor color, DialogAction action) {
        // Dialog buttons are always plain white - no &a / &c from configs.
        ActionButton.Builder b = ActionButton.builder(
                        Component.text(stripCodes(text), WHITE)
                                .decoration(TextDecoration.ITALIC, false))
                .width(Math.max(1, Math.min(1024, width)));
        if (tooltip != null && !tooltip.isEmpty()) {
            b.tooltip(component(tooltip, MUTED));
        }
        if (action != null) {
            b.action(action);
        }
        return b.build();
    }

    /** Builds a button from an already-built component label. */
    public static ActionButton button(Component label, String tooltip, int width,
                                      TextColor color, DialogAction action) {
        ActionButton.Builder b = ActionButton.builder(
                        Component.text(stripCodes(PLAIN.serialize(label)), WHITE)
                                .decoration(TextDecoration.ITALIC, false))
                .width(Math.max(1, Math.min(1024, width)));
        if (tooltip != null && !tooltip.isEmpty()) {
            b.tooltip(component(tooltip, MUTED));
        }
        if (action != null) {
            b.action(action);
        }
        return b.build();
    }

    /** Legacy overload with an icon name, which is ignored. */
    public static ActionButton button(JavaPlugin plugin, String iconName, String text,
                                      String tooltip, int width, TextColor color,
                                      DialogAction action) {
        return button(text, tooltip, width, color, action);
    }

    /** A click handler that only needs the player. */
    @FunctionalInterface
    public interface Click {
        void run(Player player);
    }

    /** Wraps a {@link Click} into a dialog action. */
    public static DialogAction click(Click callback) {
        DialogAction action=DialogAction.customClick((response, audience) -> {
            if (audience instanceof Player p) {
                callback.run(p);
            }
        }, options());
        FALLBACK_ACTIONS.put(action,callback);
        return action;
    }

    /** Options that keep a callback alive for a whole session. */
    public static ClickCallback.Options options() {
        return ClickCallback.Options.builder()
                .uses(ClickCallback.UNLIMITED_USES)
                .lifetime(Duration.ofHours(12))
                .build();
    }

    // ------------------------------------------------------------------ bodies

    /** A plain white body line (colour codes supported). */
    public static DialogBody text(String line, TextColor color) {
        return DialogBody.plainMessage(component(line, color), 320);
    }

    /** A plain white body line (colour codes supported). */
    public static DialogBody text(String line) {
        return DialogBody.plainMessage(component(line, WHITE), 320);
    }

    /** A muted body line, used for secondary information. */
    public static DialogBody muted(String line) {
        return DialogBody.plainMessage(component(line, MUTED), 320);
    }

    /**
     * A real item inside the dialog — the only genuine item picture the vanilla
     * API draws, and how the confirmation screens show what is at stake.
     */
    public static DialogBody itemBody(ItemStack stack) {
        if (stack == null) {
            return DialogBody.plainMessage(Component.empty(), 320);
        }
        return DialogBody.item(stack)
                .showDecorations(true)
                .showTooltip(true)
                .width(16)
                .height(16)
                .build();
    }

    // ----------------------------------------------------------------- dialogs

    /** Opens a multi-action dialog with the given buttons. */
    public static void open(Player player, Component title, List<DialogBody> body,
                            List<ActionButton> buttons, int columns) {
        List<DialogBody> safeBody = body == null ? List.of() : new ArrayList<>(body);
        List<ActionButton> safeButtons = buttons == null ? List.of() : new ArrayList<>(buttons);
        JavaPlugin plugin=self("Shop");
        if(!dialogsAllowed(player,plugin)){openFallback(player,title,safeBody,safeButtons,plugin);return;}

        DialogBase base = DialogBase.builder(plain(title))
                .canCloseWithEscape(true)
                .pause(false)
                .afterAction(DialogBase.DialogAfterAction.NONE)
                .body(safeBody)
                .build();

        try{player.showDialog(Dialog.create(factory -> factory.empty()
                .base(base)
                .type(DialogType.multiAction(safeButtons)
                        .columns(Math.max(1, columns))
                        .build())));}catch(Throwable error){openFallback(player,title,safeBody,safeButtons,plugin);}
    }

    /** Opens a yes/no confirmation dialog. */
    public static void confirm(Player player, Component title, List<DialogBody> body,
                               ActionButton yes, ActionButton no) {
        List<DialogBody> safeBody = body == null ? List.of() : new ArrayList<>(body);
        JavaPlugin plugin=self("Shop");List<ActionButton> buttons=List.of(yes,no);
        if(!dialogsAllowed(player,plugin)){openFallback(player,title,safeBody,buttons,plugin);return;}

        DialogBase base = DialogBase.builder(plain(title))
                .canCloseWithEscape(true)
                .pause(false)
                .afterAction(DialogBase.DialogAfterAction.NONE)
                .body(safeBody)
                .build();

        try{player.showDialog(Dialog.create(factory -> factory.empty()
                .base(base)
                .type(DialogType.confirmation(yes, no))));}catch(Throwable error){openFallback(player,title,safeBody,buttons,plugin);}
    }

    /**
     * A dialog with a real text field — this replaces the old sign input.
     *
     * <p>The player types into a normal input box inside the dialog (no sign is
     * placed in the world), presses the confirm button and the typed value is
     * handed to {@code onConfirm}. Cancel simply closes the screen.
     *
     * @param key      internal key of the input field
     * @param label    text shown next to the input box
     * @param initial  pre-filled value (may be empty)
     * @param maxLen   maximum number of characters
     * @param onCancel action for the cancel button, or null to just close
     */
    public static void input(JavaPlugin plugin, Player player, Component title,
                             List<DialogBody> body, String key, String label,
                             String initial, int maxLen,
                             String confirmText, String cancelText,
                             BiConsumer<Player, String> onConfirm,
                             Click onCancel) {
        List<DialogBody> safeBody = body == null ? List.of() : new ArrayList<>(body);
        if(!dialogsAllowed(player,plugin)){inputFallback(plugin,player,title,safeBody,label,onConfirm,onCancel);return;}

        DialogBase base = DialogBase.builder(plain(title))
                .canCloseWithEscape(true)
                .pause(false)
                .afterAction(DialogBase.DialogAfterAction.NONE)
                .body(safeBody)
                .inputs(List.of(DialogInput.text(key, component(label, WHITE))
                        .width(220)
                        .initial(initial == null ? "" : initial)
                        .maxLength(Math.max(1, maxLen))
                        .build()))
                .build();

        ActionButton ok = ActionButton.builder(Component.text(stripCodes(confirmText), WHITE)
                        .decoration(TextDecoration.ITALIC, false))
                .width(150)
                .action(DialogAction.customClick((response, audience) -> {
                    if (!(audience instanceof Player p)) {
                        return;
                    }
                    String value = null;
                    try {
                        value = response == null ? null : response.getText(key);
                    } catch (Throwable ignored) {
                        // no text field in the response -> treat as empty
                    }
                    final String typed = value;
                    p.closeDialog();
                    runNextTick(plugin, () -> onConfirm.accept(p, typed));
                }, options()))
                .build();

        ActionButton cancel = ActionButton.builder(Component.text(stripCodes(cancelText), WHITE)
                        .decoration(TextDecoration.ITALIC, false))
                .width(150)
                .action(DialogAction.customClick((response, audience) -> {
                    if (!(audience instanceof Player p)) {
                        return;
                    }
                    p.closeDialog();
                    if (onCancel != null) {
                        runNextTick(plugin, () -> onCancel.run(p));
                    }
                }, options()))
                .build();

        try{player.showDialog(Dialog.create(factory -> factory.empty()
                .base(base)
                .type(DialogType.confirmation(ok, cancel))));}catch(Throwable error){inputFallback(plugin,player,title,safeBody,label,onConfirm,onCancel);}
    }

    /** Runs work on the next tick (a chest GUI can't open while a dialog closes). */
    public static void runNextTick(JavaPlugin plugin, Runnable task) {
        if (plugin == null) {
            task.run();
            return;
        }
        Bukkit.getScheduler().runTask(plugin, task);
    }


    /**
     * Kept for existing call sites; optional font glyphs were removed with the
     * resource-pack design, so this now returns the plain dialog label.
     */
    public static Component withIcon(JavaPlugin plugin, String iconName, Component label) {
        return label;
    }

    /** Standard cancel button that just closes the screen. */
    public static ActionButton cancelButton(JavaPlugin plugin, String text) {
        return button(text, "Close this screen", 150, NEGATIVE, null);
    }

    /** Title component: white, not italic, colour codes supported. */
    public static Component plain(Component title) {
        if (title == null) {
            return Component.empty();
        }
        return title.decoration(TextDecoration.ITALIC, false);
    }
}
