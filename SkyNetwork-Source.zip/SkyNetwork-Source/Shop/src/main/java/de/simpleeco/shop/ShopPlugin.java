package de.simpleeco.shop;

import de.simpleeco.shop.cleanup.LegacyCustomContentCleanup;
import de.simpleeco.shop.economy.EconomyBridge;
import de.simpleeco.shop.economy.PrefsBridge;
import de.simpleeco.shop.gui.ShopListener;
import de.simpleeco.shop.prices.PriceBook;
import de.simpleeco.shop.stock.ShopStock;
import de.simpleeco.shop.util.CoreI18n;
import de.simpleeco.shop.util.GuiGuard;
import de.simpleeco.shop.util.Sounds;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Shop — the rebuilt store.
 *
 * <p>Three screens, all chest-based but rebuilt from scratch:
 * <ol>
 *   <li>the shop itself (3 rows, grey "Click to Add" panes),</li>
 *   <li>the item picker (3 rows: catalogue and enchanted tools),</li>
 *   <li>the shulker builder (4 rows).</li>
 * </ol>
 *
 * Stack sizes and enchantments are chosen in native dialogs.
 */
public class ShopPlugin extends JavaPlugin {

    private PriceBook book;
    private ShopStock stock;
    private EconomyBridge economy;
    private ShopListener listener;
    private StatStore stats;
    private de.simpleeco.shop.mystery.MysteryBoxes mystery;
    private de.simpleeco.shop.mystery.MysteryBoxGui boxGui;

    @Override
    public void onEnable() {
        CoreI18n.registerReloadable("shop", () -> {
            saveDefaultConfig();
            reloadConfig();
            reloadShop();
        });
        saveDefaultConfig();
        removeRetiredShopPrices();

        // Prices from config.yml (defaults built in).
        book = new PriceBook(getConfig());

        // The shop's contents live in stock.yml.
        stock = new ShopStock(this);
        stock.load();

        LegacyCustomContentCleanup retiredContentCleanup = new LegacyCustomContentCleanup(this);
        getServer().getPluginManager().registerEvents(retiredContentCleanup, this);
        retiredContentCleanup.cleanLoadedContent();

        economy = new EconomyBridge(this);
        economy.resolve();
        stats = new StatStore(this);

        PrefsBridge prefs = new PrefsBridge();
        prefs.resolve();
        Sounds sounds = new Sounds(prefs);

        listener = new ShopListener(this, stock, book, economy, prefs, sounds);
        getServer().getPluginManager().registerEvents(listener, this);

        GuiGuard guard = new GuiGuard(this);
        getServer().getPluginManager().registerEvents(guard, this);
        guard.startPeriodicSweep();

        // Mystery boxes use vanilla chest variants.
        mystery = new de.simpleeco.shop.mystery.MysteryBoxes(this);
        mystery.load();
        de.simpleeco.shop.mystery.MysteryBoxGui boxGui =
                new de.simpleeco.shop.mystery.MysteryBoxGui(mystery, economy);
        de.simpleeco.shop.mystery.MysteryBoxService boxService =
                new de.simpleeco.shop.mystery.MysteryBoxService(this, economy);
        getServer().getPluginManager().registerEvents(
                new de.simpleeco.shop.mystery.MysteryBoxListener(boxGui, boxService), this);
        this.boxGui = boxGui;

        PluginCommand cmd = getCommand("shop");
        if (cmd != null) {
            ShopCommand executor = new ShopCommand(this, listener, stats);
            cmd.setExecutor(executor);
            cmd.setTabCompleter(executor);
        }

        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            try {
                new PlaceholderHook(stats, economy.dollarSymbol()).register();
            } catch (Throwable t) {
                getLogger().warning("PlaceholderAPI hook failed: " + t.getMessage());
            }
        }
        getLogger().info("Shop enabled - " + stock.entries().size() + " entries in stock.");
    }

    private void removeRetiredShopPrices() {
        boolean changed = false;
        for (String material : new String[]{"PUMPKIN", "CARVED_PUMPKIN", "JACK_O_LANTERN"}) {
            String path = "prices." + material;
            if (getConfig().contains(path)) {
                getConfig().set(path, null);
                changed = true;
            }
        }
        if (changed) saveConfig();
    }

    /** Re-reads config + stock (used by /reload and the suite reload hub). */
    public void reloadShop() {
        removeRetiredShopPrices();
        book = new PriceBook(getConfig());
        stock.load();
        if (mystery != null) {
            mystery.load();
        }
        if (listener != null) {
            listener.reload(book);
        }
    }

    @Override
    public void onDisable() {
        if (stock != null) {
            stock.save();
        }
        if (stats != null) {
            stats.saveNow();
        }
    }

    public ShopStock stock() {
        return stock;
    }

    public PriceBook book() {
        return book;
    }

    public de.simpleeco.shop.mystery.MysteryBoxGui boxGui() {
        return boxGui;
    }
}
