package de.simpleeco.shop.gui;

import de.simpleeco.shop.economy.EconomyBridge;
import de.simpleeco.shop.prices.PriceBook;
import de.simpleeco.shop.stock.ShopEntry;
import de.simpleeco.shop.stock.ShopStock;
import de.simpleeco.shop.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.List;

/**
 * The shop — single page, 3 rows, no pagination.
 *
 * Slots that are null in the stock are grey panes ("Click to Add").
 * Clicking a pane (admin only) opens the picker; the chosen item replaces
 * that exact slot.  Clicking an existing item opens the buy dialog.
 */
public final class ShopMainGui {

    public static final int SIZE = 27;

    private final ShopStock stock;
    private final PriceBook book;
    private final EconomyBridge economy;

    public ShopMainGui(ShopStock stock, PriceBook book, EconomyBridge economy) {
        this.stock = stock;
        this.book = book;
        this.economy = economy;
    }

    public ShopMainGui(ShopStock stock, PriceBook book) {
        this(stock, book, null);
    }

    public void open(Player player) {
        ShopHolder holder = ShopHolder.main();
        Inventory inv = Bukkit.createInventory(holder, SIZE, Text.of("&8Shop"));
        holder.inventory(inv);

        List<ShopEntry> slots = stock.slots();
        for (int slot = 0; slot < SIZE; slot++) {
            ShopEntry entry = slot < slots.size() ? slots.get(slot) : null;
            if (entry == null) {
                inv.setItem(slot, ShopIcons.pane());
            } else {
                inv.setItem(slot, ShopIcons.entry(entry, book, economy));
            }
        }
        player.openInventory(inv);
    }

    public void open(Player player, int ignored) {
        open(player);
    }

    public int pages() {
        return 1;
    }

    public static List<org.bukkit.Material> catalogue() {
        return ShopStock.DEFAULTS;
    }
}
