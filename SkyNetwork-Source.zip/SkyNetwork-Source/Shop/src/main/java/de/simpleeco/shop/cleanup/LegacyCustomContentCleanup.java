package de.simpleeco.shop.cleanup;

import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.World;
import org.bukkit.block.BlockState;
import org.bukkit.block.Container;
import org.bukkit.block.ShulkerBox;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.plugin.java.JavaPlugin;

/** Removes persistent items and entities left by the retired PumpkinBoss feature. */
public final class LegacyCustomContentCleanup implements Listener {

    private static final String RETIRED_NAMESPACE = "pumpkinboss";
    private final JavaPlugin plugin;

    public LegacyCustomContentCleanup(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    /** Cleans currently loaded world entities and online player inventories once on startup. */
    public void cleanLoadedContent() {
        int removedEntities = 0;
        int removedItems = 0;
        for (World world : Bukkit.getWorlds()) {
            for (Chunk chunk : world.getLoadedChunks()) {
                removedEntities += cleanChunkAndCountEntities(chunk);
            }
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            removedItems += cleanPlayer(player);
        }
        if (removedEntities > 0 || removedItems > 0) {
            plugin.getLogger().info("Removed retired custom content: " + removedEntities
                    + " world entities and " + removedItems + " player items.");
        }
    }

    @EventHandler
    public void onChunkLoad(ChunkLoadEvent event) {
        cleanChunk(event.getChunk());
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        int removed = cleanPlayer(event.getPlayer());
        if (removed > 0) {
            plugin.getLogger().info("Removed " + removed + " retired custom item(s) from a joining player's inventory.");
        }
    }

    @EventHandler
    public void onItemSpawn(ItemSpawnEvent event) {
        ItemStack stack = event.getEntity().getItemStack();
        if (hasRetiredNamespace(event.getEntity().getPersistentDataContainer()) || isRetiredItem(stack)) {
            event.setCancelled(true);
        } else if (purgeNestedItems(stack)) {
            event.getEntity().setItemStack(stack);
        }
    }

    private void cleanChunk(Chunk chunk) {
        cleanChunkAndCountEntities(chunk);
    }

    private int cleanChunkAndCountEntities(Chunk chunk) {
        int removedEntities = 0;
        for (Entity entity : chunk.getEntities()) {
            if (isRetiredEntity(entity)) {
                entity.remove();
                removedEntities++;
            }
        }
        for (BlockState state : chunk.getTileEntities()) {
            if (!(state instanceof Container container)) continue;
            Inventory inventory = container.getInventory();
            if (purgeInventory(inventory) > 0) container.update(true, false);
        }
        return removedEntities;
    }

    private boolean isRetiredEntity(Entity entity) {
        if (hasRetiredNamespace(entity.getPersistentDataContainer())) return true;
        return entity instanceof Item item && isRetiredItem(item.getItemStack());
    }

    private int cleanPlayer(Player player) {
        int removed = purgeInventory(player.getInventory());
        removed += purgeInventory(player.getEnderChest());
        if (isRetiredItem(player.getItemOnCursor())) {
            player.setItemOnCursor(null);
            removed++;
        }
        return removed;
    }

    private int purgeInventory(Inventory inventory) {
        int removed = 0;
        for (int slot = 0; slot < inventory.getSize(); slot++) {
            ItemStack stack = inventory.getItem(slot);
            if (isRetiredItem(stack)) {
                inventory.setItem(slot, null);
                removed++;
            } else if (purgeNestedItems(stack)) {
                inventory.setItem(slot, stack);
                removed++;
            }
        }
        return removed;
    }

    private static boolean purgeNestedItems(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return false;
        ItemMeta meta = stack.getItemMeta();
        if (!(meta instanceof BlockStateMeta blockMeta)
                || !(blockMeta.getBlockState() instanceof ShulkerBox shulker)) return false;
        if (purgeNestedInventory(shulker.getInventory()) == 0) return false;
        blockMeta.setBlockState(shulker);
        stack.setItemMeta(blockMeta);
        return true;
    }

    private static int purgeNestedInventory(Inventory inventory) {
        int removed = 0;
        for (int slot = 0; slot < inventory.getSize(); slot++) {
            ItemStack stack = inventory.getItem(slot);
            if (isRetiredItem(stack)) {
                inventory.setItem(slot, null);
                removed++;
            } else if (purgeNestedItems(stack)) {
                inventory.setItem(slot, stack);
                removed++;
            }
        }
        return removed;
    }

    private static boolean isRetiredItem(ItemStack stack) {
        return stack != null && stack.hasItemMeta()
                && hasRetiredNamespace(stack.getItemMeta().getPersistentDataContainer());
    }

    private static boolean hasRetiredNamespace(PersistentDataContainer data) {
        return data.getKeys().stream().anyMatch(key -> RETIRED_NAMESPACE.equals(key.getNamespace()));
    }
}
