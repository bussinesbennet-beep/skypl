package de.simpleeco.shop.economy;

import de.simpleeco.economy.api.SimplePrefsAPI;
import org.bukkit.Bukkit;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.util.UUID;

/**
 * Optional bridge to SimpleEconomy's shared preference service, used to honour
 * the suite-wide chat/hotbar message toggles. Degrades to defaults when absent.
 */
public class PrefsBridge {

    private SimplePrefsAPI prefs;

    public void resolve() {
        try {
            RegisteredServiceProvider<SimplePrefsAPI> rsp =
                    Bukkit.getServicesManager().getRegistration(SimplePrefsAPI.class);
            prefs = rsp != null ? rsp.getProvider() : null;
        } catch (Throwable t) {
            prefs = null;
        }
    }

    public boolean get(UUID uuid, String key, boolean def) {
        return prefs != null ? prefs.get(uuid, key, def) : def;
    }
}
