package de.simpleeco.shop.gui;

import de.simpleeco.economy.api.SimplePrefsAPI;
import de.simpleeco.shop.economy.EconomyBridge;
import de.simpleeco.shop.economy.PrefsBridge;
import de.simpleeco.shop.prices.PriceBook;
import de.simpleeco.shop.stock.ShopEntry;
import de.simpleeco.shop.stock.ShopStock;
import de.simpleeco.shop.util.DialogUi;
import de.simpleeco.shop.util.Sounds;
import de.simpleeco.shop.util.Text;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Single-page shop: clicking a grey pane replaces that exact slot.
 */
public final class ShopListener implements Listener {

    private final JavaPlugin plugin;
    private final ShopStock stock;
    private final Map<UUID, ShopStock> playerStocks = new ConcurrentHashMap<>();
    private PriceBook book;
    private final EconomyBridge economy;
    private final PrefsBridge prefs;
    private final Sounds sounds;

    private ShopPickerGui pickerGui;
    private ShulkerGui shulkerGui;
    private EnchantDialog enchantDialog;

    public ShopListener(JavaPlugin plugin, ShopStock stock, PriceBook book, EconomyBridge economy,
                        PrefsBridge prefs, Sounds sounds) {
        this.plugin = plugin; this.stock = stock; this.book = book; this.economy = economy;
        this.prefs = prefs; this.sounds = sounds;
        rebuild();
    }

    private void rebuild() {
        pickerGui = new ShopPickerGui(book, economy);
        shulkerGui = new ShulkerGui(book, economy);
        enchantDialog = new EnchantDialog(plugin, book, economy);
    }

    private ShopStock stockFor(Player player) {
        return playerStocks.computeIfAbsent(player.getUniqueId(), id -> {
            ShopStock personal = new ShopStock(plugin, id);
            personal.load();
            return personal;
        });
    }

    public void openMain(Player p) { new ShopMainGui(stockFor(p), book, economy).open(p); }
    public void openPicker(Player p) { stockFor(p); pickerGui.open(p, true, -1, null); }
    public void reload(PriceBook nb) { if (nb!=null){ book=nb; rebuild(); } }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof ShopHolder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player player)) return;
        int slot = e.getRawSlot();
        Inventory top = e.getView().getTopInventory();
        if (slot < 0 || slot >= top.getSize()) return;
        switch (h.view()) {
            case MAIN -> handleMain(player, h, slot);
            case PICKER -> handlePicker(player, h, slot);
            case SHULKER -> handleShulker(player, h, slot);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof ShopHolder) e.setCancelled(true);
    }

    // --------------------------------------------------------------- main
    private void handleMain(Player player, ShopHolder holder, int slot) {
        ShopStock stock = stockFor(player);
        ShopEntry existing = stock.slots().get(slot);
        if (existing == null) {
            sounds.click(player);
            pickerGui.open(player, true, slot, null);
            return;
        }
        boolean quickBuy = prefs.get(player.getUniqueId(), SimplePrefsAPI.KEY_SHOP_QUICK_BUY, false);
        if (quickBuy) {
            buyNow(player, existing);
        } else {
            openBuyDialog(player, existing, slot);
        }
    }

    // ------------------------------------------------------------- picker
    private void handlePicker(Player player, ShopHolder holder, int slot) {
        if (slot == ShopPickerGui.BACK_SLOT) {
            sounds.click(player);
            if (holder.draft() != null) shulkerGui.open(player, holder.draft(), holder.targetSlot());
            else openMain(player);
            return;
        }
        Material mat = ShopPickerGui.materialAt(slot, holder.allowShulker());
        if (mat != null) {
            sounds.click(player);
            if (mat == Material.SHULKER_BOX) {
                // shulker draft — slot-indexed; target slot preserved via holder
                ShopEntry draft = ShopEntry.of(Material.SHULKER_BOX);
                shulkerGui.open(player, draft, holder.targetSlot());
                return;
            }
            askStackSize(player, mat, holder.targetSlot(), holder.draft(), holder.allowShulker());
            return;
        }
        if (slot == ShopPickerGui.SWORD_SLOT || slot == ShopPickerGui.PICKAXE_SLOT) {
            sounds.click(player);
            Material tool = slot == ShopPickerGui.SWORD_SLOT ? Material.DIAMOND_SWORD : Material.DIAMOND_PICKAXE;
            player.closeInventory();
            DialogUi.runNextTick(plugin, () -> enchantDialog.open(player, tool, holder.draft(),
                    entry -> deliver(player, entry, holder.targetSlot(), holder.draft())));
            return;
        }
    }

    // ------------------------------------------------------------- shulker
    private void handleShulker(Player player, ShopHolder holder, int slot) {
        ShopStock stock = stockFor(player);
        ShopEntry draft = holder.draft();
        if (draft == null) { pickerGui.open(player,true, holder.targetSlot(), null); return; }
        if (slot < 27) {
            // replace this exact shulker pane
            ShopEntry existing = draft.slotContents().get(slot);
            if (existing != null) {
                // clicking existing item inside shulker could remove it — shift-click removes
                // For now, treat click as replace: open picker for that slot
            }
            sounds.click(player);
            // open picker targeting shulker inner slot
            openPickerForShulkerSlot(player, draft, slot, holder.targetSlot());
            return;
        }
        if (slot == ShulkerGui.CONFIRM_SLOT) {
            if (draft.contents().isEmpty() && draft.slotContents().stream().allMatch(c -> c==null)) {
                sounds.deny(player);
                player.sendMessage(Text.of("&7Put at least one item in the shulker first."));
                return;
            }
            int target = holder.targetSlot();
            if (target < 0 || target >= ShopStock.SIZE) {
                // find first empty glass slot
                for (int i=0;i<ShopStock.SIZE;i++) if(stock.slots().get(i)==null){ target=i; break; }
                if (target < 0) target = 0;
            }
            stock.setSlot(target, draft);
            stock.save();
            sounds.success(player);
            openMain(player);
            return;
        }
        if (slot == ShulkerGui.BACK_SLOT) {
            sounds.click(player);
            if (holder.targetSlot() >= 0) pickerGui.open(player,true, holder.targetSlot(), null);
            else openMain(player);
        }
    }

    private void openPickerForShulkerSlot(Player player, ShopEntry draft, int innerSlot, int outerTarget) {
        // custom holder that remembers both outer target and inner slot
        // We reuse ShopHolder.picker but store draft + encode inner slot via a separate path:
        // Instead, open a lightweight inventory that directly handles this.
        // Simpler: create a dedicated holder wrapping draft+slots
        // We will repurpose ShulkerPicker via inline handling: store pending in player metadata
        player.closeInventory();
        // Use a temporary holder: we open the normal picker but with allowShulker=false and attach draft + innerSlot via a new ShulkerSlotHolder
        // Easiest: register a one-off listener via metadata — we just open pickerGui with a wrapper that on deliver writes to slot
        Inventory inv = org.bukkit.Bukkit.createInventory(new ShulkerSlotHolder(draft, innerSlot, outerTarget), 27, Text.of("&8Add to Shulker"));
        // fill same as ShopPickerGui
        int s = 0;
        for (Material m : ShopMainGui.catalogue()) {
            if (m == Material.SHULKER_BOX) continue;
            inv.setItem(s++, ShopIcons.catalogue(m, book.unit(m), economy));
        }
        inv.setItem(ShopPickerGui.SWORD_SLOT, ShopIcons.catalogue(Material.DIAMOND_SWORD, book.unit(Material.DIAMOND_SWORD), economy));
        inv.setItem(ShopPickerGui.PICKAXE_SLOT, ShopIcons.catalogue(Material.DIAMOND_PICKAXE, book.unit(Material.DIAMOND_PICKAXE), economy));
        inv.setItem(ShopPickerGui.BACK_SLOT, ShopIcons.backButton());
        player.openInventory(inv);
    }

    // Helper holder for shulker inner slot picking
    public static final class ShulkerSlotHolder implements org.bukkit.inventory.InventoryHolder {
        final ShopEntry draft; final int innerSlot; final int outerTarget;
        private Inventory inv;
        ShulkerSlotHolder(ShopEntry d,int inner,int outer){ draft=d; innerSlot=inner; outerTarget=outer; }
        void inv(Inventory inv){this.inv=inv;}
        @Override public Inventory getInventory(){ return inv; }
    }

    // Intercept clicks for that custom holder
    @EventHandler
    public void onShulkerSlotPick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof ShulkerSlotHolder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player player)) return;
        int slot = e.getRawSlot();
        if (slot<0||slot>=27) return;
        if (slot == ShopPickerGui.BACK_SLOT) {
            sounds.click(player);
            shulkerGui.open(player, h.draft, h.outerTarget);
            return;
        }
        Material mat = ShopPickerGui.materialAt(slot, false);
        if (mat != null) {
            sounds.click(player);
            askStackSizeForShulkerSlot(player, mat, h);
            return;
        }
        if (slot==ShopPickerGui.SWORD_SLOT||slot==ShopPickerGui.PICKAXE_SLOT) {
            sounds.click(player);
            Material tool = slot==ShopPickerGui.SWORD_SLOT?Material.DIAMOND_SWORD:Material.DIAMOND_PICKAXE;
            player.closeInventory();
            DialogUi.runNextTick(plugin, () -> enchantDialog.open(player, tool, h.draft, entry -> {
                h.draft.setSlotContent(h.innerSlot, entry);
                sounds.success(player);
                shulkerGui.open(player, h.draft, h.outerTarget);
            }));
            return;
        }
    }

    private void askStackSizeForShulkerSlot(Player player, Material mat, ShulkerSlotHolder h) {
        int max = Math.max(1, mat.getMaxStackSize());
        List<DialogBody> body = new ArrayList<>();
        body.add(DialogUi.itemBody(ShopEntry.of(mat).build()));
        body.add(DialogUi.muted("Stack size (1 - "+max+")"));
        player.closeInventory();
        DialogUi.input(plugin, player, DialogUi.title(ShopIcons.pretty(mat)), body,"amount","Amount",String.valueOf(max),3,"Add","Cancel",
                (p,typed)->{
                    int amt=parseAmount(typed,max);
                    ShopEntry e=new ShopEntry(mat,amt);
                    h.draft.setSlotContent(h.innerSlot, e);
                    sounds.success(player);
                    shulkerGui.open(player, h.draft, h.outerTarget);
                }, p-> shulkerGui.open(p, h.draft, h.outerTarget));
    }

    // -------------------------------------------------------------- flows
    private void askStackSize(Player player, Material material, int targetSlot, ShopEntry draft, boolean allowShulker) {
        int max = Math.max(1, material.getMaxStackSize());
        List<DialogBody> body = new ArrayList<>();
        body.add(DialogUi.itemBody(ShopEntry.of(material).build()));
        body.add(DialogUi.muted("Stack size (1 \u2013 " + max + ")"));
        player.closeInventory();
        DialogUi.input(plugin, player, DialogUi.title(ShopIcons.pretty(material)), body,
                "amount","Amount",String.valueOf(max),3,"Add","Cancel",
                (p,typed)->{
                    int amount=parseAmount(typed,max);
                    ShopEntry entry=new ShopEntry(material,amount);
                    deliver(p,entry,targetSlot,draft);
                }, p-> {
                    if (draft!=null) shulkerGui.open(p,draft,targetSlot);
                    else pickerGui.open(p,true,targetSlot,null);
                });
    }

    private static int parseAmount(String typed,int max){
        try{ int v=(int)Math.floor(Double.parseDouble(typed.trim())); return Math.max(1,Math.min(max,v)); }catch(Exception e){ return max; }
    }

    private void deliver(Player player, ShopEntry entry, int targetSlot, ShopEntry draft) {
        if (draft != null) {
            // shulker path — find first empty pane or use targetSlot if we have slot-indexed
            // For legacy path (direct from main picker), just append
            draft.contents().add(entry);
            sounds.success(player);
            shulkerGui.open(player,draft,targetSlot);
            return;
        }
        ShopStock stock = stockFor(player);
        int slot = targetSlot;
        if (slot < 0 || slot >= ShopStock.SIZE) {
            for (int i=0;i<ShopStock.SIZE;i++) if(stock.slots().get(i)==null){ slot=i; break; }
            if (slot < 0) slot=0;
        }
        stock.setSlot(slot, entry);
        stock.save();
        sounds.success(player);
        openMain(player);
    }

    private void buyNow(Player player, ShopEntry entry) {
        double price = entry.price(book);
        if (!economy.isAvailable()) {
            player.sendMessage(Text.of("&7Economy is not available."));
            sounds.deny(player);
            return;
        }
        if (!economy.withdraw(player, price)) {
            sounds.deny(player);
            player.sendMessage(Text.of("&7You cannot afford that."));
            return;
        }
        var leftovers = player.getInventory().addItem(entry.build());
        leftovers.values().forEach(rest -> player.getWorld().dropItemNaturally(player.getLocation(), rest));
        sounds.success(player);
        player.sendMessage(Text.of("&7Bought &f" + ShopIcons.pretty(entry.material())
                + "&7 for &a" + economy.format(price)));
    }

    private void openBuyDialog(Player player, ShopEntry entry, int slot) {
        double price = entry.price(book);
        List<DialogBody> body = new ArrayList<>();
        body.add(DialogUi.itemBody(entry.build()));
        body.add(DialogUi.text("&fPrice: &a" + economy.format(price)));
        body.add(DialogUi.text("&fBalance: &a" + economy.format(economy.getBalance(player.getUniqueId()))));

        ActionButton buy = DialogUi.button("Buy", "Pay and receive the item", 150,
                DialogUi.POSITIVE, DialogUi.click(p -> {
                    p.closeDialog();
                    DialogUi.runNextTick(plugin, () -> buyNow(p, entry));
                }));
        ActionButton cancel = DialogUi.button("Cancel", "Close", 150,
                DialogUi.NEGATIVE, DialogUi.click(Player::closeDialog));

        ActionButton remove = DialogUi.button("Remove from Shop", "Delete this entry and restore its empty plus slot.", 170,
                DialogUi.NEGATIVE, DialogUi.click(p -> {
                    p.closeDialog();
                    DialogUi.runNextTick(plugin, () -> {
                        ShopStock personal = stockFor(p);
                        if (slot < 0 || slot >= ShopStock.SIZE || personal.slots().get(slot) != entry) {
                            openMain(p);
                            return;
                        }
                        personal.setSlot(slot, null);
                        personal.save();
                        sounds.success(p);
                        openMain(p);
                    });
                }));
        DialogUi.open(player, Text.of("&8Shop item: " + ShopIcons.pretty(entry.material())),
                body, List.of(buy, remove, cancel), 3);
    }
}
