package de.simpleeco.shop.economy;

import de.simpleeco.economy.api.SimpleEconomyAPI;
import de.simpleeco.economy.api.SimpleStatsAPI;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;
import java.util.UUID;

/**
 * Bridges to the suite's single currency (SimpleEconomy Dollars) via Bukkit's
 * ServicesManager.
 *
 * <p>The former Shards and Credits providers were removed on purpose: the shop
 * now has exactly one payment path, Dollars.
 */
public class EconomyBridge {

    private final JavaPlugin plugin;
    private SimpleEconomyAPI dollars;
    private SimpleStatsAPI stats;

    public EconomyBridge(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    /** (Re)resolves the provider from the services manager. */
    public void resolve() {
        RegisteredServiceProvider<SimpleEconomyAPI> d =
                Bukkit.getServicesManager().getRegistration(SimpleEconomyAPI.class);
        dollars = d != null ? d.getProvider() : null;

        try {
            RegisteredServiceProvider<SimpleStatsAPI> st =
                    Bukkit.getServicesManager().getRegistration(SimpleStatsAPI.class);
            stats = st != null ? st.getProvider() : null;
        } catch (Throwable t) {
            stats = null;
        }

        if (dollars == null) {
            plugin.getLogger().warning("SimpleEconomy not found - purchases are disabled.");
        }
    }

    public boolean isDollarAvailable() {
        return dollars != null;
    }

    /** The Dollar currency symbol (e.g. "$"), or "$" if the provider is absent. */
    public String dollarSymbol() {
        return dollars != null ? dollars.getCurrencySymbol() : "$";
    }

    public boolean isAvailable() {
        return isDollarAvailable();
    }

    /** Current balance in Dollars. */
    public double getBalance(UUID uuid) {
        return dollars != null ? dollars.getBalance(uuid) : 0;
    }

    /** Formats an amount for display. */
    public String format(double amount) {
        if (dollars != null) return dollars.format(amount);
        DecimalFormat decimal = new DecimalFormat("#,##0.##", new DecimalFormatSymbols(Locale.US));
        return "$" + decimal.format(amount);
    }

    /** Adds money (used by mystery box rewards and shop refunds). */
    public boolean deposit(Player player, double amount) {
        return dollars != null && dollars.deposit(player.getUniqueId(), amount);
    }

    /** Attempts to withdraw the total cost. Returns true on success. */
    public boolean withdraw(Player player, double amount) {
        UUID id = player.getUniqueId();
        boolean ok = dollars != null && dollars.withdraw(id, amount);
        if (ok && stats != null) {
            stats.add(id, SimpleStatsAPI.KEY_SHOP_SPENT, amount);
        }
        return ok;
    }
}
