package de.simpleeco.shop.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

import java.util.ArrayList;
import java.util.List;

/**
 * Helper for turning &-color-coded strings into Adventure Components.
 * Supports hex colors in the form &#rrggbb (e.g. &#c6c7f2).
 */
public final class Text {

    private static final LegacyComponentSerializer LEGACY =
            LegacyComponentSerializer.builder()
                    .character('&')
                    .hexColors()
                    .build();

    private static final java.util.regex.Pattern HEX =
            java.util.regex.Pattern.compile("&#([0-9A-Fa-f]{6})");

    private Text() {
    }

    /**
     * Converts &#rrggbb into the &x&r&r&g&g&b&b form the serializer understands.
     */
    private static String preprocess(String input) {
        java.util.regex.Matcher m = HEX.matcher(input);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String hex = m.group(1);
            StringBuilder repl = new StringBuilder("&x");
            for (char c : hex.toCharArray()) {
                repl.append('&').append(c);
            }
            m.appendReplacement(sb, repl.toString());
        }
        m.appendTail(sb);
        return sb.toString();
    }

    /** Parses a legacy &-string (with &#rrggbb hex) and disables italics. */
    public static Component of(String legacy) {
        return LEGACY.deserialize(preprocess(legacy)).decoration(TextDecoration.ITALIC, false);
    }

    /** Parses a legacy &-string but keeps italics ON (for italic lore/labels). */
    public static Component italic(String legacy) {
        return LEGACY.deserialize(preprocess(legacy)).decoration(TextDecoration.ITALIC, true);
    }

    /** Non-italic lore lines. */
    public static List<Component> lore(List<String> lines) {
        List<Component> result = new ArrayList<>();
        for (String line : lines) {
            result.add(of(line));
        }
        return result;
    }

    /** Italic lore lines (gray-italic navigation style). */
    public static List<Component> loreItalic(List<String> lines) {
        List<Component> result = new ArrayList<>();
        for (String line : lines) {
            result.add(italic(line));
        }
        return result;
    }
}
