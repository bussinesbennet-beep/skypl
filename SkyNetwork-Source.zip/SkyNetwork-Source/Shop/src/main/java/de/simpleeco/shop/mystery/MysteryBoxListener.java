package de.simpleeco.shop.mystery;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

/** Click handling for the mystery box screen. */
public final class MysteryBoxListener implements Listener {

    private final MysteryBoxGui gui;
    private final MysteryBoxService service;

    public MysteryBoxListener(MysteryBoxGui gui, MysteryBoxService service) {
        this.gui = gui;
        this.service = service;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof MysteryBoxGui.Holder)) {
            return;
        }
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        int slot = event.getRawSlot();
        if (slot < 0 || slot >= MysteryBoxGui.SIZE) {
            return;
        }
        MysteryBoxes.Tier tier = gui.tierAt(slot);
        if (tier == null) {
            return;
        }
        player.closeInventory();
        service.open(player, tier);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof MysteryBoxGui.Holder) {
            event.setCancelled(true);
        }
    }
}
