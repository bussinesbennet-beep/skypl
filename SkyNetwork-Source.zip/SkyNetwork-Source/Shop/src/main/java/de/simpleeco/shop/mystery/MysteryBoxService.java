package de.simpleeco.shop.mystery;

import de.simpleeco.shop.economy.EconomyBridge;
import de.simpleeco.shop.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;


/**
 * Opens a mystery box: charges the cost, rolls the outcome and executes it.
 *
 * <p>Outcomes come from {@code mystery.yml}. Commands run from the console with
 * {@code <player>}, {@code <x>}, {@code <y>}, {@code <z>} substituted, so admins
 * can add anything — summoning, particles, loot, scoreboard changes.
 */
public final class MysteryBoxService {

    private final JavaPlugin plugin;
    private final EconomyBridge economy;

    public MysteryBoxService(JavaPlugin plugin, EconomyBridge economy) {
        this.plugin = plugin;
        this.economy = economy;
    }

    /** Charges and opens one box. Returns false if the player cannot afford it. */
    public boolean open(Player player, MysteryBoxes.Tier tier) {
        if (tier == null) {
            return false;
        }
        if (tier.cost > 0) {
            if (!economy.isAvailable() || !economy.withdraw(player, tier.cost)) {
                player.sendMessage(Text.of("&7You cannot afford that box."));
                return false;
            }
        }

        // Opening effects.
        player.playSound(player.getLocation(), Sound.BLOCK_CHEST_OPEN, 1f, 1.2f);
        player.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING,
                player.getLocation().add(0, 1, 0), 30, 0.6, 0.8, 0.6, 0.1);

        MysteryBoxes.Outcome outcome = tier.roll();
        if (outcome == null) {
            player.sendMessage(Text.of("&7The box is empty."));
            return true;
        }

        announce(player, tier, outcome);
        apply(player, outcome);
        return true;
    }

    private void announce(Player player, MysteryBoxes.Tier tier, MysteryBoxes.Outcome outcome) {
        player.sendMessage(Text.of(tier.display + " &7\u00bb " + outcome.name));
        if (outcome.message != null && !outcome.message.isEmpty()) {
            player.sendMessage(Text.of(outcome.message));
        }
        // Small extra feedback for everyone around.
        Location loc = player.getLocation();
        if (tier.id.equals("legendary")) {
            player.getWorld().playSound(loc, Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
            player.getWorld().spawnParticle(Particle.FIREWORK, loc.add(0, 1, 0), 60,
                    0.8, 1.0, 0.8, 0.15);
        } else if (tier.id.equals("rare")) {
            player.getWorld().playSound(loc, Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
        }
    }

    private void apply(Player player, MysteryBoxes.Outcome outcome) {
        Location loc = player.getLocation();

        if (outcome.money > 0 && economy.isAvailable()) {
            economy.deposit(player, outcome.money);
            player.sendMessage(Text.of("&7You received &f" + economy.format(outcome.money) + "&7."));
        }

        if (outcome.give != null && !outcome.give.isEmpty()) {
            give(player, outcome.give);
        }

        if (outcome.command != null && !outcome.command.isEmpty()) {
            String cmd = outcome.command
                    .replace("<player>", player.getName())
                    .replace("<x>", format(loc.getX()))
                    .replace("<y>", format(loc.getY()))
                    .replace("<z>", format(loc.getZ()));
            Bukkit.getScheduler().runTask(plugin,
                    () -> Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd));
        }
    }

    /** Hands an item over, dropping whatever does not fit. */
    private void give(Player player, String spec) {
        String[] parts = spec.split(":");
        Material material = Material.matchMaterial(parts[0].trim().toUpperCase());
        if (material == null) {
            plugin.getLogger().warning("Unknown material in mystery.yml: " + spec);
            return;
        }
        int amount = 1;
        if (parts.length > 1) {
            try {
                amount = Math.max(1, Integer.parseInt(parts[1].trim()));
            } catch (NumberFormatException ignored) {
                amount = 1;
            }
        }
        ItemStack stack = new ItemStack(material, Math.min(material.getMaxStackSize(), amount));
        int remaining = amount - stack.getAmount();
        var leftovers = player.getInventory().addItem(stack);
        leftovers.values().forEach(rest ->
                player.getWorld().dropItemNaturally(player.getLocation(), rest));
        while (remaining > 0) {
            int chunk = Math.min(material.getMaxStackSize(), remaining);
            var rest = player.getInventory().addItem(new ItemStack(material, chunk));
            rest.values().forEach(drop ->
                    player.getWorld().dropItemNaturally(player.getLocation(), drop));
            remaining -= chunk;
        }
    }

    private static String format(double value) {
        return String.format(java.util.Locale.US, "%.1f", value);
    }


}
