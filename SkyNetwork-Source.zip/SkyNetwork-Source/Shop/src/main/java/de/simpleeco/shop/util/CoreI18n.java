package de.simpleeco.shop.util;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.lang.reflect.Method;
import java.util.UUID;

/**
 * Reflection bridge to SkyCore's translation service (SkyCoreAPI) with NO
 * compile-time dependency. Routes this plugin's player-facing messages through
 * the player's chosen language, stored centrally by SkyCore. If SkyCore is
 * absent, {@link #translate} returns null and the caller falls back to its own
 * local config message. Keys are namespaced per plugin, e.g. "shop.no-permission".
 */
public final class CoreI18n {

    private static final String API_CLASS = "de.simpleeco.core.api.SkyCoreAPI";

    private static Boolean available;
    private static Object provider;
    private static Method translateMethod;
    private static Method translateScopedMethod;

    private CoreI18n() {
    }

    public static boolean isAvailable() {
        if (available == null || !available) {
            resolve();
        }
        return available != null && available;
    }

    private static synchronized void resolve() {
        if (available != null && available) {
            return;
        }
        try {
            Class<?> api = Class.forName(API_CLASS);
            Method getReg = Bukkit.getServicesManager().getClass()
                    .getMethod("getRegistration", Class.class);
            Object rsp = getReg.invoke(Bukkit.getServicesManager(), api);
            if (rsp == null) {
                available = false;
                return;
            }
            Method getProvider = rsp.getClass().getMethod("getProvider");
            provider = getProvider.invoke(rsp);
            translateMethod = api.getMethod("translate", UUID.class, String.class, String[].class);
            try {
                translateScopedMethod = api.getMethod("translateScoped", UUID.class, String.class, String.class, String[].class);
            } catch (NoSuchMethodException ignored) {
                translateScopedMethod = null;
            }
            available = provider != null;
        } catch (Throwable t) {
            available = false;
        }
    }

    /**
     * Translate a namespaced key for a player. Returns the raw colour-coded
     * string, or null if SkyCore is unavailable or the key is missing (so the
     * caller can fall back to its local message).
     */
    /** Translate, or return the provided fallback string when unavailable/missing. */
    public static String orElse(Player player, String key, String fallback, String... repl) {
        String t = translate(player, key, repl);
        if (t != null) {
            return t;
        }
        String out = fallback;
        for (int i = 0; i + 1 < repl.length; i += 2) {
            out = out.replace("{" + repl[i] + "}", repl[i + 1]);
        }
        return out;
    }

    public static String translate(Player player, String key, String... repl) {
        if (player == null || !isAvailable()) {
            return null;
        }
        try {
            String result = (String) translateMethod.invoke(provider, player.getUniqueId(), key, repl);
            if (result == null || result.equals(key)) {
                return null;
            }
            return result;
        } catch (Throwable t) {
            return null;
        }
    }

    /**
     * Translate a GUI title/name honouring the player's "translate GUIs" scope.
     * Returns the translation, or {@code fallback} (with {placeholders} filled)
     * when SkyCore is missing, the scope is off, or the key is absent.
     */
    public static String gui(Player player, String key, String fallback, String... repl) {
        return scoped(player, "gui", key, fallback, repl);
    }

    /** Scope-aware translate with fallback. scope = chat|scoreboard|messages|gui. */
    public static String scoped(Player player, String scope, String key, String fallback, String... repl) {
        if (player != null && isAvailable() && translateScopedMethod != null) {
            try {
                String result = (String) translateScopedMethod.invoke(
                        provider, player.getUniqueId(), scope, key, repl);
                if (result != null && !result.equals(key)) {
                    return result;
                }
            } catch (Throwable ignored) {
            }
        }
        String out = fallback;
        for (int i = 0; i + 1 < repl.length; i += 2) {
            out = out.replace("{" + repl[i] + "}", repl[i + 1]);
        }
        return out;
    }

    /**
     * Registers a reload handler with SkyCore's ReloadHub so
     * {@code /skycore reload <name>} covers this plugin. No-op without SkyCore.
     */
    public static void registerReloadable(String name, Runnable action) {
        if (name == null || action == null || !isAvailable()) {
            return;
        }
        try {
            Class<?> api = Class.forName(API_CLASS);
            java.lang.reflect.Method m = api.getMethod("registerReloadable", String.class, Runnable.class);
            m.invoke(provider, name, action);
        } catch (Throwable ignored) {
            // SkyCore absent or older API version - reload via restart still works
        }
    }
}
