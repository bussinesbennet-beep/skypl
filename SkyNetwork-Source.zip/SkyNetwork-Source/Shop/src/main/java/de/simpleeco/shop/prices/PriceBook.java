package de.simpleeco.shop.prices;

import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.inventory.ItemStack;

import java.util.EnumMap;
import java.util.Map;

/**
 * Central price list for the shop.
 *
 * <p>Every material has a unit price. The values can be overridden in
 * {@code config.yml} under {@code prices:} — anything not listed there falls back
 * to the built-in defaults below (these match the SellWorth defaults, so buying
 * and selling stay consistent).
 *
 * <p>Enchanted items and shulkers add their value on top: a shulker containing a
 * totem costs exactly the shulker price <b>plus</b> the totem price.
 */
public final class PriceBook {

    private final Map<Material, Double> prices = new EnumMap<>(Material.class);
    private double enchantPrice = 100.0;

    /** Built-in defaults (SellWorth-compatible). */
    private static final Map<Material, Double> DEFAULTS = new EnumMap<>(Material.class);

    static {
        put(Material.OBSIDIAN, 12);
        put(Material.END_CRYSTAL, 125);
        put(Material.TOTEM_OF_UNDYING, 875);
        put(Material.RESPAWN_ANCHOR, 200);
        put(Material.GLOWSTONE, 10);
        put(Material.GOLDEN_APPLE, 62);
        put(Material.GOLDEN_CARROT, 20);
        put(Material.FIREWORK_ROCKET, 8);
        put(Material.SHULKER_BOX, 300);
        put(Material.DIAMOND_SWORD, 350);
        put(Material.DIAMOND_PICKAXE, 320);
    }

    private static void put(Material m, double price) {
        DEFAULTS.put(m, price);
    }

    public PriceBook(FileConfiguration config) {
        prices.putAll(DEFAULTS);
        if (config == null) {
            return;
        }
        enchantPrice = config.getDouble("enchant-price", 100.0);
        var section = config.getConfigurationSection("prices");
        if (section != null) {
            for (String key : section.getKeys(false)) {
                Material mat = Material.matchMaterial(key);
                if (mat != null) {
                    prices.put(mat, section.getDouble(key, unit(mat)));
                }
            }
        }
    }

    /** Unit price of a material (0 if unknown). */
    public double unit(Material material) {
        if (material == null) {
            return 0;
        }
        Double price = prices.get(material);
        if (price != null) {
            return price;
        }
        // Sensible fallback so newly added items are never free.
        double fallback = DEFAULTS.getOrDefault(material, 5.0);
        prices.put(material, fallback);
        return fallback;
    }

    /** Surcharge per enchantment level. */
    public double enchantPrice() {
        return enchantPrice;
    }

    /** Price of a plain stack (unit price × amount). */
    public double stackPrice(ItemStack stack) {
        if (stack == null) {
            return 0;
        }
        return unit(stack.getType()) * Math.max(1, stack.getAmount());
    }
}
