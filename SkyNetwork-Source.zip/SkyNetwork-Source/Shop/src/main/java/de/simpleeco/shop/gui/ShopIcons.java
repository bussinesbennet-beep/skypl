package de.simpleeco.shop.gui;

import de.simpleeco.shop.economy.EconomyBridge;
import de.simpleeco.shop.prices.PriceBook;
import de.simpleeco.shop.stock.ShopEntry;
import de.simpleeco.shop.util.Text;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Builds every item shown in the shop screens.
 * Shop entries and picker icons keep exactly one lore line: their formatted price.
 */
public final class ShopIcons {

    public static final String ADD_NAME = "&7Click to Add";
    public static final String ADD_LORE = "&7more Items to the Shop";

    private ShopIcons() {
    }

    /** Formatted shop price line using the configured SimpleEconomy currency. */
    public static String priceLine(double price, EconomyBridge economy) {
        return "&fPrice: &a" + formatted(price, economy);
    }

    /** Fallback overload retained for callers without an economy bridge. */
    public static String priceLine(double price) {
        return "&fPrice: &a$" + format(price);
    }

    public static ItemStack pane() {
        return button(Material.GRAY_STAINED_GLASS_PANE, ADD_NAME, List.of(ADD_LORE));
    }

    /** An entry has only its formatted price line in lore. */
    public static ItemStack entry(ShopEntry shopEntry, PriceBook book, EconomyBridge economy) {
        ItemStack stack = shopEntry.build();
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.lore(Text.lore(List.of(priceLine(shopEntry.price(book), economy))));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    /** Backwards-compatible fallback overload. */
    public static ItemStack entry(ShopEntry shopEntry, PriceBook book) {
        return entry(shopEntry, book, null);
    }

    /** Catalogue item in the picker: one formatted price line. */
    public static ItemStack catalogue(Material material, double price, EconomyBridge economy) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.lore(Text.lore(List.of(priceLine(price, economy))));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    /** Backwards-compatible fallback overload. */
    public static ItemStack catalogue(Material material, double price) {
        return catalogue(material, price, null);
    }

    /** Plain labelled button using its ordinary vanilla appearance. */
    public static ItemStack button(Material material, String name, List<String> lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.displayName(Text.of(name));
            if (lore != null && !lore.isEmpty()) meta.lore(Text.lore(lore));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    /** Clear left-arrow button used for Back in the picker/builder. */
    public static ItemStack backButton() {
        return button(Material.ARROW, "&fBack", List.of("&7Return to the previous screen."));
    }

    /** Green button used to accept the shulker build. */
    public static ItemStack confirmButton() {
        return button(Material.LIME_DYE, "&fConfirm", List.of("&7Finish this shulker and save it to the shop."));
    }

    private static String formatted(double value, EconomyBridge economy) {
        return economy == null ? "$" + format(value) : economy.format(value);
    }

    /** Grouped fallback numeric formatting, e.g. 12,345.67. */
    public static String format(double value) {
        DecimalFormat decimal = new DecimalFormat("#,##0.##", new DecimalFormatSymbols(Locale.US));
        return decimal.format(value);
    }

    public static String pretty(Material material) {
        String name = material.name().toLowerCase(Locale.ROOT).replace('_', ' ');
        StringBuilder sb = new StringBuilder();
        for (String word : name.split(" ")) {
            if (word.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return sb.toString();
    }

    public static String prettyEnchant(Enchantment enchantment) {
        return enchantment == null ? "?" : titleCase(enchantment.getKey().getKey());
    }

    private static String titleCase(String key) {
        String[] parts = key.split("_");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }

    /** 1..10 as roman numerals, used for enchant levels. */
    public static String roman(int level) {
        return switch (level) {
            case 1 -> "I";
            case 2 -> "II";
            case 3 -> "III";
            case 4 -> "IV";
            case 5 -> "V";
            case 6 -> "VI";
            case 7 -> "VII";
            case 8 -> "VIII";
            case 9 -> "IX";
            case 10 -> "X";
            default -> String.valueOf(level);
        };
    }

    /** Contents summary used for status messages. */
    public static String describe(ShopEntry entry) {
        StringBuilder sb = new StringBuilder(entry.material().name());
        if (entry.amount() > 1) sb.append(" x").append(entry.amount());
        if (!entry.contents().isEmpty()) {
            sb.append(" [");
            boolean first = true;
            for (ShopEntry child : entry.contents()) {
                if (!first) sb.append(", ");
                first = false;
                sb.append(describe(child));
            }
            sb.append(']');
        }
        if (!entry.enchants().isEmpty()) {
            sb.append(" {");
            boolean first = true;
            for (Map.Entry<Enchantment, Integer> e : entry.enchants().entrySet()) {
                if (!first) sb.append(", ");
                first = false;
                sb.append(prettyEnchant(e.getKey())).append(' ').append(e.getValue());
            }
            sb.append('}');
        }
        return sb.toString();
    }
}
