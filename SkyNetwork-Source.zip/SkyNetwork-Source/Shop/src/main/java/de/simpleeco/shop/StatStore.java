package de.simpleeco.shop;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

/**
 * Tiny per-player cumulative statistics store backed by a YAML file
 * ({@code stats.yml}). Used to feed PlaceholderAPI placeholders such as the
 * total amount of Dollars a player has spent in the shop.
 *
 * Writes are debounced/saved asynchronously to avoid main-thread I/O stalls.
 */
public class StatStore {

    private final JavaPlugin plugin;
    private final File file;
    private final FileConfiguration data;
    private boolean dirty = false;

    public StatStore(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "stats.yml");
        if (!plugin.getDataFolder().exists()) {
            plugin.getDataFolder().mkdirs();
        }
        this.data = YamlConfiguration.loadConfiguration(file);
        // Periodic autosave every 60s if anything changed.
        plugin.getServer().getScheduler().runTaskTimerAsynchronously(plugin, this::saveIfDirty, 1200L, 1200L);
    }

    public double get(UUID uuid, String key) {
        return data.getDouble(uuid + "." + key, 0.0);
    }

    public synchronized void add(UUID uuid, String key, double amount) {
        double current = data.getDouble(uuid + "." + key, 0.0);
        data.set(uuid + "." + key, current + amount);
        dirty = true;
    }

    public synchronized void saveIfDirty() {
        if (!dirty) {
            return;
        }
        try {
            data.save(file);
            dirty = false;
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save stats.yml: " + e.getMessage());
        }
    }

    public void saveNow() {
        try {
            data.save(file);
            dirty = false;
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save stats.yml: " + e.getMessage());
        }
    }
}
