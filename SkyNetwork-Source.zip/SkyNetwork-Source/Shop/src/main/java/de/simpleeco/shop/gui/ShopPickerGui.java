package de.simpleeco.shop.gui;

import de.simpleeco.shop.economy.EconomyBridge;
import de.simpleeco.shop.prices.PriceBook;
import de.simpleeco.shop.stock.ShopEntry;
import de.simpleeco.shop.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

public final class ShopPickerGui {
    public static final int SIZE = 27;
    public static final int SWORD_SLOT = 12;
    public static final int PICKAXE_SLOT = 14;
    public static final int BACK_SLOT = 26;

    private final PriceBook book;
    private final EconomyBridge economy;
    public ShopPickerGui(PriceBook book, EconomyBridge economy){ this.book=book; this.economy=economy; }
    public ShopPickerGui(PriceBook book){ this(book, null); }

    public void open(Player player, boolean allowShulker, int targetSlot, ShopEntry draft) {
        ShopHolder holder = ShopHolder.picker(allowShulker, targetSlot, draft);
        String title = draft==null?"&8Add to Shop":"&8Add to Shulker";
        Inventory inv = Bukkit.createInventory(holder, SIZE, Text.of(title));
        holder.inventory(inv);
        int slot=0;
        for(Material m: ShopMainGui.catalogue()){
            if(m==Material.SHULKER_BOX && !allowShulker) continue;
            inv.setItem(slot++, ShopIcons.catalogue(m, book.unit(m), economy));
        }
        inv.setItem(SWORD_SLOT, ShopIcons.catalogue(Material.DIAMOND_SWORD, book.unit(Material.DIAMOND_SWORD), economy));
        inv.setItem(PICKAXE_SLOT, ShopIcons.catalogue(Material.DIAMOND_PICKAXE, book.unit(Material.DIAMOND_PICKAXE), economy));
        inv.setItem(BACK_SLOT, ShopIcons.backButton());
        player.openInventory(inv);
    }

    // legacy compat
    public void open(Player player, boolean allowShulker, ShopEntry draft){ open(player,allowShulker,-1,draft); }

    public static Material materialAt(int slot, boolean allowShulker){
        int idx=0;
        for(Material m: ShopMainGui.catalogue()){
            if(m==Material.SHULKER_BOX && !allowShulker) continue;
            if(idx==slot) return m;
            idx++;
        }
        return null;
    }
}
