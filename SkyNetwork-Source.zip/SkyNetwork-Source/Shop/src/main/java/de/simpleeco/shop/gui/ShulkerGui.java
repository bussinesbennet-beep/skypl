package de.simpleeco.shop.gui;

import de.simpleeco.shop.economy.EconomyBridge;
import de.simpleeco.shop.prices.PriceBook;
import de.simpleeco.shop.stock.ShopEntry;
import de.simpleeco.shop.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public final class ShulkerGui {

    public static final int SIZE = 36;
    public static final int PREVIEW_SLOT = 31;
    public static final int BACK_SLOT = 27;
    public static final int CONFIRM_SLOT = 35;

    private final PriceBook book;
    private final EconomyBridge economy;

    public ShulkerGui(PriceBook book, EconomyBridge economy) {
        this.book = book;
        this.economy = economy;
    }

    public ShulkerGui(PriceBook book) {
        this(book, null);
    }

    public void open(Player player, ShopEntry draft) {
        open(player, draft, -1);
    }

    public void open(Player player, ShopEntry draft, int outerTarget) {
        ShopHolder holder = ShopHolder.shulker(draft, outerTarget);
        Inventory inv = Bukkit.createInventory(holder, SIZE, Text.of("&8Shulker"));
        holder.inventory(inv);
        for (int slot = 0; slot < 27; slot++) {
            ShopEntry entry = draft.slotContents().get(slot);
            inv.setItem(slot, entry == null ? ShopIcons.pane() : ShopIcons.entry(entry, book, economy));
        }
        inv.setItem(PREVIEW_SLOT, preview(draft));
        inv.setItem(BACK_SLOT, ShopIcons.backButton());
        inv.setItem(CONFIRM_SLOT, ShopIcons.confirmButton());
        player.openInventory(inv);
    }

    private ItemStack preview(ShopEntry draft) {
        ItemStack stack = draft.build();
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.lore(Text.lore(List.of(ShopIcons.priceLine(draft.price(book), economy))));
            stack.setItemMeta(meta);
        }
        return stack;
    }
}
