package de.simpleeco.shop.gui;

import de.simpleeco.shop.economy.EconomyBridge;
import de.simpleeco.shop.stock.ShopEntry;
import de.simpleeco.shop.util.DialogUi;
import de.simpleeco.shop.util.Text;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Enchantment picker for the shop's diamond sword / diamond pickaxe.
 *
 * <p>Every enchantment is a toggle button that cycles through its levels:
 * {@code 0 → I → II … → max → 0}. Enchantments that would conflict are blocked —
 * Sharpness, Smite and Bane of Arthropods can never end up on the same sword,
 * and Fortune never sits next to Silk Touch on the same pickaxe.
 */
public final class EnchantDialog {

    /** One available enchantment. */
    private record Def(Enchantment enchantment, int max, String group) {
    }

    /** Enchantments on a diamond sword. */
    private static final List<Def> SWORD = List.of(
            new Def(Enchantment.SHARPNESS, 5, "damage"),
            new Def(Enchantment.SMITE, 5, "damage"),
            new Def(Enchantment.BANE_OF_ARTHROPODS, 5, "damage"),
            new Def(Enchantment.KNOCKBACK, 2, ""),
            new Def(Enchantment.FIRE_ASPECT, 2, ""),
            new Def(Enchantment.LOOTING, 3, ""),
            new Def(Enchantment.SWEEPING_EDGE, 3, ""),
            new Def(Enchantment.UNBREAKING, 3, ""),
            new Def(Enchantment.MENDING, 1, ""),
            new Def(Enchantment.VANISHING_CURSE, 1, "")
    );

    /** Enchantments on a diamond pickaxe. */
    private static final List<Def> PICKAXE = List.of(
            new Def(Enchantment.EFFICIENCY, 5, ""),
            new Def(Enchantment.FORTUNE, 3, "tool"),
            new Def(Enchantment.SILK_TOUCH, 1, "tool"),
            new Def(Enchantment.UNBREAKING, 3, ""),
            new Def(Enchantment.MENDING, 1, ""),
            new Def(Enchantment.VANISHING_CURSE, 1, "")
    );

    /** Per-player editing state. */
    private static final class Session {
        final Material material;
        final Map<Enchantment, Integer> levels = new LinkedHashMap<>();
        final ShopEntry draft;
        final java.util.function.Consumer<ShopEntry> onFinish;

        Session(Material material, ShopEntry draft, java.util.function.Consumer<ShopEntry> onFinish) {
            this.material = material;
            this.draft = draft;
            this.onFinish = onFinish;
        }
    }

    private static final Map<UUID, Session> SESSIONS = new HashMap<>();

    private final JavaPlugin plugin;
    private final de.simpleeco.shop.prices.PriceBook book;
    private final EconomyBridge economy;

    public EnchantDialog(JavaPlugin plugin, de.simpleeco.shop.prices.PriceBook book, EconomyBridge economy) {
        this.plugin = plugin;
        this.book = book;
        this.economy = economy;
    }

    public EnchantDialog(JavaPlugin plugin, de.simpleeco.shop.prices.PriceBook book) {
        this(plugin, book, null);
    }

    private static List<Def> defs(Material material) {
        return material == Material.DIAMOND_PICKAXE ? PICKAXE : SWORD;
    }

    /** Opens (or re-opens) the enchantment picker. */
    public void open(Player player, Material material, ShopEntry draft,
                     java.util.function.Consumer<ShopEntry> onFinish) {
        Session session = SESSIONS.computeIfAbsent(player.getUniqueId(),
                id -> new Session(material, draft, onFinish));
        session.levels.clear();
        show(player, session);
    }

    private void show(Player player, Session session) {
        List<Def> defs = defs(session.material);

        Component title = Text.of("&8Enchantments \u2014 " + ShopIcons.pretty(session.material));

        ShopEntry preview = new ShopEntry(session.material, 1);
        preview.enchants().putAll(session.levels);

        List<DialogBody> body = new ArrayList<>();
        body.add(DialogUi.muted("Click an enchantment to raise its level,"
                + " click again to go further. Conflicting enchantments are blocked."));
        body.add(DialogUi.muted("Price: " + (economy == null
                ? "$" + ShopIcons.format(preview.price(book))
                : economy.format(preview.price(book)))));

        List<ActionButton> buttons = new ArrayList<>();
        for (Def def : defs) {
            int level = session.levels.getOrDefault(def.enchantment(), 0);
            boolean blocked = level == 0 && isBlocked(def, session);

            Component label = Component.text()
                    .append(Component.text(ShopIcons.prettyEnchant(def.enchantment()), 
                            blocked ? NamedTextColor.DARK_GRAY : NamedTextColor.WHITE)
                            .decoration(TextDecoration.ITALIC, false))
                    .append(Component.text(level > 0 ? "  " + ShopIcons.roman(level) : "  \u2014",
                            level > 0 ? NamedTextColor.WHITE : NamedTextColor.GRAY)
                            .decoration(TextDecoration.ITALIC, false))
                    .build();

            String tip = blocked
                    ? "Conflicts with another enchantment already on this item"
                    : (level >= def.max()
                        ? "Click to remove"
                        : "Click for level " + ShopIcons.roman(level + 1));

            buttons.add(DialogUi.button(label, tip, 150,
                    blocked ? NamedTextColor.DARK_GRAY : NamedTextColor.WHITE,
                    blocked ? null : DialogUi.click(p -> {
                        cycle(session, def);
                        show(p, session);
                    })));
        }

        buttons.add(DialogUi.button(DialogUi.withIcon(plugin, "check",
                        Component.text("Add to Shop").decoration(TextDecoration.ITALIC, false)),
                "Finish and put the item in the shop",
                150, DialogUi.POSITIVE, DialogUi.click(p -> {
                    SESSIONS.remove(p.getUniqueId());
                    p.closeDialog();
                    ShopEntry entry = new ShopEntry(session.material, 1);
                    entry.enchants().putAll(session.levels);
                    DialogUi.runNextTick(plugin, () -> session.onFinish.accept(entry));
                })));

        buttons.add(DialogUi.button(DialogUi.withIcon(plugin, "cross",
                        Component.text("Cancel").decoration(TextDecoration.ITALIC, false)),
                "Discard and go back",
                150, DialogUi.NEGATIVE, DialogUi.click(p -> {
                    SESSIONS.remove(p.getUniqueId());
                    p.closeDialog();
                })));

        DialogUi.open(player, title, body, buttons, 2);
    }

    /** True if adding this enchantment would break a conflict rule. */
    private static boolean isBlocked(Def def, Session session) {
        if (def.group().isEmpty()) {
            return false;
        }
        for (Def other : defs(session.material)) {
            if (other == def || !other.group().equals(def.group())) {
                continue;
            }
            if (session.levels.getOrDefault(other.enchantment(), 0) > 0) {
                return true;
            }
        }
        return false;
    }

    /** Cycles the level and enforces the conflict groups. */
    private static void cycle(Session session, Def def) {
        int current = session.levels.getOrDefault(def.enchantment(), 0);
        int next = current + 1;
        if (next > def.max()) {
            session.levels.remove(def.enchantment());
            return;
        }
        if (!def.group().isEmpty()) {
            for (Def other : defs(session.material)) {
                if (other.group().equals(def.group()) && other != def) {
                    session.levels.remove(other.enchantment());
                }
            }
        }
        session.levels.put(def.enchantment(), next);
    }
}
