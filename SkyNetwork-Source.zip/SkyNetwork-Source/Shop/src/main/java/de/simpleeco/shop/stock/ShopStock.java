package de.simpleeco.shop.stock;

import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Slot-indexed shop stock: 27 fixed slots, null = grey pane.
 * Persisted as 27 entry slot file so admin placement is remembered.
 */
public final class ShopStock {

    public static final int SIZE = 27;

    public static final List<Material> DEFAULTS = List.of(
            Material.OBSIDIAN,
            Material.END_CRYSTAL,
            Material.TOTEM_OF_UNDYING,
            Material.RESPAWN_ANCHOR,
            Material.GLOWSTONE,
            Material.GOLDEN_APPLE,
            Material.GOLDEN_CARROT,
            Material.FIREWORK_ROCKET,
            Material.SHULKER_BOX
    );

    // Slots 9-17 map to the 9 defaults on first run — middle row only.
    private static final int[] DEFAULT_SLOTS = {9,10,11,12,13,14,15,16,17};

    private final JavaPlugin plugin;
    private final UUID owner;
    private final List<ShopEntry> slots = new ArrayList<>();
    private File file;

    public ShopStock(JavaPlugin plugin) {
        this(plugin, null);
    }

    public ShopStock(JavaPlugin plugin, UUID owner) {
        this.plugin = plugin;
        this.owner = owner;
        for (int i = 0; i < SIZE; i++) slots.add(null);
    }

    /** Fixed 27-slot view (null = empty pane). */
    public List<ShopEntry> slots() { return slots; }

    /** Legacy list view — only non-null entries, in slot order. */
    public List<ShopEntry> entries() {
        List<ShopEntry> out = new ArrayList<>();
        for (ShopEntry e : slots) if (e != null) out.add(e);
        return out;
    }

    public void setSlot(int slot, ShopEntry entry) {
        if (slot < 0 || slot >= SIZE) return;
        slots.set(slot, entry);
    }

    public void replaceAll(List<ShopEntry> list) {
        for (int i = 0; i < SIZE; i++) slots.set(i, null);
        for (int i = 0; i < Math.min(list.size(), SIZE); i++) slots.set(i, list.get(i));
    }

    // ------------------------------------------------------------------- io
    public void load() {
        String configured = owner == null
                ? plugin.getConfig().getString("stock.file", "../../../network-data/shop-stock.yml")
                : plugin.getConfig().getString("stock.player-directory", "../../../network-data/player-shops") + "/" + owner + ".yml";
        file = plugin.getDataFolder().toPath().resolve(configured).normalize().toFile();
        for (int i = 0; i < SIZE; i++) slots.set(i, null);

        if (!file.exists()) {
            for (int i = 0; i < DEFAULTS.size(); i++) {
                slots.set(DEFAULT_SLOTS[i], ShopEntry.of(DEFAULTS.get(i)));
            }
            save();
            return;
        }

        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        // New format: slots: [ {slot:9, material:...}, ... ]
        if (yml.contains("slots")) {
            List<?> list = yml.getList("slots");
            if (list != null) {
                for (Object raw : list) {
                    if (raw instanceof Map<?,?> map) {
                        Object s = map.get("slot");
                        int slot = s instanceof Number n ? n.intValue() : -1;
                        ShopEntry entry = fromMap(map);
                        if (entry != null && slot >= 0 && slot < SIZE) slots.set(slot, entry);
                    }
                }
            }
            // Remove entries from the retired custom pumpkin shop stock, including
            // any old pumpkin items nested in shulker-box entries.
            boolean changed = purgeRemovedPumpkinEntries();
            // Migrate: if file is empty (old bad save), seed defaults.
            if (entries().isEmpty()) {
                seedDefaults();
                changed = true;
            }
            if (changed) save();
            return;
        }

        // Legacy format: items: [ {material:...}, ... ] — middle row only
        List<?> list = yml.getList("items");
        if (list == null || list.isEmpty()) {
            seedDefaults();
            save();
            return;
        }
        int idx = 0;
        for (Object raw : list) {
            if (raw instanceof Map<?,?> map) {
                ShopEntry entry = fromMap(map);
                if (entry != null) {
                    if (idx < DEFAULTS.size()) {
                        slots.set(DEFAULT_SLOTS[idx++], entry);
                    } else {
                        // spill into glass area — find next empty
                        for (int s = 0; s < SIZE; s++) if (slots.get(s) == null) { slots.set(s, entry); break; }
                    }
                }
            }
        }
        if (purgeRemovedPumpkinEntries()) save();
        if (entries().isEmpty()) {
            seedDefaults();
            save();
        }
    }

    public void save() {
        if (file == null) file = new File(plugin.getDataFolder(), "stock.yml");
        YamlConfiguration yml = new YamlConfiguration();
        List<Map<String,Object>> out = new ArrayList<>();
        for (int slot = 0; slot < SIZE; slot++) {
            ShopEntry e = slots.get(slot);
            if (e == null) continue;
            Map<String,Object> map = toMap(e);
            map.put("slot", slot);
            out.add(map);
        }
        yml.set("slots", out);
        // keep old key empty so old jar doesn't re-read it as authoritative
        yml.set("items", null);
        try {
            File parent = file.getAbsoluteFile().getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IOException("Could not create " + parent);
            yml.save(file);
        } catch (IOException e) { plugin.getLogger().warning("Konnte stock.yml nicht speichern: "+e.getMessage()); }
    }

    private void seedDefaults() {
        for (int i = 0; i < DEFAULTS.size(); i++) {
            slots.set(DEFAULT_SLOTS[i], ShopEntry.of(DEFAULTS.get(i)));
        }
    }

    private boolean purgeRemovedPumpkinEntries() {
        boolean changed = false;
        for (int slot = 0; slot < SIZE; slot++) {
            ShopEntry entry = slots.get(slot);
            if (entry == null) continue;
            if (isRemovedPumpkin(entry.material())) {
                slots.set(slot, null);
                changed = true;
            } else if (purgeNestedPumpkins(entry)) {
                changed = true;
            }
        }
        return changed;
    }

    private static boolean purgeNestedPumpkins(ShopEntry entry) {
        boolean changed = false;
        for (int slot = 0; slot < entry.slotContents().size(); slot++) {
            ShopEntry child = entry.slotContents().get(slot);
            if (child == null) continue;
            if (isRemovedPumpkin(child.material())) {
                entry.setSlotContent(slot, null);
                changed = true;
            } else if (purgeNestedPumpkins(child)) {
                changed = true;
            }
        }
        for (int i = entry.contents().size() - 1; i >= 0; i--) {
            ShopEntry child = entry.contents().get(i);
            if (isRemovedPumpkin(child.material())) {
                entry.contents().remove(i);
                changed = true;
            } else if (purgeNestedPumpkins(child)) {
                changed = true;
            }
        }
        return changed;
    }

    private static boolean isRemovedPumpkin(Material material) {
        return material == Material.PUMPKIN
                || material == Material.CARVED_PUMPKIN
                || material == Material.JACK_O_LANTERN;
    }

    // ------------------------------------------------------------- mapping
    private static Map<String,Object> toMap(ShopEntry entry) {
        Map<String,Object> map = new LinkedHashMap<>();
        map.put("material", entry.material().name());
        map.put("amount", entry.amount());
        if (!entry.enchants().isEmpty()) {
            Map<String,Object> ench = new LinkedHashMap<>();
            entry.enchants().forEach((en,lvl) -> ench.put(en.getKey().getKey(), lvl));
            map.put("enchants", ench);
        }
        if (!entry.contents().isEmpty()) {
            List<Map<String,Object>> kids = new ArrayList<>();
            for (ShopEntry child : entry.contents()) {
                if (child != null) kids.add(toMap(child));
            }
            map.put("contents", kids);
        }
        if (!entry.slotContents().isEmpty()) {
            // shulker slot-indexed contents — persist with explicit slot when possible
            List<Map<String,Object>> kids = new ArrayList<>();
            for (int s = 0; s < entry.slotContents().size(); s++) {
                ShopEntry child = entry.slotContents().get(s);
                if (child == null) continue;
                Map<String,Object> m = toMap(child);
                m.put("slot", s);
                kids.add(m);
            }
            map.put("slotContents", kids);
        }
        return map;
    }

    @SuppressWarnings("unchecked")
    private static ShopEntry fromMap(Map<?,?> map) {
        Object matName = map.get("material");
        Material material = matName == null ? null : Material.matchMaterial(String.valueOf(matName));
        if (material == null) return null;
        int amount = 1;
        Object amt = map.get("amount");
        if (amt instanceof Number n) amount = n.intValue();
        ShopEntry entry = new ShopEntry(material, amount);
        Object ench = map.get("enchants");
        if (ench instanceof Map<?,?> enchMap) {
            for (Map.Entry<?,?> e : enchMap.entrySet()) {
                Enchantment enchantment = enchantmentOf(String.valueOf(e.getKey()));
                if (enchantment != null && e.getValue() instanceof Number lvl) entry.enchants().put(enchantment, lvl.intValue());
            }
        }
        // shulker slot-indexed
        Object sc = map.get("slotContents");
        if (sc instanceof List<?> kidList && !kidList.isEmpty()) {
            // ensure slotContents sized to 27
            for (Object kid : kidList) {
                if (kid instanceof Map<?,?> kidMap) {
                    ShopEntry child = fromMap(kidMap);
                    Object s = kidMap.get("slot");
                    int slot = s instanceof Number n ? n.intValue() : -1;
                    if (child != null) {
                        if (slot >= 0) entry.setSlotContent(slot, child);
                        else entry.contents().add(child);
                    }
                }
            }
        } else {
            Object kids = map.get("contents");
            if (kids instanceof List<?> kidList2) {
                for (Object kid : kidList2) if (kid instanceof Map<?,?> kidMap) {
                    ShopEntry child = fromMap(kidMap);
                    if (child != null) entry.contents().add(child);
                }
            }
        }
        return entry;
    }

    public static Enchantment enchantmentOf(String key) {
        if (key == null) return null;
        try { return org.bukkit.Registry.ENCHANTMENT.get(org.bukkit.NamespacedKey.minecraft(key.toLowerCase())); } catch (Throwable t) { return null; }
    }
}
