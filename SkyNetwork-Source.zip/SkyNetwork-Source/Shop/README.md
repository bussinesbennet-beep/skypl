# Shop 1.2.0

Paper GUI shop for the SimpleEconomy suite. The main shop is a single 27-slot stock page; admins edit the shop in-game and the contents are persisted in `stock.yml`.

## Commands and permissions

| Command | What it does | Permission |
|---|---|---|
| `/shop` | Opens the shop | `shop.use` (default: everyone) |
| `/shop add` | Opens the item picker | `shop.admin` (default: op) |
| `/shop boxes` | Opens the Mystery Box menu | `shop.use` |

## Buying

Shop Quick Buy is **on by default**. With it enabled, a regular player's click buys that stock entry immediately. Switch it off under **Settings → Shop & Economy** to restore the buy confirmation dialog. Admins always receive the confirmation/edit dialog, which has **Buy**, **Remove from Shop**, and **Cancel** actions. Removing an entry saves the stock and restores the empty add pane in that slot.

Purchases use SimpleEconomy. When the economy provider is unavailable, purchases are declined without charging. If the player's inventory is full, remaining items are dropped at their location.

## Editing stock and prices

- Click a gray **Click to Add** pane as an admin, or run `/shop add`, then choose an item.
- Stack size and enchantments use native Paper dialogs. The shulker builder supports shop items inside a shulker entry.
- Unit prices, enchantment surcharge, and optional dialog icons are configured in `config.yml`.
- Stock updates are persisted in `stock.yml`; removing an entry leaves its slot empty and ready for reuse.

## Preferences integration

The Shop reads `SimplePrefsAPI.KEY_SHOP_QUICK_BUY`. The Settings plugin exposes this toggle in Shop & Economy. The default is `true` when the preference provider or a saved value is absent. Mystery Box tiers remain available via `/shop boxes`, now represented by vanilla Chest, Ender Chest, and Shulker Box items without pumpkin models or resource-pack dependence.

On startup and as old chunks load, Shop also clears legacy PumpkinBoss-tagged entities/items from the world and loaded containers. It removes matching items from player inventories and ender chests when they join, so retired summon/reward items and old bosses do not remain active after the feature is removed.

## Building

Requires JDK 21+ and Maven. Install SimpleEconomy to the local Maven repository, then build Shop:

```bash
export JAVA_HOME=/path/to/jdk-21
bash /path/to/maven/bin/mvn -f SimpleEconomy/pom.xml install
bash /path/to/maven/bin/mvn -f Shop/pom.xml clean package
```

The artifact is `Shop/target/Shop-1.2.0.jar`.
